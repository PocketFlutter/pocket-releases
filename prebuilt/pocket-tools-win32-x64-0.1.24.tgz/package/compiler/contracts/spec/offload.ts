/** Offload v1 request/reply values cross the host boundary as bounded direct
 * objects. The UI copies bounded values; only the provider executes
 * capabilities. */
export const OFFLOAD = Object.freeze({
  version: 1, recordBytes: 4096, payloadChars: 2500, pending: 8,
  deliveriesPerFrame: 1, submissionsPerFrame: 2, timeoutFrames: 600,
  port: 8741,
});

export interface OffloadOps {
  /** Device-local provider with independent credits and generation. No pairing
   * is needed; the host's local capability/path policy controls access. */
  local?: OffloadOps;
  /** Positive authenticated connection generation; zero/negative = offline. */
  session(): number;
  /** Nonwaiting bounded copy. False means no credit; caller retains work. */
  submitValue(request: OffloadRequest): boolean;
  /** At most one complete reply value per host frame. Never performs IO. */
  takeValue(): OffloadReply | undefined;
  /** 2-bit coverage; width 4..512 in multiples of 4, height 1..128.
   * Power-of-two envelope: min width 8, min height 16, at most 8192 pixels
   * on POSIX hosts; the 3DS permits 16384 envelope pixels for multiline text.
   * Source coverage stays within 8192 pixels and one upload per frame.
   * Foreground is ABGR. Optional columns carry one lowercase hex palette index
   * per column; palette contains 1..16 concatenated RGB hex colors. */
  uploadCoverage?(base64: string, width: number, height: number, foreground: number, columns?: string, palette?: string): number;
}
export interface OffloadRequest { v: 1; id: number; method: string; payload: string }
export interface OffloadReply { id: number; payload?: string; error?: string }
