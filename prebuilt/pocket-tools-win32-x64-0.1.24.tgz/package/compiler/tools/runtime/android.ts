import { REPOSITORY_ROOT } from "../repository.ts";
import motoToolchain from "../build/toolchains/moto-g-play.ts";
import redmiToolchain from "../build/toolchains/redmi-1s.ts";
// The generic Android runtime: what tools/android.ts build-app compiles for
// every game of a profile, built once, with no game in it, and linked by
// aapt2 into one unsigned template APK.
//
//   bun tools/runtime.ts android [--profile=redmi-1s] [--out=dist/runtime/android]
//
// Writes into the output directory:
//   template.apk         aapt2's link of the runtime with ANDROID_TEMPLATE_IDENTITY:
//                        the compiled manifest and resources.arsc, the default
//                        launcher icon (PocketJS's mark) at five densities,
//                        empty assets/app.js and assets/app.pak, classes.dex
//                        (PocketActivity) and lib/armeabi-v7a/libpocketjs.so,
//                        lib/arm64-v8a/libpocketjs.so (Rust core + QuickJS +
//                        host, compiled with the profile's target id, host ABI
//                        and viewport only); unsigned
//   AndroidManifest.xml, res/values/strings.xml
//                        the templates it was linked from (@POCKET_*@ placeholders)
//   runtime.json         target, hostAbi, pocketjs, profile, viewport, android, files
//
// tools/repack/android.ts turns it and a `.pocket` into a signed APK with no
// SDK tool.

import { copyFileSync, existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, relative, resolve } from "node:path";
import { linkAndroidApk } from "../../tools/android-link.ts";
import { ANDROID_TEMPLATE, ANDROID_TEMPLATE_SOURCES, androidTemplateJob } from "../../tools/repack/android.ts";
import { RUNTIME_MANIFEST, type RuntimeManifest } from "../../tools/repack/shared/runtime.ts";
import { MOTO_G_PLAY_CONTRACTS, MOTO_G_PLAY_TARGET } from "../moto-g-play-profile.ts";
import { REDMI_1S_CONTRACTS, REDMI_1S_TARGET } from "../redmi-1s-profile.ts";
import { writeRuntimeManifest } from "../../tools/runtime/manifest.ts";
import redmiProfile from "../../profiles/redmi-1s-dev.ts";
import motoProfile from "../../profiles/moto-g-play-dev.ts";
import { hashPocketProfile, type PocketProfile } from "../../framework/src/profile.ts";

const repository = REPOSITORY_ROOT;

interface Contract {
  readonly hostAbi: number;
  readonly display: { readonly logicalViewports: readonly (readonly number[])[]; readonly rasterDensity: number };
}

/** The Android profiles a runtime can be built for, by tools/android.ts profile name. */
export const ANDROID_RUNTIME_PROFILES: Readonly<Record<string, { readonly target: string; readonly contract: Contract; readonly profile: PocketProfile }>> = {
  "redmi-1s": { target: REDMI_1S_TARGET, contract: REDMI_1S_CONTRACTS.targets[REDMI_1S_TARGET], profile: redmiProfile },
  "moto-g-play": { target: MOTO_G_PLAY_TARGET, contract: MOTO_G_PLAY_CONTRACTS.targets[MOTO_G_PLAY_TARGET], profile: motoProfile },
};

function walk(directory: string): string[] {
  return readdirSync(directory).flatMap((name) => {
    const path = join(directory, name);
    return statSync(path).isDirectory() ? walk(path) : [path];
  });
}

export async function buildRuntimeAndroid(argv: readonly string[] = []): Promise<string> {
  let profile = "redmi-1s";
  let out: string | undefined;
  for (const argument of argv) {
    if (argument.startsWith("--profile=")) profile = argument.slice("--profile=".length);
    else if (argument.startsWith("--out=")) out = resolve(argument.slice("--out=".length));
    else throw new Error(`usage: bun tools/runtime.ts android [--profile=<${Object.keys(ANDROID_RUNTIME_PROFILES).join("|")}>] [--out=<dir>] (unknown argument ${argument})`);
  }
  const chosen = ANDROID_RUNTIME_PROFILES[profile];
  if (!chosen) throw new Error(`runtime android: no profile ${profile}; use ${Object.keys(ANDROID_RUNTIME_PROFILES).join(" or ")}`);
  out ??= join(repository, profile === "redmi-1s" ? "dist/runtime/android" : `dist/runtime/android-${profile}`);

  // The directory is replaced: refuse one that holds anything but an earlier runtime.
  if (existsSync(out) && readdirSync(out).length && !existsSync(join(out, RUNTIME_MANIFEST))) {
    throw new Error(`runtime android: ${out} is not empty and holds no earlier runtime`);
  }

  const started = performance.now();
  const parts = mkdtempSync(join(tmpdir(), "pocket-runtime-android-"));
  let manifest: RuntimeManifest;
  try {
    const build = Bun.spawnSync(["bun", join(repository, "tools/android.ts"), `--profile=${profile}`, "runtime", `--out=${parts}`], {
      cwd: repository,
      stdout: "inherit",
      stderr: "inherit",
    });
    if (!build.success) throw new Error(`runtime android: tools/android.ts runtime failed: ${build.signalCode ?? build.exitCode}`);
    const toolchain = profile === "redmi-1s" ? redmiToolchain : motoToolchain;
    const sdk = {
      apiLevel: toolchain.android.apiLevel,
      buildToolsVersion: toolchain.android.buildToolsVersion,
      minSdkVersion: toolchain.android.minSdkVersion,
      targetSdkVersion: toolchain.android.targetSdkVersion,
    };
    const abis: string[] = toolchain.android.abis.map((abi: { abi: string }) => abi.abi);
    const files = new Map(walk(parts).map((path) => [relative(parts, path).split("\\").join("/"), new Uint8Array(readFileSync(path))]));
    const template = await linkAndroidApk(androidTemplateJob(files, sdk, abis));

    rmSync(out, { recursive: true, force: true });
    mkdirSync(out, { recursive: true });
    writeFileSync(join(out, ANDROID_TEMPLATE), template);
    for (const source of ANDROID_TEMPLATE_SOURCES) {
      mkdirSync(dirname(join(out, source)), { recursive: true });
      copyFileSync(join(parts, source), join(out, source));
    }
    manifest = await writeRuntimeManifest(out, {
      target: chosen.target,
      hostAbi: chosen.contract.hostAbi,
      profile,
      profileHash: hashPocketProfile(chosen.profile),
      files: [ANDROID_TEMPLATE, ...ANDROID_TEMPLATE_SOURCES].sort(),
      extra: {
        viewport: { logical: chosen.contract.display.logicalViewports[0], rasterDensity: chosen.contract.display.rasterDensity },
        android: {
          toolchain: toolchain.toolchainVersion,
          ...sdk,
          ndkVersion: toolchain.android.ndkVersion,
          abis,
          quickjs: toolchain.quickjs.revision,
          rust: toolchain.rust.toolchain,
        },
      },
    });
  } finally {
    rmSync(parts, { recursive: true, force: true });
  }
  const total = Object.values(manifest.files).reduce((sum, file) => sum + file.bytes, 0);
  console.log(
    `output: ${out} (${Object.keys(manifest.files).length} files, ${total} bytes, PocketJS ${manifest.pocketjs}, ` +
      `${((performance.now() - started) / 1000).toFixed(1)} s)`,
  );
  return out;
}

if (import.meta.main) {
  try {
    await buildRuntimeAndroid(Bun.argv.slice(2));
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}
