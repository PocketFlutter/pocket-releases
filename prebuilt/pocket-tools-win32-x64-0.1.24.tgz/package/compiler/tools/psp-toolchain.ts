// Temporary entrypoint while program build adapters move to tools/build.
export * from "./build/toolchains/psp/build.ts";
