import { resolveSourceEntry, sourceAppContent, sourceOutputName } from "./source-app.ts";
import { resolveSolidAotModel } from "../microts/compiler/aot-solid-browser.ts";
import { modelConfiguration } from "../microts/compiler/aot-model-build.ts";
import { BuildInputs } from "../framework/compiler/build-inputs.ts";
import { addInlineTextFontSlots } from "./inline-text-slots.ts";
import { buildWorker } from "./build-worker.ts";
// tools/build.ts <app> — the TWO-PASS app build (docs/DESIGN.md "Build pipeline").
//
//   bun tools/build.ts apps/hero/app.tsx    (or just `hero`)
//   bun tools/build.ts hero-main             (mounted demo entry)
//
// pass 1  transform & collect: framework-specific JSX + TS over every
//         .tsx/.ts reachable from the app entry (content-hash cached),
//         collecting candidate class strings + text codepoints from the AST.
// compile tailwind.ts -> styles.bin + an ignored styles.generated.ts mirror;
//         bake-font.ts -> font atlas per used slot; demo images (PNG/SVG or a
//         placeholder); pak.ts packs it all -> dist/<app>.pak.
// pass 2  Bun.build (plugin serves the CACHED pass-1 transforms plus this
//         build's in-memory generated styles, iife, target browser,
//         minify false) -> dist/<app>.js.
//
// Flags:
//   --framework=solid|vue-vapor|octane  select the framework for this build
//   --extra-chars=<string>       force extra codepoints into every atlas
//   --density=<integer>          low-level target sampling density (default 1)
//   --font-regular=<path>        override the regular font source
//   --font-bold=<path>           override the bold font source
//   --outdir=<path>              write <app>.js/.pak here instead of dist/
//                                (external repos build their apps against a
//                                vendored PocketJS and keep outputs local)
//   --strict-classes             fail when a `class` attribute holds a literal
//                                that does not compile; without it the build
//                                prints the same finding as a warning

import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import { resolve as resolvePath, join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { IMG_FLAG_LINEAR, PSM } from "../contracts/spec/spec.ts";
import {
  FRAMEWORKS,
  frameworkVariantPath,
  jsxPlugin,
  packagePath,
  parseFramework,
  transformFile,
  type LiteralSite,
  type PocketFramework,
} from "../framework/compiler/jsx-plugin.ts";
import { animationThemeSchema } from "../contracts/spec/pocket-manifest.ts";
import { validateSchema, type ContractDiagnostic } from "../framework/src/manifest/schema.ts";
import { verifyPlanHash, verifyPlanProfile, type ResolvedBuildPlan } from "../framework/src/manifest/plan.ts";
import { POCKET_BINDING_GENERATION } from "../contracts/spec/binding-generation.ts";
import { registerAnimationTheme, setAnimationTickRate } from "../framework/compiler/animation.ts";
import { compileClasses, generateStylesModule, suspectClassLiteral, unknownUtilities } from "../framework/compiler/tailwind.ts";
import { bakeAtlases } from "../framework/compiler/bake-font.ts";
import { readFontConfig } from "../framework/compiler/font-config.ts";
import { bakeSvg } from "../framework/compiler/bake-svg.ts";
import {
  assertDensityVariantDimensions,
  densityVariantPath,
} from "../framework/compiler/raster-assets.ts";
import {
  PAK_DTYPE,
  KEY_STYLES,
  decodePng,
  encodeImageEntry,
  encodeSpriteEntry,
  keyFont,
  keyImage,
  keySprite,
  pack,
  placeholderImage,
  type PakBlob,
} from "../framework/compiler/pak.ts";
import { checkAppletBundle, checkAppletSources, formatAppletDiagnostics } from "./applet-check.ts";

const ROOT = resolvePath(fileURLToPath(new URL("..", import.meta.url))); // pocketjs/
let DIST = join(ROOT, "dist/");

interface PackageJson {
  name?: string;
}

const packageJson = await Bun.file(join(ROOT, "package.json")).json() as PackageJson;
const packageName = packageJson.name ?? "@pocketjs/framework";

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------

const args = process.argv.slice(2);
let extraChars = "";
let regularFontPath: string | undefined;
let boldFontPath: string | undefined;
let appArg = "";
let frameworkFlag: string | undefined;
let planPath: string | undefined;
let densityFlag: number | undefined;
let hzFlag: number | undefined;
let projectRoot = process.cwd();
let inputsFile: string | undefined;
let strictClasses = false;
let bakeFonts = true;
const buildInputs = new BuildInputs();
for (const a of args) {
  if (a.startsWith("--extra-chars=")) extraChars = a.slice("--extra-chars=".length);
  else if (a.startsWith("--font-regular=")) regularFontPath = resolvePath(a.slice("--font-regular=".length));
  else if (a.startsWith("--font-bold=")) boldFontPath = resolvePath(a.slice("--font-bold=".length));
  else if (a.startsWith("--framework=")) frameworkFlag = a.slice("--framework=".length);
  else if (a === "--config" || a.startsWith("--config=") || a === "--no-config") {
    throw new Error("PocketJS build: application configuration belongs in pocket.json; --config and --no-config were removed");
  }
  else if (a.startsWith("--plan=")) planPath = resolvePath(a.slice("--plan=".length));
  else if (a.startsWith("--project-root=")) projectRoot = resolvePath(a.slice("--project-root=".length));
  else if (a.startsWith("--outdir=")) DIST = resolvePath(a.slice("--outdir=".length)) + "/";
  else if (a.startsWith("--density=")) densityFlag = Number(a.slice("--density=".length));
  else if (a.startsWith("--hz=")) hzFlag = Number(a.slice("--hz=".length));
  else if (a.startsWith("--inputs-file=")) inputsFile = resolvePath(a.slice("--inputs-file=".length));
  else if (a === "--strict-classes") strictClasses = true;
  else if (a === "--no-bake-fonts") bakeFonts = false;
  else if (a === "--bake-fonts") bakeFonts = true;
  else if (!a.startsWith("-")) appArg = a;
}

let buildPlan: ResolvedBuildPlan | undefined;
if (planPath) {
  buildPlan = await Bun.file(planPath).json() as ResolvedBuildPlan;
  if (!verifyPlanHash(buildPlan) || !verifyPlanProfile(buildPlan)) {
    throw new Error(`PocketJS build: invalid ResolvedBuildPlan checksum in ${planPath}`);
  }
  if (buildPlan.target.hostAbi !== POCKET_BINDING_GENERATION) {
    throw new Error(`PocketJS build: binding generation ${buildPlan.target.hostAbi} is unsupported; rebuild plan for ${POCKET_BINDING_GENERATION}`);
  }
  if (frameworkFlag) {
    throw new Error("PocketJS build: --framework cannot override a ResolvedBuildPlan");
  }
  appArg = resolvePath(projectRoot, buildPlan.app.entry);
  // Model lowering reads the application's manifest before transform caching.
  // A frozen plan must reject a later change to that compiler configuration.
  const model = modelConfiguration(appArg);
  const currentApp = model.directory ? (await Bun.file(join(model.directory, "pocket.json")).json()).app ?? {} : {};
  if ((currentApp.aot === true) !== (buildPlan.app.aot === true)
    || model.mode !== (buildPlan.app.model ?? "rust")
    || model.recursionLimit !== (buildPlan.app.recursionLimit ?? 256)
    || model.mode === "compiled" && currentApp.framework !== buildPlan.app.framework) {
    throw new Error("PocketJS build: model settings differ from the ResolvedBuildPlan; resolve a new plan before building");
  }
}

if (!appArg) {
  console.error("usage: bun tools/build.ts <app.tsx | app name> [--plan=<resolved-plan.json>] [--framework=solid|vue-vapor|octane] [--extra-chars=...] [--density=N] [--hz=N]");
  process.exit(1);
}

const requestedEntry = resolveSourceEntry(appArg, ROOT);
buildInputs.optional(join(projectRoot, "tsconfig.json"));
// The public compiler passes a frozen plan. Low-level source builds read the
// matching application manifest so they bake the same application theme.
if (!buildPlan) modelConfiguration(requestedEntry);
let appProjectRoot = projectRoot;
const sourceContent = buildPlan ? undefined : sourceAppContent(requestedEntry, {
  frameworkRoot: ROOT, projectRoot, onRead: path => buildInputs.add(path),
  onAppRoot: path => { appProjectRoot = path; },
});
const appContent = buildPlan ? buildPlan.app : sourceContent!;
/** The worker domain: the frozen plan's, or the source manifest's. */
const workerDeclaration = buildPlan ? buildPlan.domains?.worker : sourceContent?.domains?.worker;
if (appContent.theme !== undefined) {
  const diagnostics: ContractDiagnostic[] = [];
  validateSchema(appContent.theme, animationThemeSchema, "/app/theme", diagnostics);
  if (diagnostics.length) throw new Error(diagnostics.map(item => `${item.path}: ${item.message}`).join("; "));
}
const framework: PocketFramework = frameworkFlag
  ? parseFramework(frameworkFlag, "--framework")
  : parseFramework(appContent.framework, buildPlan ? "ResolvedBuildPlan" : "pocket.json");
const frameworkConfig = FRAMEWORKS[framework];
const entry = frameworkVariantPath(requestedEntry, framework);
const appName = buildPlan?.app.output ?? sourceOutputName(requestedEntry, ROOT);
// A resolved plan names the exact artifact. Low-level demo builds retain the
// framework suffix so multiple framework variants can coexist in dist/.
const outName = buildPlan ? appName : `${appName}${frameworkConfig.outputSuffix}`;
// Raster density: a resolved plan owns it; --density=N serves hosts whose
// viewport is not a fixed platform contract (the desktop widget shell runs
// arbitrary window sizes on 2x displays, which no target profile names).
if (buildPlan && densityFlag !== undefined) {
  throw new Error("PocketJS build: --density cannot override a ResolvedBuildPlan");
}
if (densityFlag !== undefined && (!Number.isInteger(densityFlag) || densityFlag < 1 || densityFlag > 255)) {
  throw new Error("PocketJS build: --density wants an integer from 1 through 255");
}
const rasterDensity = buildPlan?.viewport.rasterDensity ?? densityFlag ?? 1;

// Tick rate: the realm's virtual-time step, baked into the bundle because
// every ms-to-frame conversion in the framework resolves against it. An
// software profile owns the rate; low-level builds may still pass --hz.
if (hzFlag !== undefined && (!Number.isInteger(hzFlag) || hzFlag < 1 || hzFlag > 240)) {
  throw new Error("PocketJS build: --hz wants an integer from 1 through 240");
}
if (buildPlan && hzFlag !== undefined && hzFlag !== buildPlan.profile.tickHz) {
  throw new Error("PocketJS build: --hz cannot override the resolved software profile");
}
const tickHz = buildPlan?.profile.tickHz ?? hzFlag ?? 60;
console.log(
  `PocketJS build: ${appName} (${entry}, framework=${framework}` +
    `${tickHz === 60 ? "" : `, ${tickHz}Hz`}` +
    `${buildPlan ? `, target=${buildPlan.target.id}, raster=${rasterDensity}x, plan=${buildPlan.planHash.slice(0, 20)}…` : ""})`,
);

// ---------------------------------------------------------------------------
// pass 1 — transform & collect over the entry's import graph
// ---------------------------------------------------------------------------

/** Extract import/re-export specifiers (our own code style — no dynamic import). */
function importSpecifiers(src: string): string[] {
  const out: string[] = [];
  const re = /(?:^|\n)\s*(?:import|export)\b[^;'"]*?from\s*(["'])([^"']+)\1|(?:^|\n)\s*import\s*(["'])([^"']+)\3/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src))) out.push(m[2] ?? m[4]);
  return out;
}

/** Resolve a relative import the SAME way pass 2's Bun.build does (extension
 *  remapping like `./card.js` -> card.tsx included), so the two passes agree
 *  on the module graph by construction. */
function resolveImport(fromFile: string, spec: string): string | null {
  if (spec === packageName || spec.startsWith(packageName + "/")) {
    const exported = packagePath(spec, framework);
    return exported && /\.tsx?$/.test(exported) ? exported : null;
  }
  if (!spec.startsWith("./") && !spec.startsWith("../") && !spec.startsWith("/")) return null; // external bare
  const model = framework === "solid" ? resolveSolidAotModel(fromFile, spec, entry) : undefined;
  if (model) return model.endsWith(".d.ts") ? null : model;
  let resolved: string;
  try {
    resolved = Bun.resolveSync(spec, dirname(fromFile));
  } catch {
    return null;
  }
  return (/\.tsx?$/.test(resolved) || resolved.endsWith(".vue")) && !resolved.endsWith(".d.ts") ? frameworkVariantPath(resolved, framework) : null;
}

const classStrings: string[] = [];
const literalSites: Array<{ file: string; site: LiteralSite }> = [];
const seenClass = new Set<string>();
const codepoints = new Set<number>();
const visited = new Set<string>();
const visitedSources = new Map<string, string>();

async function walk(file: string): Promise<void> {
  if (visited.has(file)) return;
  visited.add(file);
  // Never scan the compiled-styles module: its literals ARE the compiled
  // class names, and collecting them again would feed the compiler its own
  // output [R]. Other generated modules (e.g. the launcher's registry) are
  // ordinary app data whose literals — cover asset paths, title glyphs —
  // pass 1 must see like any hand-written module's.
  if (file.replace(/\\/g, "/").endsWith("/styles.generated.ts")) return;
  const src = await Bun.file(file).text();
  visitedSources.set(file, src);
  buildInputs.add(file);
  // Throws with a code frame on lint errors.
  const res = await transformFile(file, src, framework, { features: buildPlan?.features, entry });
  for (const s of res.classStrings) {
    if (!seenClass.has(s)) {
      seenClass.add(s);
      classStrings.push(s);
    }
  }
  for (const cp of res.textCodepoints) codepoints.add(cp);
  // The framework's own modules are not the app author's to fix.
  if (!file.startsWith(ROOT + "/framework/")) for (const site of res.literalSites) literalSites.push({ file, site });
  for (const spec of importSpecifiers(src)) {
    const dep = resolveImport(file, spec);
    if (dep) await walk(dep);
  }
}

// System layers the plan's capabilities bring (framework/src/system-layers.ts):
// a Solid app that declares "system.agent" gets the agent's overlay. It is
// walked here so pass 1 compiles its classes and glyphs, and imported ahead
// of the app's entry in pass 2 so it registers before the app mounts.
const systemLayers: string[] = [];
if (framework === "solid" && buildPlan?.features["system.agent"] === true) {
  systemLayers.push(join(ROOT, "framework/src/agent-layer.tsx"));
}
await walk(entry);
for (const layer of systemLayers) await walk(layer);
console.log(`  pass 1: ${visited.size} module(s), ${classStrings.length} candidate literal(s), ${codepoints.size} codepoint(s)`);

// ---------------------------------------------------------------------------
// compile styles + fonts + images
// ---------------------------------------------------------------------------

registerAnimationTheme(appContent.theme);
// Keyframe timelines are frame-baked; they must count frames at the same
// rate the realm ticks (transition-* stays in ms and converts at runtime).
setAnimationTickRate(tickHz);
const styles = compileClasses(classStrings);
const inlineTextUsed = addInlineTextFontSlots(styles, [...visitedSources].map(([path, source]) => ({ path, source })));
if (styles.records.length === 0) {
  console.warn("  tailwind: no class literals compiled — is the app unstyled?");
}
// A literal the compiler left out gives its node no style, and nothing at run
// time says so on a native host. Where the source put it tells two cases
// apart. In a `class` attribute it was meant as a class string, so each
// unsupported token is a finding. Anywhere else (a constant, a function that
// returns the class) it is reported only when it reads as a class string
// with a mistake in it, and it never fails the build.
{
  const shown = (file: string, site: LiteralSite): string => {
    const base = projectRoot.endsWith("/") ? projectRoot : projectRoot + "/";
    return `${file.startsWith(base) ? file.slice(base.length) : file}:${site.line}:${site.column}`;
  };
  const utilities = (unknown: string[]): string =>
    `unknown ${unknown.length === 1 ? "utility" : "utilities"} ${unknown.join(", ")}`;
  const findings: string[] = [];
  const suspects: string[] = [];
  for (const { file, site } of literalSites) {
    if (site.literal in styles.ids) continue;
    if (site.inClass) {
      const unknown = unknownUtilities(site.literal);
      if (unknown.length > 0) findings.push(`${shown(file, site)}: class "${site.literal}" does not compile: ${utilities(unknown)}`);
    } else {
      const unknown = suspectClassLiteral(site.literal);
      if (unknown) suspects.push(`${shown(file, site)}: "${site.literal}" reads as a class string and does not compile: ${utilities(unknown)}`);
    }
  }
  for (const line of suspects) console.warn(`  warning: ${line}`);
  if (strictClasses && findings.length > 0) {
    for (const line of findings) console.error(`error: ${line}`);
    console.error(`PocketJS build: ${findings.length} class literal(s) do not compile. The supported utilities are listed in the styling reference.`);
    process.exit(1);
  }
  for (const line of findings) console.warn(`  warning: ${line}`);
}

const generatedStyles = generateStylesModule(styles, inlineTextUsed);
// Pass 2 receives this build's style table through jsxPlugin. The copy beside
// the bundle is for inspection and for tools that bundle the framework with a
// given table (the site's playground runtimes); nothing is written into the
// framework directory.
const generatedPath = `${DIST}${outName}.styles.ts`;
await Bun.write(generatedPath, generatedStyles);
console.log(
  `  tailwind: ${styles.records.length} style record(s), ${styles.anims.length} baked timeline(s), ` +
    `${Object.keys(styles.ids).length} literal(s) -> ${generatedPath}`,
);

// The font policy covers runtime data independently of source literals.
const fontsManifestPath = join(dirname(entry), "fonts.json");
buildInputs.optional(fontsManifestPath);
const shouldBakeFonts = bakeFonts || regularFontPath !== undefined || boldFontPath !== undefined;
const fontConfig = shouldBakeFonts
  ? readFontConfig(fontsManifestPath, path => buildInputs.add(path))
  : { fallbackTtfs: [] as string[], codepoints: [] as number[] };
const { fallbackTtfs } = fontConfig;
if (fallbackTtfs.length || fontConfig.codepoints.length)
  console.log(`  fonts: ${fallbackTtfs.length} fallback face(s), ${fontConfig.codepoints.length} declared characters`);

const atlases = shouldBakeFonts
  ? await bakeAtlases({
      codepoints: new Set([...codepoints, ...fontConfig.codepoints]),
      slots: styles.usedFontSlots,
      extraChars,
      rasterDensity,
      regularTtf: regularFontPath,
      boldTtf: boldFontPath,
      onRead: path => buildInputs.add(path),
      fallbackTtfs,
    })
  : [];
if (!shouldBakeFonts) {
  console.log("  fonts: host-native (skipped DCFA bitmap atlas baking)");
}
for (const a of atlases) {
  console.log(
    `  font: slot ${a.slot} (${a.px}px${a.bold ? " bold" : ""}) ${a.glyphCount} glyphs, ` +
      `cell ${a.cellW}x${a.cellH}, coverage ${a.coverageW}x${a.coverageH} @${a.rasterDensity}x, ${a.bytes.length} bytes`,
  );
}

// demo images: any collected literal ending .png/.svg is a candidate asset name
const blobs: PakBlob[] = [
  { key: KEY_STYLES, dtype: PAK_DTYPE.u8, data: styles.bin },
  ...(!shouldBakeFonts
    ? [{ key: "ui:fonts.host", dtype: PAK_DTYPE.u8, data: new Uint8Array([1]) }]
    : []),
  ...atlases.map((a) => ({ key: keyFont(a.slot), dtype: PAK_DTYPE.u8, data: a.bytes })),
];
const appDir = dirname(entry);
// Optional per-app sprite manifest: images listed here are baked as animated
// sprite-atlas entries (ui:sprite.<name>) instead of static images.
interface SpriteMeta {
  cols: number;
  rows: number;
  frames: number;
  step: number;
  /** spec PSM (default 8888); set 2 (PSM_4444) to halve atlas texmem on PSP. */
  psm?: number;
}
const spriteManifestPath = join(appDir, "sprites.json");
buildInputs.optional(spriteManifestPath);
const spriteMeta: Record<string, SpriteMeta> = existsSync(spriteManifestPath)
  ? (JSON.parse(await Bun.file(spriteManifestPath).text()) as Record<string, SpriteMeta>)
  : {};
// Optional per-app static-image meta: <appDir>/images.json maps an asset
// name to { linear?, psm? }. `linear` bakes IMG_FLAG_LINEAR so the core
// samples it bilinearly (rotated/scaled art — the launcher's covers); psm 2
// selects PSM_4444. Absent file or name = today's defaults, byte-identical.
interface ImageMeta {
  linear?: boolean;
  psm?: number;
}
const imageManifestPath = join(appDir, "images.json");
buildInputs.optional(imageManifestPath);
const imageMeta: Record<string, ImageMeta> = existsSync(imageManifestPath)
  ? (JSON.parse(await Bun.file(imageManifestPath).text()) as Record<string, ImageMeta>)
  : {};
const imageNames = classStrings.filter((s) => /^[\w./-]+\.(?:png|svg)$/i.test(s));
for (const name of imageNames) {
  const candidates = [join(appDir, name), join(ROOT, "assets/images/", name), join(ROOT, "assets/", name)];
  candidates.forEach(path => buildInputs.optional(path));
  const found = candidates.find((c) => existsSync(c));
  let img;
  if (found) {
    if (/\.svg$/i.test(found)) {
      img = bakeSvg(await Bun.file(found).text(), rasterDensity);
      console.log(
        `  image: ${name} <- ${found} (${img.width}x${img.height}, svg @${rasterDensity}x)`,
      );
    } else {
      const base = decodePng(new Uint8Array(await Bun.file(found).arrayBuffer()));
      // Static images and sprite atlases share the same @Nx convention. A
      // sprite's frame grid stays logical because every atlas dimension is
      // scaled by the same integer density.
      const variant = densityVariantPath(found, rasterDensity);
      buildInputs.optional(variant);
      if (variant !== found && existsSync(variant)) {
        const highDensity = decodePng(new Uint8Array(await Bun.file(variant).arrayBuffer()));
        assertDensityVariantDimensions(base, highDensity, rasterDensity, found, variant);
        img = highDensity;
        console.log(
          `  image: ${name} <- ${variant} (${img.width}x${img.height}, @${rasterDensity}x for ${base.width}x${base.height})`,
        );
      } else {
        img = base;
        console.log(
          `  image: ${name} <- ${found} (${img.width}x${img.height}` +
            `${rasterDensity > 1 ? `, 1x fallback (no ${variant})` : ""})`,
        );
      }
    }
  } else {
    img = placeholderImage();
    console.log(`  image: ${name} not found (tried ${candidates.join(", ")}) — baking a 32x32 placeholder`);
  }
  const sp = spriteMeta[name];
  if (sp) {
    blobs.push({
      key: keySprite(name),
      dtype: PAK_DTYPE.u8,
      data: encodeSpriteEntry(
        {
          atlasW: img.width,
          atlasH: img.height,
          frameCount: sp.frames,
          cols: sp.cols,
          frameStep: sp.step,
          rgba: img.rgba,
        },
        sp.psm ?? PSM.PSM_8888,
      ),
    });
    console.log(`  sprite: ${name} (${sp.frames} frames, ${sp.cols} cols, step ${sp.step}, psm ${sp.psm ?? PSM.PSM_8888})`);
  } else {
    const meta = imageMeta[name];
    const flags = meta?.linear ? IMG_FLAG_LINEAR : 0;
    blobs.push({
      key: keyImage(name),
      dtype: PAK_DTYPE.u8,
      data: encodeImageEntry(img, meta?.psm ?? PSM.PSM_8888, flags),
    });
    if (flags) console.log(`  image: ${name} sampled linear (images.json)`);
  }
}

// Optional per-app raw-blob manifest: <appDir>/pak.json lists PREBAKED binary
// entries (e.g. apps/zoomlab's committed TILESET pyramids from gen-assets.ts)
// appended verbatim as u8 blobs. This keeps expensive offline bakes out of the
// build: the build just splices bytes it can't (and needn't) regenerate.
const pakManifestPath = join(appDir, "pak.json");
buildInputs.optional(pakManifestPath);
if (existsSync(pakManifestPath)) {
  const rawEntries = JSON.parse(await Bun.file(pakManifestPath).text()) as Array<{ key: string; file: string }>;
  let rawBytes = 0;
  for (const e of rawEntries) {
    const basePath = join(appDir, e.file);
    if (!existsSync(basePath)) {
      console.error(`  pak.json: ${e.key} -> ${basePath} missing (re-run the app's gen-assets baker?)`);
      process.exit(1);
    }
    const densityPath = densityVariantPath(basePath, rasterDensity);
    buildInputs.add(basePath);
    buildInputs.optional(densityPath);
    const path = densityPath !== basePath && existsSync(densityPath) ? densityPath : basePath;
    const data = new Uint8Array(await Bun.file(path).arrayBuffer());
    blobs.push({ key: e.key, dtype: PAK_DTYPE.u8, data });
    rawBytes += data.length;
    if (path !== basePath) {
      console.log(`  raw: ${e.key} <- ${path} (@${rasterDensity}x)`);
    }
  }
  console.log(`  raw: ${rawEntries.length} prebaked blob(s) from pak.json, ${rawBytes} bytes`);
}

const pak = pack(blobs);
await Bun.write(DIST + outName + ".pak", pak);
console.log(`  pak: ${blobs.length} entries, ${pak.length} bytes -> ${DIST}${outName}.pak`);

// ---------------------------------------------------------------------------
// pass 2 — bundle (served from the pass-1 cache)
// ---------------------------------------------------------------------------

// jsxPlugin owns dependency identity as well as framework aliases. In
// particular, external apps and renderer-solid.ts must share PocketJS's
// browser-mode Solid runtime even when the app has its own node_modules.
let bundleEntry = entry;
if (systemLayers.length > 0) {
  const entries = join(DIST, ".entries");
  mkdirSync(entries, { recursive: true });
  bundleEntry = join(entries, `${outName}.ts`);
  writeFileSync(bundleEntry, [...systemLayers, entry].map((file) => `import ${JSON.stringify(file)};\n`).join(""));
}
const result = await Bun.build({
  entrypoints: [bundleEntry],
  root: process.cwd(),
  outdir: DIST,
  naming: `${outName}.js`,
  format: "iife",
  target: "browser",
  // solid-js MUST resolve via its "browser" export condition — the "node"
  // condition serves dist/server.js (SSR build) where reactive updates
  // silently no-op. See tests/renderer.test.ts for the fail-fast guard.
  // Bun's bundler otherwise also enables the "development" condition, which
  // pulls Solid's dev builds and duplicates the root + universal runtimes.
  conditions: ["browser"],
  define: {
    "process.env.NODE_ENV": '"production"',
    __POCKET_TARGET__: JSON.stringify(buildPlan?.target.id ?? ""),
    __POCKET_HOST_ABI__: String(buildPlan?.target.hostAbi ?? POCKET_BINDING_GENERATION),
    __POCKET_FEATURES__: JSON.stringify(buildPlan?.features ?? {}),
    __POCKET_DOMAIN__: '"ui"',
    __POCKET_WORKER_DECLARATION__: JSON.stringify(workerDeclaration ?? null),
    // The modality and presentation the plan resolved; the runtime module
    // (@pocketjs/framework/modality) falls back to the portable PSP shape
    // when a bundle is built without a plan.
    __POCKET_MODALITY__: JSON.stringify(buildPlan?.modality ?? null),
    __POCKET_PRESENTATION__: JSON.stringify(buildPlan?.presentation.id ?? "default"),
    // The animation class the plan derived (contracts/spec/animation.ts);
    // a bundle built without a plan animates as a composited target.
    __POCKET_ANIMATION__: JSON.stringify(buildPlan?.animation ?? "composited"),
    __POCKET_PIXEL_RATIO__: String(rasterDensity),
    __POCKET_TICK_HZ__: String(tickHz),
    ...(framework === "vue-vapor"
      ? { document: "globalThis.__pocketDocument" }
      : {}),
  },
  minify: false,
  metafile: true,
  sourcemap: "none",
  plugins: [jsxPlugin(framework, {
    entry,
    features: buildPlan?.features,
    generatedStyles,
  })],
});
if (!result.success) {
  for (const log of result.logs) console.error(log);
  console.error("PocketJS build: pass 2 bundling failed");
  process.exit(1);
}
const bundle = result.outputs.find((o) => o.path.endsWith(".js"));
if (workerDeclaration) {
  const worker = await buildWorker({ declaration: workerDeclaration, projectRoot: appProjectRoot, outdir: DIST, output: outName });
  buildInputs.metafile(worker.metafile);
  console.log(`  worker: ${DIST}${outName}.worker.js`);
}
if (inputsFile) {
  buildInputs.metafile(result.metafile);
  await buildInputs.compiler([join(ROOT, "tools/build.ts"), join(ROOT, "tools/pocket.ts")], ROOT);
  await Bun.write(inputsFile, JSON.stringify(buildInputs.paths(), null, 2) + "\n");
}
const bundleBytes = bundle ? (await bundle.arrayBuffer()).byteLength : 0;
console.log(`  pass 2: ${DIST}${outName}.js (${bundleBytes} bytes)`);
// A Pocket Applet's code and bundle meet the applet rules
// (contracts/spec/applet.ts) or the build fails.
if (buildPlan?.applet) {
  const diagnostics = [
    ...checkAppletSources({
      projectRoot,
      entry: buildPlan.app.entry,
      applet: buildPlan.applet,
      capabilities: Object.keys(buildPlan.features),
    }),
    ...checkAppletBundle({ jsBytes: bundleBytes, pakBytes: pak.length }),
  ];
  if (diagnostics.length > 0) {
    console.error(formatAppletDiagnostics(outName, diagnostics));
    console.error("PocketJS build: the applet breaks the applet rules (docs/APPLETS.md)");
    process.exit(1);
  }
  console.log("  applet: rules pass");
}
console.log("PocketJS build: done");
