import { POCKET_BINDING_GENERATION } from "../contracts/spec/binding-generation.ts";
// tools/psp.ts <demo> | --pocket <app.pocket> [cargo args…] — compile the
// stock demo apps/<demo>/main.tsx with `pocket compile` into
// dist/<output>.pocket (or take the given package), then the EBOOT:
//   POCKETJS_EMBED_PACKAGE=<package> POCKETJS_PROFILE_RS=<export> cargo psp
// inside programs/psp/, with the environment tools/psp-toolchain.ts reads from the
// installed toolchain (PSP_SDK, QUICKJS_PREBUILT_LIB, cargo-psp on PATH) plus
// RUST_PSP_TARGET=programs/psp/targets/mipsel-sony-psp.json, RUST_PSP_ABORT_ONLY=1
// and RUSTFLAGS "-A linker-messages …". `pocket target add psp` installs the
// pinned Rust, cargo-psp, SDK and prebuilt QuickJS. The EBOOT embeds the
// package bytes and the exported profile; it encodes nothing at boot.
//
// A demo builds from its apps/<demo>/pocket.json (or the repository template);
// --framework=<id> replaces the manifest's framework, as the PPSSPP goldens do.
//
// --capture builds the E2E frame-dump EBOOT (cargo psp --features capture)
// and bakes the POCKETJS_CAPTURE_INPUT env ("frame:mask,…") into the binary —
// used by tests/e2e/ppsspp.ts, never by normal builds.
// --bench additionally enables native microsecond timing output to
// ms0:/PocketJS-bench.jsonl and implies --capture.
//
// --runtime builds the generic runtime instead of an app's EBOOT (cargo
// feature `runtime`, POCKETJS_EMBED_APP=0): no app is built or embedded, and
// the EBOOT reads app.pocket from its own folder at boot. tools/runtime/psp.ts
// runs this and collects the output.

import { $ } from "bun";
import { createHash } from "node:crypto";
import { existsSync, statSync, unlinkSync } from "node:fs";
import { dirname, resolve as resolvePath } from "node:path";
import { parseFramework, type PocketFramework } from "../framework/compiler/framework-choice.ts";
import {
  extractHostBuildInputs,
  hostBuildEnvironment,
} from "../framework/src/manifest/host-build-inputs.ts";
import { verifyPlanHash, type ResolvedBuildPlan } from "../framework/src/manifest/plan.ts";
import { resolvePspBuildToolchain } from "./psp-toolchain.ts";
import softwareProfile from "../profiles/psp.ts";
import runtimeProfile from "../profiles/psp-runtime.ts";
import type { RuntimeApplication, RuntimeBuildContext } from "../framework/src/runtime-config.ts";
import { hashPocketProfile } from "../framework/src/profile.ts";
import { prepareApplication } from "./build/inputs.ts";
import { compileDemoPackage, demoManifest } from "./build/programs/handheld-common.ts";
import { exportProfile } from "./profile-export.ts";

const pspUiDir = new URL("..", import.meta.url).pathname; // PocketJS/
const nativeDir = pspUiDir + "programs/psp/";
const pspTarget = resolvePath(pspUiDir, "tools/build/toolchains/psp/mipsel-sony-psp.json");

/** Production inputs retain the executor's immutable snapshot, including all sections. */
export function pspPackageInput(packagePath: string | undefined, outdir: string, context?: RuntimeBuildContext): RuntimeApplication | undefined {
  if (context) {
    if (packagePath) throw new Error("PSP recipe owns --pocket; supply it to the build executor");
    if (context.application && !existsSync(context.application.packagePath))
      throw new Error(`PSP captured package is missing: ${context.application.packagePath}`);
    return context.application;
  }
  if (!packagePath) return undefined; // A stock demo compiles its package first.
  return prepareApplication({ profile: softwareProfile, profileHash: hashPocketProfile(softwareProfile),
    hostAbi: POCKET_BINDING_GENERATION, dependencies: [] }, packagePath, outdir);
}

/** The manifest `tools/psp.ts <demo>` compiles: the demo's own, with a
 *  --framework override in place of its framework. */
export function pspDemoManifest(demo: string, framework?: string): Record<string, any> {
  const manifest = demoManifest(demo, framework);
  if (framework) manifest.app.framework = parseFramework(framework, "--framework");
  return manifest;
}

/** The compiled package `tools/psp.ts <demo>` embeds, under its output directory. */
export function pspDemoPackage(demo: string, outdir = `${pspUiDir}dist/`, framework?: string): string {
  return resolvePath(outdir, `${pspDemoManifest(demo, framework).app.output}.pocket`);
}

export function pspLauncherPackages(registry: string, requested = ""): string {
  if (!registry) {
    if (requested) throw new Error("--launcher-packages requires --launcher-registry");
    return "";
  }
  if (!existsSync(registry) || !statSync(registry).isFile()) throw new Error(`PSP launcher registry is missing: ${registry}`);
  const directory = resolvePath(requested || resolvePath(dirname(registry), "packages"));
  if (!existsSync(directory) || !statSync(directory).isDirectory()) throw new Error(`PSP launcher packages directory is missing: ${directory}`);
  return directory;
}

// ---------------------------------------------------------------------------
// CLI: first bare arg = app name; everything else is passed to cargo psp.
// ---------------------------------------------------------------------------

export async function buildPsp(argv: readonly string[], context?: RuntimeBuildContext): Promise<string> {
let appArg = "";
let capture = false;
let bench = false;
let frameworkFlag: string | undefined;
let planPath: string | undefined;
let packagePath: string | undefined;
let projectRoot = process.cwd();
let outputDir = pspUiDir + "dist/";
let skipBuild = false;
let launcherRegistry = "";
let launcherPackages = "";
let runtime = false;
const cargoArgs: string[] = [];
for (let index = 0; index < argv.length; index++) {
  const a = argv[index]!;
  if (a === "--capture") capture = true; // E2E frame-dump build (tests/e2e/ppsspp.ts)
  else if (a === "--bench") {
    bench = true;
    capture = true;
  }
  else if (a.startsWith("--framework=")) frameworkFlag = a.slice("--framework=".length);
  else if (a.startsWith("--config=") || a === "--no-config") {
    throw new Error("pocket.config.ts was removed; use pocket.json app.framework and app.theme");
  } else if (a.startsWith("--plan=")) planPath = resolvePath(a.slice("--plan=".length));
  else if (a === "--pocket" || a.startsWith("--pocket=")) {
    const value = a === "--pocket" ? argv[++index] : a.slice("--pocket=".length);
    if (!value || value.startsWith("--")) throw new Error("--pocket requires a compiled package path");
    packagePath = resolvePath(value);
  }
  // Multi-app embed (docs/LAUNCHER.md): the TSV registry tools/launcher.ts
  // emits; build.rs appends one embedded bundle per line after app 0.
  else if (a.startsWith("--launcher-registry=")) launcherRegistry = resolvePath(a.slice("--launcher-registry=".length));
  else if (a.startsWith("--launcher-packages=")) launcherPackages = resolvePath(a.slice("--launcher-packages=".length));
  else if (a.startsWith("--project-root=")) projectRoot = resolvePath(a.slice("--project-root=".length));
  else if (a.startsWith("--outdir=")) outputDir = resolvePath(a.slice("--outdir=".length)) + "/";
  else if (a === "--skip-build") skipBuild = true;
  else if (a === "--runtime") runtime = true;
  else if (!planPath && !runtime && !appArg && !a.startsWith("-")) appArg = a;
  else cargoArgs.push(a);
}
if (runtime && packagePath) throw new Error("PSP generic runtime cannot embed --pocket");
if (packagePath && (appArg || planPath || frameworkFlag))
  throw new Error("--pocket supplies the application and plan; do not override them");
if (planPath && !context) throw new Error("PocketJS psp: --plan is the build executor's input; compile the application and pass --pocket");
if (frameworkFlag && !appArg) throw new Error("PocketJS psp: --framework applies to a stock demo build");
let application = pspPackageInput(packagePath, outputDir, context);
launcherPackages = pspLauncherPackages(launcherRegistry, launcherPackages);
if (context && !runtime && !application) throw new Error("PSP native build requires an admitted package");
const selectedProfile = context?.profile ?? (runtime ? runtimeProfile : softwareProfile);
const features = [capture ? "capture" : "", bench ? "bench" : "", runtime ? "runtime" : ""].filter(Boolean);
if (features.length > 0) cargoArgs.push("--features", features.join(","));
if (runtime && (appArg || planPath || launcherRegistry)) {
  console.error("PocketJS psp: --runtime builds an EBOOT without an app; give no app, --plan or --launcher-registry");
  process.exit(1);
}
if (!appArg && !application && !runtime) {
  console.error("usage: bun tools/psp.ts <demo> | --pocket <application.pocket> [--framework=<id>] [--capture|--bench] [cargo args…]   e.g. bun tools/psp.ts hero --release");
  process.exit(1);
}
// Reject an unknown demo before resolving a toolchain.
const demoManifestInput = !application && !runtime ? pspDemoManifest(appArg, frameworkFlag) : undefined;

// The installed toolchain, or a diagnostic naming `pocket target add psp`.
let toolchain: ReturnType<typeof resolvePspBuildToolchain>;
try {
  toolchain = resolvePspBuildToolchain();
} catch (error) {
  console.error(`PocketJS psp: ${error instanceof Error ? error.message : String(error)}`);
  process.exit(1);
}

// ---------------------------------------------------------------------------
// 1. A stock demo compiles to dist/<output>.pocket; --skip-build reuses it.
// The EBOOT embeds that package exactly as it embeds a --pocket input.
// ---------------------------------------------------------------------------

if (runtime) console.log("PocketJS psp: building the generic runtime (no app; reads app.pocket)");
if (demoManifestInput) {
  console.log(`PocketJS psp: compiling demo "${appArg}" (framework=${demoManifestInput.app.framework ?? "solid"})`);
  application = pspPackageInput(await compileDemoPackage("psp", demoManifestInput, outputDir, skipBuild), outputDir);
  projectRoot = pspUiDir;
}
if (application) {
  planPath = application.planPath;
  outputDir = application.directory + "/";
}

let buildPlan: ResolvedBuildPlan | undefined;
if (planPath) {
  buildPlan = await Bun.file(planPath).json() as ResolvedBuildPlan;
  if (!verifyPlanHash(buildPlan) || buildPlan.target.id !== selectedProfile.id) {
    throw new Error(`PocketJS psp: invalid PSP ResolvedBuildPlan at ${planPath}`);
  }
}

const app = buildPlan ? resolvePath(projectRoot, buildPlan.app.entry) : "";
const framework: PocketFramework = parseFramework(buildPlan?.app.framework, "ResolvedBuildPlan");
const outputApp = buildPlan?.app.output ?? "";
cargoArgs.push("-p", "pocketjs-psp", "--bin", "pocketjs-psp");

// ---------------------------------------------------------------------------
// 1b. Per-app XMB metadata: <app dir>/psp/Psp.toml -> programs/psp/Psp.toml.
// cargo-psp reads Psp.toml from its CWD (programs/psp/) and packs it into
// PARAM.SFO / ICON0 / PIC1. The fragment lives NEXT TO THE APP ENTRY —
// <entry dir>/psp/Psp.toml, e.g. apps/<demo>/psp/Psp.toml (`app` is the
// plan entry's absolute path). It keeps its art beside it with
// relative paths; they are rewritten absolute here. No fragment => the
// generated file is REMOVED, so one app's title/cover never leaks into
// another app's EBOOT. programs/psp/Psp.toml is build output (gitignored).
// ---------------------------------------------------------------------------
const GENERATED_MARK = "# GENERATED by tools/psp.ts";
const fragmentBase = buildPlan
  ? resolvePath(projectRoot, buildPlan.app.entry, "..", "psp")
  : `${pspUiDir}apps/${app.replace(/-main$/, "")}/psp`;
// A demo built through a non-default framework may ship its own cover set so
// the XMB tells the twins apart (<app>/psp/<framework>/); the shared fragment
// one level up stays the default when there is no such variant.
const frameworkFragmentHome = `${fragmentBase}/${framework}`;
const fragmentHome = existsSync(`${frameworkFragmentHome}/Psp.toml`)
  ? frameworkFragmentHome
  : fragmentBase;
const xmbFragment = runtime ? `${pspUiDir}programs/psp/runtime/Psp.toml` : `${fragmentHome}/Psp.toml`;
const xmbFragmentLabel = xmbFragment.startsWith(pspUiDir)
  ? xmbFragment.slice(pspUiDir.length)
  : xmbFragment;
const generatedPspToml = `${nativeDir}Psp.toml`;
const generatedExisting =
  existsSync(generatedPspToml) && (await Bun.file(generatedPspToml).text()).startsWith(GENERATED_MARK);
if (existsSync(xmbFragment)) {
  if (existsSync(generatedPspToml) && !generatedExisting) {
    console.error(
      "PocketJS psp: programs/psp/Psp.toml exists but was not generated by this script — " +
        "per-app XMB metadata lives in <app dir>/psp/Psp.toml; move or delete the file to continue.",
    );
    process.exit(1);
  }
  const fragDir = `${fragmentHome}/`;
  const rewritten = (await Bun.file(xmbFragment).text()).replace(
    /^(\s*\w+_(?:png|pmf|at3))(\s*=\s*")(?!\/)([^"]+)(")/gm,
    (_m, key, eq, rel, close) => `${key}${eq}${fragDir}${rel}${close}`,
  );
  // Every asset key must have resolved to an absolute path that exists —
  // single-quoted strings, `~`, or drive paths would otherwise slip through
  // the rewrite and cargo-psp would pack missing/stale art without a word.
  const badAssets: string[] = [];
  for (const m of rewritten.matchAll(/^\s*(\w+_(?:png|pmf|at3))\s*=\s*(['"])(.*)\2\s*$/gm)) {
    if (!m[3].startsWith("/") || !existsSync(m[3])) badAssets.push(`${m[1]} = ${m[3]}`);
  }
  if (badAssets.length > 0) {
    console.error(
      `PocketJS psp: XMB asset path(s) in ${xmbFragmentLabel} did not resolve:\n` +
        badAssets.map((b) => `  ${b}`).join("\n") +
        `\n(use double-quoted paths relative to the fragment's directory)`,
    );
    process.exit(1);
  }
  await Bun.write(
    generatedPspToml,
    `${GENERATED_MARK} from ${xmbFragmentLabel} — do not edit.\n${rewritten}`,
  );
  console.log(`PocketJS psp: XMB metadata from ${xmbFragmentLabel}`);
} else if (generatedExisting) {
  unlinkSync(generatedPspToml); // a previous demo's cover must not leak into this EBOOT
} else if (existsSync(generatedPspToml)) {
  console.log("PocketJS psp: note — hand-authored programs/psp/Psp.toml found; cargo-psp will apply it.");
}

// ---------------------------------------------------------------------------
// 1b. Switch-veil logo (docs/PLATFORM.md): rasterize the brand mark to a 128×128
// RGBA texture the host embeds and direct-draws during guest swaps. Baked on
// every build (deterministic, ~10 ms); single-app EBOOTs embed it too but
// never switch, so it stays dormant 64 KB of rodata.
// ---------------------------------------------------------------------------

const veilLogoPath = `${outputDir}veil-logo.raw`;
{
  // The brand PNGs carry an opaque white plate and the SVG uses stroked
  // shapes our baker does not rasterize — so the mark is drawn here from
  // its exact geometry (assets/brand/pocketjs-avatar-white-minimal.svg, in
  // its 1024 viewBox): a 76-wide stroked round-rect, the face circle, two
  // rounded bars. White with real alpha; the veil tints via vertex color.
  const { resizeBilinear } = await import("./image-resize.ts");
  const S = 512; // supersample grid, downscaled 4x for anti-aliasing
  const k = S / 1024;
  const sdRoundRect = (px: number, py: number, cx: number, cy: number, hw: number, hh: number, r: number) => {
    const qx = Math.abs(px - cx) - (hw - r);
    const qy = Math.abs(py - cy) - (hh - r);
    const ax = Math.max(qx, 0);
    const ay = Math.max(qy, 0);
    return Math.hypot(ax, ay) + Math.min(Math.max(qx, qy), 0) - r;
  };
  const big = new Uint8Array(S * S * 4);
  for (let y = 0; y < S; y++) {
    for (let x = 0; x < S; x++) {
      const px = (x + 0.5) / k;
      const py = (y + 0.5) / k;
      // Stroked outline: |distance to the round-rect edge| <= 38.
      const outline = Math.abs(sdRoundRect(px, py, 512, 512, 414, 246, 147)) - 38;
      const face = Math.hypot(px - 338, py - 512) - 92;
      const bar1 = sdRoundRect(px, py, 664, 449, 152, 35, 35);
      const bar2 = sdRoundRect(px, py, 614, 583, 102, 35, 35);
      const d = Math.min(outline, face, bar1, bar2);
      // 1.5px-wide edge ramp in supersample space (~2px at 1024 scale).
      const a = Math.round(255 * Math.min(1, Math.max(0, 0.5 - d * k / 1.5)));
      const o = (y * S + x) * 4;
      big[o] = 255;
      big[o + 1] = 255;
      big[o + 2] = 255;
      big[o + 3] = a;
    }
  }
  await Bun.write(veilLogoPath, resizeBilinear(big, S, S, 128, 128));
}

const rustflags = [
  process.env.RUSTFLAGS,
  // Benign +abicalls(newlib) vs +noabicalls(rust-psp) linker warnings are
  // suppressed by default — set PSPJS_SHOW_LINKER_MESSAGES=1 for raw output.
  process.env.PSPJS_SHOW_LINKER_MESSAGES === "1" ? undefined : "-A linker-messages",
  "-A unexpected-cfgs",
  "-A unstable-name-collisions",
]
  .filter(Boolean)
  .join(" ");

// build.rs embeds the exported profile module. The executor exports it into
// its outdir; a command-line build exports the selected profile here.
const profileExportDirectory = context?.outdir ?? `${nativeDir}target/pocket-profile/${selectedProfile.id}`;
if (!context) {
  exportProfile({ profile: selectedProfile, profileHash: hashPocketProfile(selectedProfile),
    hostAbi: POCKET_BINDING_GENERATION, dependencies: [] }, profileExportDirectory);
}
const hostEnvironment = buildPlan
  ? hostBuildEnvironment(extractHostBuildInputs(buildPlan, { expectedTarget: selectedProfile.id }), {
      outputDirectory: outputDir,
      embedApp: true,
      profileExportDirectory,
    })
  : {
      // The generic runtime: no application is embedded.
      POCKETJS_PROFILE_EXPORT_DIR: profileExportDirectory,
      POCKETJS_PROFILE_RS: `${profileExportDirectory}/pocket_profile.rs`,
      POCKETJS_APP_OUTPUT: "",
      POCKETJS_EMBED_APP: "0",
      POCKETJS_OUTPUT_DIR: outputDir,
      POCKETJS_TARGET: selectedProfile.id,
      POCKETJS_HOST_ABI: String(POCKET_BINDING_GENERATION),
      POCKETJS_LOGICAL_WIDTH: "480",
      POCKETJS_LOGICAL_HEIGHT: "272",
      POCKETJS_PHYSICAL_WIDTH: "480",
      POCKETJS_PHYSICAL_HEIGHT: "272",
      POCKETJS_PRESENTATION: "native",
      POCKETJS_RASTER_DENSITY: "1",
    };

const env = {
  POCKETJS_OFFLOAD_SLOT: buildPlan?.features["io.offload"] ? createHash("sha256").update(buildPlan.app.id).digest("hex").slice(0, 16) : "",
  ...toolchain.environment,
  RUSTFLAGS: rustflags,
  RUST_PSP_TARGET: pspTarget,
  // panic-abort EBOOTs: no panic_unwind/libunwind in build-std.
  RUST_PSP_ABORT_ONLY: "1",
  // Keep PSP dev builds fast (opt-level 0 is unusably slow on hardware).
  CARGO_TARGET_DIR: `${nativeDir}target`,
  CARGO_PROFILE_DEV_OPT_LEVEL: process.env.CARGO_PROFILE_DEV_OPT_LEVEL ?? "3",
  ...hostEnvironment,
  // The build script embeds these original bytes; it has no raw-bundle path.
  POCKETJS_EMBED_PACKAGE: application ? resolvePath(application.packagePath) : "",
  POCKETJS_LAUNCHER_PACKAGES: launcherPackages,
  // Scripted capture input + per-demo capture window, baked into the EBOOT
  // by programs/psp/build.rs (only consumed under --capture; harmless otherwise).
  // Explicit so stale values never linger in the cargo fingerprint.
  POCKETJS_CAPTURE_INPUT: process.env.POCKETJS_CAPTURE_INPUT ?? "",
  POCKETJS_TRACE: process.env.POCKETJS_TRACE ?? "",
  POCKETJS_CAP_START: process.env.POCKETJS_CAP_START ?? "",
  POCKETJS_CAP_N: process.env.POCKETJS_CAP_N ?? "",
  POCKETJS_ARENA_BYTES: process.env.POCKETJS_ARENA_BYTES ?? "",
  POCKETJS_BENCH_DUMP_FRAMES: process.env.POCKETJS_BENCH_DUMP_FRAMES ?? "",
  // Multi-app embed (docs/LAUNCHER.md): empty = single-app table of one.
  POCKETJS_LAUNCHER_REGISTRY: launcherRegistry,
  // Switch-veil logo texture (docs/PLATFORM.md), baked above.
  POCKETJS_VEIL_LOGO: veilLogoPath,
};

// Trace bakes dprintln onto the DEBUG SCREEN — over the switch veil it reads
// as a log stream fighting the animation, and from the XMB (no host0:) it
// exercises IO paths PSPLINK sessions never see. A release EBOOT with trace
// is almost always a deployment mistake: say so, loudly (this exact slip
// shipped once).
if ((process.env.POCKETJS_TRACE ?? "") !== "" && outputProfile(cargoArgs) === "release") {
  console.warn(
    "\n!!  PocketJS psp: POCKETJS_TRACE is baked into a RELEASE build — debug-screen logs" +
      "\n!!  will draw over the app (and the switch veil). Ship traceless; trace is for" +
      "\n!!  PSPLINK dev loops.\n",
  );
}

function outputProfile(args: string[]): string {
  const inlineProfile = args.find((arg) => arg.startsWith("--profile="));
  if (inlineProfile) return inlineProfile.slice("--profile=".length);
  const profileFlag = args.indexOf("--profile");
  if (profileFlag !== -1 && args[profileFlag + 1]) return args[profileFlag + 1];
  return args.includes("--release") || args.includes("-r") ? "release" : "debug";
}

console.log(`PocketJS psp: cargo psp (app=${runtime ? "none, runtime" : outputApp})`);
if (context) await context.run([toolchain.rustup, "run", toolchain.rustToolchain, "cargo", "psp", ...cargoArgs], { cwd: nativeDir, env });
else await $`${toolchain.rustup} run ${toolchain.rustToolchain} cargo psp ${cargoArgs}`.cwd(nativeDir).env(env);

const profile = outputProfile(cargoArgs);
const { verifyPspPrx } = await import("./psp-prx.ts");
verifyPspPrx(new Uint8Array(await Bun.file(`${nativeDir}target/mipsel-sony-psp/${profile}/pocketjs-psp.prx`).arrayBuffer()));
const binEboot = `${nativeDir}target/mipsel-sony-psp/${profile}/pocketjs-psp.EBOOT.PBP`;
const conventionalEboot = `${nativeDir}target/mipsel-sony-psp/${profile}/EBOOT.PBP`;
if (existsSync(binEboot)) {
  await Bun.write(conventionalEboot, await Bun.file(binEboot).arrayBuffer());
}
console.log(`output: ${conventionalEboot}`);

return conventionalEboot;
}

if (import.meta.main) await buildPsp(Bun.argv.slice(2));
