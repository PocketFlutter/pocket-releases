import { describe, expect, test } from "bun:test";
import { compileClasses, DEFAULT_FONT_SLOT, fontSlotFor, generateStylesModule } from "../../framework/compiler/tailwind.ts";
import { addInlineTextFontSlots } from "../inline-text-slots.ts";

describe("InlineText font-slot ablation", () => {
  test("plain modules and re-export barrels add no atlas slots or role metadata", () => {
    const styles = compileClasses([]);
    const used = addInlineTextFontSlots(styles, [
      { path: "/app/page.tsx", source: `import { Text } from "@pocket/ui"; <Text>plain</Text>;` },
      { path: "/app/ui/index.ts", source: `export { InlineText, inlineFontSlot } from "@pocket/ui";` },
      { path: "/sdk/packages/pocket_ui/src/inline-text.tsx", source: `export function InlineText() {}` },
    ]);
    expect(used).toBe(false);
    expect(styles.usedFontSlots).toEqual([DEFAULT_FONT_SLOT]);
    expect(generateStylesModule(styles, used)).toContain("INLINE_TEXT_FONT_SLOTS: Partial<Record<\"body\" | \"bodyBold\" | \"headingBold\" | \"ruby\", number>> = {};");
  });

  test("a consumer callsite bakes the four compiler-derived font roles", () => {
    const styles = compileClasses([]);
    const used = addInlineTextFontSlots(styles, [
      { path: "/app/rich.tsx", source: `import { InlineText, inlineFontSlot } from "@pocket/ui"; const slot = inlineFontSlot("body"); <InlineText source="x"/>;` },
    ]);
    expect(used).toBe(true);
    expect(styles.usedFontSlots).toEqual([
      fontSlotFor(12, false), fontSlotFor(16, false), fontSlotFor(16, true), fontSlotFor(18, true),
    ].sort((a, b) => a - b));
    const generated = generateStylesModule(styles, used);
    expect(generated).toContain(`body: ${fontSlotFor(16, false)},`);
    expect(generated).toContain(`bodyBold: ${fontSlotFor(16, true)},`);
    expect(generated).toContain(`headingBold: ${fontSlotFor(18, true)},`);
    expect(generated).toContain(`ruby: ${fontSlotFor(12, false)},`);
  });
});
