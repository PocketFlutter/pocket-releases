import { fontSlotFor, type CompiledStyles } from "../framework/compiler/tailwind.ts";

const REQUIRED_ROLES = {
  body: fontSlotFor(16, false),
  bodyBold: fontSlotFor(16, true),
  headingBold: fontSlotFor(18, true),
  ruby: fontSlotFor(12, false),
} as const;

/** Detect app-side JSX/callsites, not the InlineText definition or barrels. */
export function hasInlineTextCallsite(files: Iterable<{ path: string; source: string }>): boolean {
  for (const file of files) {
    const path = file.path.replace(/\\/g, "/");
    if (path.endsWith("/framework/src/inline-fonts.ts")
      || path.endsWith("/packages/pocket_ui/src/inline-text.tsx")
      || path.endsWith("/packages/pocket_ui/src/index.ts")) continue;
    const code = file.source
      .replace(/\/\*[\s\S]*?\*\//g, " ")
      .replace(/(^|[^:])\/\/.*$/gm, "$1 ");
    if (/<\s*InlineText\b/.test(code) || /\binlineFontSlot\s*\(/.test(code)) return true;
  }
  return false;
}

export function addInlineTextFontSlots(styles: CompiledStyles, files: Iterable<{ path: string; source: string }>): boolean {
  if (!hasInlineTextCallsite(files)) return false;
  const slots = new Set(styles.usedFontSlots);
  for (const slot of Object.values(REQUIRED_ROLES)) slots.add(slot);
  styles.usedFontSlots = [...slots].sort((a, b) => a - b);
  return true;
}

export function inlineTextRoleSlots(): typeof REQUIRED_ROLES { return REQUIRED_ROLES; }
