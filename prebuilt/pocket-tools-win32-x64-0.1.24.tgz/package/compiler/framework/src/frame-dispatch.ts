// Per-frame callback registry and deferred-press dispatch, shared by the Solid
// (frame.ts) and Vue Vapor (frame-vue-vapor.ts) frame pumps. The pumps own
// their framework's reactive scope and lifecycle; this module owns the order
// in which frame callbacks and deferred presses run.

import type { DeferredPress } from "./input.ts";
import type { NodeMirror } from "./native-tree.ts";

export type FrameCallback = (buttons: number) => void;

export interface FrameWorkOptions {
  /** Keep host frames flowing while this callback is useful. Defaults to true. */
  continuous?: boolean | (() => boolean);
  /** Optionally gate callback delivery and its continuous-work hint. */
  active?: boolean | (() => boolean);
}

type FrameWorkHint = { active: () => boolean; scope: "app" | "system" };
const workHints = new Set<FrameWorkHint>();
let appFramesSuspended = false;

/** Register an independently-owned callback's scheduler hint. */
export function registerFrameWorkHint(
  active: () => boolean,
  scope: "app" | "system" = "app",
): () => void {
  const hint = { active, scope };
  workHints.add(hint);
  return () => workHints.delete(hint);
}

/** Unknown or throwing predicates keep the runtime awake for safety. */
export function hasContinuousFrameWork(): boolean {
  for (const hint of workHints) {
    if (hint.scope === "app" && appFramesSuspended) continue;
    try {
      if (hint.active()) return true;
    } catch {
      return true;
    }
  }
  return false;
}

export function setAppFramesSuspended(suspended: boolean): void {
  appFramesSuspended = suspended;
}

/** The registrations one frame runs, frozen when the frame starts. */
export interface FrameSnapshot {
  readonly callbacks: readonly FrameCallback[];
  readonly placed: readonly (readonly [FrameCallback, NodeMirror])[];
}

/** Runs one deferred press; the Solid pump restores the node's list row. */
export type RunPress = (node: NodeMirror, invoke: () => void) => void;

export class FrameRegistry {
  private readonly callbacks = new Set<FrameCallback>();
  private readonly placed = new Map<FrameCallback, NodeMirror>();
  private readonly workDisposers = new Map<FrameCallback, () => void>();
  // Rebuilt after a registration changes and never mutated once built, so a
  // frame holding it keeps the set it started with.
  private snapshot: FrameSnapshot | null = null;

  /** Register `callback`; with `placement` its press joins the document-order
   *  queue at that node instead of running in registration order. */
  add(callback: FrameCallback, placement?: NodeMirror, options: FrameWorkOptions = {}, scope: "app" | "system" = "app"): () => void {
    const activeOption = options.active;
    const continuousOption = options.continuous;
    const active = typeof activeOption === "function"
      ? activeOption
      : () => activeOption ?? true;
    const continuous = typeof continuousOption === "function"
      ? continuousOption
      : () => continuousOption ?? true;
    const gated = activeOption === undefined
      ? callback
      : (buttons: number) => { if (active()) callback(buttons); };
    if (placement) this.placed.set(gated, placement);
    else this.callbacks.add(gated);
    this.snapshot = null;
    // Known-passive hooks remain in the dispatch registry, but need no entry
    // in the global scheduler scan. Keep dynamic predicates observable.
    if (continuousOption !== false && activeOption !== false && !this.workDisposers.has(gated)) {
      const unregisterWork = registerFrameWorkHint(() => active() && continuous(), scope);
      this.workDisposers.set(gated, unregisterWork);
    }
    return () => {
      const removed = this.callbacks.delete(gated);
      if (this.placed.delete(gated) || removed) this.snapshot = null;
      const disposeWork = this.workDisposers.get(gated);
      if (disposeWork) {
        disposeWork();
        this.workDisposers.delete(gated);
      }
    };
  }

  clear(): void {
    for (const dispose of this.workDisposers.values()) dispose();
    this.workDisposers.clear();
    this.callbacks.clear();
    this.placed.clear();
    this.snapshot = null;
  }

  /** Freeze registration before any callback can mount another handler. */
  freeze(): FrameSnapshot {
    return (this.snapshot ??= { callbacks: [...this.callbacks], placed: [...this.placed] });
  }
}

/**
 * One frame's input phase: gesture recognition (`beforeHooks`), the frozen
 * frame callbacks in registration order, then every deferred press — placed
 * callbacks and whatever `resolveInput` queued — in the live tree's document
 * order, parents before children and a node's presses in queue order. Presses
 * on nodes that left the tree are dropped.
 */
export function dispatchFrame(
  frame: FrameSnapshot,
  buttons: number,
  run: RunPress,
  beforeHooks?: (defer: DeferredPress) => void,
  resolveInput?: (defer: DeferredPress) => void,
): void {
  // Most frames defer nothing: allocate the queue on the first press.
  let pending: Map<NodeMirror, (() => void)[]> | undefined;
  const enqueue: DeferredPress = (node, invoke) => {
    pending ??= new Map();
    const entries = pending.get(node);
    if (entries) entries.push(invoke);
    else pending.set(node, [invoke]);
  };
  // Gesture recognition keeps its original phase; its declarative presses
  // join the ordered queue instead of running ahead of all input handlers.
  beforeHooks?.(enqueue);
  for (let i = 0; i < frame.callbacks.length; i++) frame.callbacks[i](buttons);
  for (let i = 0; i < frame.placed.length; i++) {
    const [callback, node] = frame.placed[i];
    enqueue(node, () => callback(buttons));
  }
  resolveInput?.(enqueue);
  if (!pending) return;
  // A component's setup order is not its position after a keyed move.
  // Snapshot the live mirror's document order before running any handlers.
  const queued = pending;
  const roots = new Set<NodeMirror>();
  for (const node of queued.keys()) {
    if (!(node as NodeMirror & { readonly isConnected: boolean }).isConnected) continue;
    let root = node;
    while (root.parent) root = root.parent;
    roots.add(root);
  }
  const ordered: [NodeMirror, () => void][] = [];
  const collect = (node: NodeMirror): void => {
    const entries = queued.get(node);
    if (entries) for (const invoke of entries) ordered.push([node, invoke]);
    for (const child of node.children) collect(child);
  };
  for (const root of roots) collect(root);
  for (const [node, invoke] of ordered) run(node, invoke);
}
