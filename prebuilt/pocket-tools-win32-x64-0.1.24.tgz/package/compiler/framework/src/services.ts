// Framework-neutral per-tick service pumps. UI lifecycle hooks are component
// scoped and differ between Solid, Vue Vapor and Octane; module Promise
// delivery is realm scoped and must not depend on any of them.
//
// Most apps keep the map empty. Unknown pumps report pending work by default;
// modules with a precise idle state can opt out of continuous scheduling.

type ServicePump = () => void;
type PendingWork = () => boolean;

const pumps = new Map<ServicePump, PendingWork>();

export function registerServicePump(pump: ServicePump, pending: PendingWork = () => true): () => void {
  pumps.set(pump, pending);
  return () => pumps.delete(pump);
}

/** Unknown pumps count as work until their owner unregisters them. */
export function hasPendingServiceWork(): boolean {
  for (const pending of pumps.values()) {
    try {
      if (pending()) return true;
    } catch {
      return true;
    }
  }
  return false;
}

export function runServicePumps(): void {
  if (pumps.size === 0) return;
  // A pump may remove itself while running; Map iteration safely advances to
  // the next entry without a snapshot allocation on this per-frame path.
  for (const pump of pumps.keys()) pump();
}
