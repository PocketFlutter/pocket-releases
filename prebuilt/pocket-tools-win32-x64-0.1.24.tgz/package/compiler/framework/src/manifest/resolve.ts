import { WORKER_RESOURCES } from "../../../contracts/spec/worker.ts";
import { isHostExtension, type HostExtension } from "./host-extension.ts";
import { hashPocketProfile, profileHashProjection } from "../profile.ts";
import { DYNAMIC_FORMS, PACKAGE_ROLES, TARGET_FORMS } from "../../../contracts/spec/platforms.ts";
import { deriveAnimationClass } from "../../../contracts/spec/animation.ts";
import { deriveModality, modalityMisses } from "../../../contracts/spec/modality.ts";
import type {
  ManifestViewport,
  PocketManifestV2,
  PresentationSpec,
} from "../../../contracts/spec/pocket-manifest.ts";
import {
  POCKET_PLATFORM_CONTRACTS,
  type FixedDisplayProfile,
  type PlatformContractRegistry,
  type PresentationMode,
  type TargetProfile,
  type Viewport,
} from "../../../contracts/spec/platforms.ts";
import {
  finalizeBuildPlan,
  type ResolvedBuildPlan,
  type ResolvedBuildPlanContent,
} from "./plan.ts";
import { validatePocketManifest, type ContractDiagnostic } from "./validate.ts";
import { POCKET_BINDING_GENERATION } from "../../../contracts/spec/binding-generation.ts";
import { appletManifestDiagnostics } from "../../../contracts/spec/applet.ts";

const AUXILIARY_DISPLAY = "display.auxiliary";
const AUXILIARY_TOUCH = "input.touch.auxiliary";

export interface ResolveBuildRequest {
  readonly target: string;
  /** Artifact selected by the caller. Omitted retains JavaScript guest plans. */
  readonly executionClass?: "guest" | "aot";
  /** Defaults to an ordinary application. System resolution assigns the
   *  System UI role before capability admission. */
  readonly role?: "application" | "systemUI";
  /** Versioned adapter input, interpreted only by its owner. */
  readonly hostExtension?: HostExtension;
}

export type ResolutionResult =
  | { readonly ok: true; readonly plan: ResolvedBuildPlan }
  | { readonly ok: false; readonly diagnostics: readonly ContractDiagnostic[] };

function capabilityPath(kind: "enhances" | "requires", index: number): string {
  return `/engine/capabilities/${kind}/${index}`;
}

function sameViewport(left: Viewport, right: Viewport): boolean {
  return left[0] === right[0] && left[1] === right[1];
}

/**
 * Native presentation fills the panel: one logical px = rasterDensity
 * physical px, with no letterbox. A panel is the same panel turned a quarter
 * turn, so a logical viewport that fills it in the transposed orientation
 * fills it too — that is how a portrait handheld hosts a landscape app. The
 * returned physical viewport is the panel as the app sees it (transposed
 * when the fit was transposed); `logicalViewports` stays the gate that says
 * which orientations a target's host can actually present.
 */
function nativeFill(logical: Viewport, rasterDensity: number, panel: Viewport): Viewport | null {
  const scaled: Viewport = [logical[0] * rasterDensity, logical[1] * rasterDensity];
  if (sameViewport(scaled, panel)) return [panel[0], panel[1]];
  if (sameViewport(scaled, [panel[1], panel[0]])) return [panel[1], panel[0]];
  return null;
}

function resolveFixedDisplay(
  requested: { logical: Viewport; presentation: PresentationMode },
  provided: FixedDisplayProfile,
  path: string,
  diagnostics?: ContractDiagnostic[],
): {
  logical: Viewport;
  physical: Viewport;
  presentation: PresentationMode;
  rasterDensity: number;
} | null {
  const { logical, presentation } = requested;
  let ok = true;
  if (!provided.logicalViewports.some((supported) => sameViewport(supported, logical))) {
    diagnostics?.push({
      code: "surface.logicalUnsupported",
      path: `${path}/logical`,
      message: `target does not support auxiliary logical viewport ${logical[0]}x${logical[1]}`,
    });
    ok = false;
  }
  if (!provided.presentations.includes(presentation)) {
    diagnostics?.push({
      code: "surface.presentationUnsupported",
      path: `${path}/presentation`,
      message: `target does not support ${JSON.stringify(presentation)} auxiliary presentation`,
    });
    ok = false;
  }
  let physical: Viewport = [provided.physicalViewport[0], provided.physicalViewport[1]];
  if (presentation === "native") {
    const fill = nativeFill(logical, provided.rasterDensity, provided.physicalViewport);
    if (fill === null) {
      diagnostics?.push({
        code: "surface.nativeMismatch",
        path,
        message: "native auxiliary presentation requires the logical viewport to fill the panel",
      });
      ok = false;
    } else {
      physical = fill;
    }
  }
  if (presentation === "integer-fit") {
    const x = provided.physicalViewport[0] / logical[0];
    const y = provided.physicalViewport[1] / logical[1];
    if (!Number.isInteger(x) || x < 1 || x !== y) {
      diagnostics?.push({
        code: "surface.integerFitMismatch",
        path,
        message: "integer-fit auxiliary presentation requires one positive integer scale on both axes",
      });
      ok = false;
    }
  }
  return ok
    ? {
        logical: [logical[0], logical[1]],
        physical,
        presentation,
        rasterDensity: provided.rasterDensity,
      }
    : null;
}

/** An adaptive auxiliary surface takes the first size the target offers
 *  inside its range, presented natively. */
function resolveAdaptiveDisplay(
  requested: { min: Viewport; max: Viewport },
  provided: FixedDisplayProfile,
  path: string,
  diagnostics?: ContractDiagnostic[],
): ReturnType<typeof resolveFixedDisplay> {
  const logical = provided.logicalViewports.find((size) => within(size, requested.min, requested.max));
  if (!logical) {
    diagnostics?.push({
      code: "surface.logicalUnsupported",
      path,
      message:
        `target offers no auxiliary logical viewport from ${requested.min[0]}x${requested.min[1]} ` +
        `through ${requested.max[0]}x${requested.max[1]}`,
    });
    return null;
  }
  return resolveFixedDisplay({ logical, presentation: "native" }, provided, path, diagnostics);
}

/** The app's viewport intent, normalized: the bare `{logical, presentation}`
 *  spelling is shorthand for `{fixed: ...}`. */
function normalizeViewport(viewport: PocketManifestV2["app"]["viewport"]): {
  fixed?: { logical: Viewport; presentation: PresentationMode };
  dynamic?: { default: Viewport; min?: Viewport; max?: Viewport };
} {
  if ("logical" in viewport) {
    return { fixed: { logical: viewport.logical, presentation: viewport.presentation } };
  }
  return { fixed: viewport.fixed as never, dynamic: viewport.dynamic as never };
}

const within = (v: Viewport, min: Viewport, max: Viewport): boolean =>
  v[0] >= min[0] && v[1] >= min[1] && v[0] <= max[0] && v[1] <= max[1];

/**
 * Pick and validate the viewport variant the target's FORM calls for.
 * Window/widget forms take the app's `dynamic` variant (or its `fixed` one
 * size-locked, when the target opts in via acceptsFixed); every other form
 * requires `fixed`. Returns the resolved plan viewport, or null after
 * pushing diagnostics.
 */
function resolveViewport(
  declared: ManifestViewport,
  viewportPath: string,
  profile: TargetProfile,
  diagnostics: ContractDiagnostic[],
): {
  logical: Viewport;
  presentation: PresentationMode;
  physical: Viewport;
  policy: "fixed" | "dynamic";
} | null {
  const viewport = normalizeViewport(declared);
  const { physicalViewport, logicalViewports, dynamicViewport, presentations, rasterDensity } =
    profile.display;
  const dynamicTarget = DYNAMIC_FORMS.includes(profile.form);

  if (dynamicTarget) {
    // Registry validation already records the actionable diagnostic. Do not
    // dereference malformed framework-owned data and turn it into a runtime
    // TypeError before the caller can receive that diagnostic.
    if (!dynamicViewport) return null;
    const range = dynamicViewport;
    if (viewport.dynamic) {
      const size = viewport.dynamic.default;
      if (!within(size, range.min, range.max)) {
        diagnostics.push({
          code: "viewport.logicalUnsupported",
          path: `${viewportPath}/dynamic/default`,
          message: `target admits ${range.min[0]}x${range.min[1]} through ${range.max[0]}x${range.max[1]}, not ${size[0]}x${size[1]}`,
        });
        return null;
      }
      return {
        logical: size,
        presentation: "native",
        physical: [size[0] * rasterDensity, size[1] * rasterDensity],
        policy: "dynamic",
      };
    }
    if (viewport.fixed) {
      if (!range.acceptsFixed) {
        diagnostics.push({
          code: "viewport.fixedUnhosted",
          path: viewportPath,
          message: `${profile.form}-form target does not host fixed-viewport apps — declare a dynamic viewport variant`,
        });
        return null;
      }
      const size = viewport.fixed.logical;
      if (!within(size, range.min, range.max)) {
        diagnostics.push({
          code: "viewport.logicalUnsupported",
          path: `${viewportPath}/fixed/logical`,
          message: `target admits ${range.min[0]}x${range.min[1]} through ${range.max[0]}x${range.max[1]}, not ${size[0]}x${size[1]}`,
        });
        return null;
      }
      // Size-locked window: presented 1 logical px = density physical px.
      return {
        logical: size,
        presentation: "native",
        physical: [size[0] * rasterDensity, size[1] * rasterDensity],
        policy: "fixed",
      };
    }
    diagnostics.push({
      code: "viewport.dynamicRequired",
      path: viewportPath,
      message: "target has a dynamic window — declare a dynamic viewport variant",
    });
    return null;
  }

  if (!viewport.fixed) {
    diagnostics.push({
      code: "viewport.fixedRequired",
      path: viewportPath,
      message: "target has a fixed screen — declare a fixed viewport variant",
    });
    return null;
  }
  const { logical, presentation } = viewport.fixed;
  const fixedPath = "logical" in declared ? viewportPath : `${viewportPath}/fixed`;
  let ok = true;
  if (!logicalViewports.some((supported) => sameViewport(supported, logical))) {
    diagnostics.push({
      code: "viewport.logicalUnsupported",
      path: `${fixedPath}/logical`,
      message: `target does not support logical viewport ${logical[0]}x${logical[1]}`,
    });
    ok = false;
  }
  if (!presentations.includes(presentation)) {
    diagnostics.push({
      code: "viewport.presentationUnsupported",
      path: `${fixedPath}/presentation`,
      message: `target does not support ${JSON.stringify(presentation)} presentation`,
    });
    ok = false;
  }
  // Native presentation: one logical px maps to rasterDensity physical px,
  // in either orientation of the panel (nativeFill).
  let physical: Viewport = [physicalViewport[0], physicalViewport[1]];
  if (presentation === "native") {
    const fill = nativeFill(logical, rasterDensity, physicalViewport);
    if (fill === null) {
      diagnostics.push({
        code: "viewport.nativeMismatch",
        path: fixedPath,
        message: "native presentation requires the logical viewport to fill the panel",
      });
      ok = false;
    } else {
      physical = fill;
    }
  }
  if (presentation === "integer-fit") {
    const x = physicalViewport[0] / logical[0];
    const y = physicalViewport[1] / logical[1];
    if (!Number.isInteger(x) || x < 1 || x !== y) {
      diagnostics.push({
        code: "viewport.integerFitMismatch",
        path: fixedPath,
        message: "integer-fit requires one positive integer scale on both axes",
      });
      ok = false;
    }
  }
  return ok
    ? {
        logical,
        presentation,
        physical,
        policy: "fixed",
      }
    : null;
}

/** Validate framework-owned registry data before trusting it in resolution. */
export function validatePlatformContractRegistry(
  registry: PlatformContractRegistry,
): readonly ContractDiagnostic[] {
  const diagnostics: ContractDiagnostic[] = [];
  const known = new Set<string>();
  registry.capabilities.forEach((capability, index) => {
    if (known.has(capability)) {
      diagnostics.push({
        code: "registry.duplicateCapability",
        path: `/capabilities/${index}`,
        message: `capability ${JSON.stringify(capability)} is registered more than once`,
      });
    }
    known.add(capability);
  });

  for (const [targetId, target] of Object.entries(registry.targets)) {
    if (target.hostAbi !== POCKET_BINDING_GENERATION) {
      diagnostics.push({ code: "registry.bindingGeneration", path: `/targets/${targetId}/hostAbi`,
        message: `target must use binding generation ${POCKET_BINDING_GENERATION}` });
    }
    if (target.tickHz !== undefined && (!Number.isInteger(target.tickHz) || target.tickHz < 1 || target.tickHz > 240)) {
      diagnostics.push({ code: "registry.invalidTickHz", path: `/targets/${targetId}/tickHz`,
        message: "target tickHz must be an integer from 1 through 240" });
    }
    if (
      !Number.isInteger(target.display.rasterDensity) ||
      target.display.rasterDensity < 1 ||
      target.display.rasterDensity > 255
    ) {
      diagnostics.push({
        code: "registry.invalidRasterDensity",
        path: `/targets/${targetId}/display/rasterDensity`,
        message: "target rasterDensity must be an integer from 1 through 255",
      });
    }
    const targetCapabilities = new Set<string>(target.capabilities);
    const auxiliary = target.display.auxiliary;
    if (targetCapabilities.has(AUXILIARY_DISPLAY) !== Boolean(auxiliary)) {
      diagnostics.push({
        code: "registry.auxiliaryDisplayMismatch",
        path: `/targets/${targetId}/display/auxiliary`,
        message: "display.auxiliary capability and display.auxiliary facts must be declared together",
      });
    }
    if (auxiliary && auxiliary.rasterDensity !== target.display.rasterDensity) {
      diagnostics.push({
        code: "registry.auxiliaryRasterDensityMismatch",
        path: `/targets/${targetId}/display/auxiliary/rasterDensity`,
        message: "auxiliary rasterDensity must match the primary display",
      });
    }
    if (
      targetCapabilities.has(AUXILIARY_TOUCH) &&
      !targetCapabilities.has(AUXILIARY_DISPLAY)
    ) {
      diagnostics.push({
        code: "registry.auxiliaryTouchWithoutDisplay",
        path: `/targets/${targetId}/capabilities`,
        message: "input.touch.auxiliary requires display.auxiliary",
      });
    }
    if (!TARGET_FORMS.includes(target.form)) {
      diagnostics.push({
        code: "registry.invalidForm",
        path: `/targets/${targetId}/form`,
        message: `target form must be one of ${TARGET_FORMS.join(", ")}`,
      });
    }
    const dynamicForm = DYNAMIC_FORMS.includes(target.form);
    if (dynamicForm && !target.display.dynamicViewport) {
      diagnostics.push({
        code: "registry.dynamicViewportMissing",
        path: `/targets/${targetId}/display`,
        message: `${target.form}-form targets must declare display.dynamicViewport`,
      });
    }
    if (!dynamicForm && target.display.dynamicViewport) {
      diagnostics.push({
        code: "registry.dynamicViewportForbidden",
        path: `/targets/${targetId}/display/dynamicViewport`,
        message: `${target.form}-form targets have a fixed screen — remove dynamicViewport`,
      });
    }
    const provided = new Set<string>();
    target.capabilities.forEach((capability, index) => {
      const path = `/targets/${targetId}/capabilities/${index}`;
      if (!known.has(capability)) {
        diagnostics.push({
          code: "registry.unknownCapability",
          path,
          message: `target provides unregistered capability ${JSON.stringify(capability)}`,
        });
      }
      if (provided.has(capability)) {
        diagnostics.push({
          code: "registry.duplicateCapability",
          path,
          message: `target provides capability ${JSON.stringify(capability)} more than once`,
        });
      }
      provided.add(capability);
    });
    for (const [role, capabilities] of Object.entries(target.roleCapabilities ?? {})) {
      const rolePath = `/targets/${targetId}/roleCapabilities/${role}`;
      if (!PACKAGE_ROLES.includes(role as (typeof PACKAGE_ROLES)[number])) {
        diagnostics.push({
          code: "registry.unknownPackageRole",
          path: rolePath,
          message: `target declares unknown package role ${JSON.stringify(role)}`,
        });
      }
      const roleProvided = new Set(provided);
      capabilities?.forEach((capability, index) => {
        const path = `${rolePath}/${index}`;
        if (!known.has(capability)) {
          diagnostics.push({
            code: "registry.unknownCapability",
            path,
            message: `target provides unregistered capability ${JSON.stringify(capability)}`,
          });
        }
        if (roleProvided.has(capability)) {
          diagnostics.push({
            code: "registry.duplicateCapability",
            path,
            message: `target provides capability ${JSON.stringify(capability)} more than once for ${role}`,
          });
        }
        roleProvided.add(capability);
      });
    }
  }
  return diagnostics;
}

export function resolveBuildPlan(
  manifest: PocketManifestV2,
  request: ResolveBuildRequest,
  registry: PlatformContractRegistry = POCKET_PLATFORM_CONTRACTS,
): ResolutionResult {
  const diagnostics: ContractDiagnostic[] = [...validatePlatformContractRegistry(registry)];
  if (request.hostExtension !== undefined && !isHostExtension(request.hostExtension)) {
    diagnostics.push({ code: "hostExtension.invalid", path: "/hostExtension",
      message: "host extension must carry a versioned, content-verified JSON payload" });
  }
  if (typeof manifest.app.theme === "string") {
    diagnostics.push({
      code: "app.themeUnresolved",
      path: "/app/theme",
      message: `app.theme names the module ${JSON.stringify(manifest.app.theme)}; readPocketManifest loads it before resolution`,
    });
    return { ok: false, diagnostics };
  }
  const profile = registry.targets[request.target];
  if (!profile) {
    diagnostics.push({
      code: "target.unknown",
      path: "/target",
      message: `unknown target ${JSON.stringify(request.target)}; available: ${Object.keys(registry.targets).sort().join(", ")}`,
    });
    return { ok: false, diagnostics };
  }

  const executionClass = request.executionClass ?? "guest";
  const executionClasses = manifest.execution?.classes;
  if (executionClasses && !executionClasses.includes(executionClass)) {
    diagnostics.push({
      code: `execution.${executionClass}Excluded`,
      path: "/execution/classes",
      message: `manifest declares no ${executionClass} execution class`,
    });
  }
  if (executionClass === "aot" && manifest.app.aot !== true) {
    diagnostics.push({ code: "execution.aotDisabled", path: "/app/aot", message: "AOT compilation requires app.aot to be true" });
  }

  // The device's modality selects the presentation; the first declared
  // presentation whose requirement the modality meets is the one this build
  // compiles. None matching means the baseline `app.entry`.
  const modality = deriveModality(profile);
  const presentations = manifest.app.presentations ?? [];
  const presentationIds = new Map<string, number>();
  presentations.forEach((candidate, index) => {
    const previous = presentationIds.get(candidate.id);
    if (previous !== undefined) {
      diagnostics.push({
        code: "presentation.duplicateId",
        path: `/app/presentations/${index}/id`,
        message: `presentation id ${JSON.stringify(candidate.id)} was already declared at /app/presentations/${previous}`,
      });
      return;
    }
    presentationIds.set(candidate.id, index);
  });
  const chosenIndex = presentations.findIndex(
    (candidate) => modalityMisses(modality, candidate.modality).length === 0,
  );
  const chosen: PresentationSpec | undefined = chosenIndex >= 0 ? presentations[chosenIndex] : undefined;
  const presentationPath = chosen ? `/app/presentations/${chosenIndex}` : "/app";
  if (!chosen && manifest.app.modality) {
    const misses = modalityMisses(modality, manifest.app.modality);
    if (misses.length > 0) {
      diagnostics.push({
        code: "modality.unsupported",
        path: "/app/modality",
        message: `target ${request.target} does not meet the application's modality (${misses.join(", ")}) and no presentation matched`,
      });
      return { ok: false, diagnostics };
    }
  }
  const presentation = {
    id: chosen?.id ?? "default",
    entry: chosen?.entry ?? manifest.app.entry,
  };

  const declaredViewport = chosen?.viewport ?? manifest.app.viewport;
  const viewportPath = chosen?.viewport ? `${presentationPath}/viewport` : "/app/viewport";
  const resolvedViewport = resolveViewport(declaredViewport, viewportPath, profile, diagnostics);
  const declaredSurfaces = chosen?.surfaces ?? manifest.app.surfaces;
  const surfacesPath = chosen?.surfaces ? `${presentationPath}/surfaces` : "/app/surfaces";

  const known = new Set<string>(registry.capabilities);
  const role = request.role ?? "application";
  const provided = new Set<string>([
    ...profile.capabilities,
    ...(role === "systemUI" ? (profile.roleCapabilities?.systemUI ?? []) : []),
  ]);
  const seen = new Map<string, string>();
  const featureAvailability = new Map<string, boolean>();

  // App-level declarations first, then the chosen presentation's additions.
  // A presentation `requires` may promote an app-level `enhances`; every
  // other repeat is a duplicate the author should remove.
  const appEnhances = new Map<string, string>();
  (manifest.engine.capabilities.enhances ?? []).forEach((capability, index) => {
    appEnhances.set(capability, capabilityPath("enhances", index));
  });
  const declarations: readonly (readonly ["requires" | "enhances", readonly string[], (index: number) => string])[] = [
    ["requires", manifest.engine.capabilities.requires, (index) => capabilityPath("requires", index)],
    ["enhances", manifest.engine.capabilities.enhances ?? [], (index) => capabilityPath("enhances", index)],
    ...(chosen
      ? ([
          ["requires", chosen.capabilities?.requires ?? [], (index: number) => `${presentationPath}/capabilities/requires/${index}`],
          ["enhances", chosen.capabilities?.enhances ?? [], (index: number) => `${presentationPath}/capabilities/enhances/${index}`],
        ] as const)
      : []),
  ];

  for (const [kind, capabilities, pathOf] of declarations) {
    capabilities.forEach((capability, index) => {
      const path = pathOf(index);
      const previous = seen.get(capability);
      if (previous) {
        const promotes = kind === "requires" && path.startsWith("/app/presentations/") && appEnhances.get(capability) === previous;
        if (!promotes) {
          diagnostics.push({
            code: "capability.duplicate",
            path,
            message: `capability was already declared at ${previous}`,
          });
          return;
        }
      }
      seen.set(capability, path);

      if (!known.has(capability)) {
        diagnostics.push({
          code: "capability.unknown",
          path,
          message: `unknown capability ${JSON.stringify(capability)}`,
        });
        return;
      }

      const available = provided.has(capability);
      const required = kind === "requires";
      if (required && !available) {
        diagnostics.push({
          code: "capability.unavailable",
          path,
          message: `target ${request.target} does not provide ${capability} to role ${role}`,
        });
        return;
      }
      featureAvailability.set(capability, required || available);
    });
  }

  const requires = new Set([
    ...manifest.engine.capabilities.requires,
    ...(chosen?.capabilities?.requires ?? []),
  ]);
  const enhances = new Set(
    [...(manifest.engine.capabilities.enhances ?? []), ...(chosen?.capabilities?.enhances ?? [])].filter(
      (capability) => !requires.has(capability),
    ),
  );
  if (requires.has("text.glyphs.streamed") && !requires.has("io.offload") ||
      enhances.has("text.glyphs.streamed") && !requires.has("io.offload") && !enhances.has("io.offload")) {
    diagnostics.push({code:"capability.offloadDependency",path:"/engine/capabilities",message:"text.glyphs.streamed requires a matching io.offload declaration"});
  }
  if (requires.has("text.layout.offload") && !requires.has("io.offload") ||
      enhances.has("text.layout.offload") && !requires.has("io.offload") && !enhances.has("io.offload")) {
    diagnostics.push({code:"capability.offloadDependency",path:"/engine/capabilities",message:"text.layout.offload requires a matching io.offload declaration"});
  }
  const auxiliaryDeclared = requires.has(AUXILIARY_DISPLAY) || enhances.has(AUXILIARY_DISPLAY);
  const auxiliaryTouchDeclared = requires.has(AUXILIARY_TOUCH) || enhances.has(AUXILIARY_TOUCH);
  if (Boolean(declaredSurfaces?.auxiliary) !== auxiliaryDeclared) {
    diagnostics.push({
      code: "surface.auxiliaryDeclarationMismatch",
      path: surfacesPath,
      message: "surfaces.auxiliary and the display.auxiliary capability must be declared together",
    });
  }
  if (auxiliaryTouchDeclared && !auxiliaryDeclared) {
    diagnostics.push({
      code: "capability.dependency",
      path: seen.get(AUXILIARY_TOUCH) ?? "/engine/capabilities",
      message: "input.touch.auxiliary requires the application to declare display.auxiliary",
    });
  }
  if (requires.has(AUXILIARY_TOUCH) && !requires.has(AUXILIARY_DISPLAY)) {
    diagnostics.push({
      code: "capability.dependency",
      path: seen.get(AUXILIARY_TOUCH) ?? "/engine/capabilities/requires",
      message: "required input.touch.auxiliary requires display.auxiliary in requires",
    });
  }

  if (declaredSurfaces && !declaredSurfaces.auxiliary.fixed === !declaredSurfaces.auxiliary.adaptive) {
    diagnostics.push({
      code: "surface.auxiliaryPolicy",
      path: `${surfacesPath}/auxiliary`,
      message: "surfaces.auxiliary declares exactly one of fixed and adaptive",
    });
  }
  let resolvedAuxiliary:
    | NonNullable<ResolvedBuildPlanContent["surfaces"]>["auxiliary"]
    | undefined;
  if (
    featureAvailability.get(AUXILIARY_DISPLAY) === true &&
    declaredSurfaces?.auxiliary &&
    profile.display.auxiliary
  ) {
    const auxiliaryDiagnostics = requires.has(AUXILIARY_DISPLAY) ? diagnostics : undefined;
    const { fixed, adaptive } = declaredSurfaces.auxiliary;
    resolvedAuxiliary = (adaptive
      ? resolveAdaptiveDisplay(
          adaptive,
          profile.display.auxiliary,
          `${surfacesPath}/auxiliary/adaptive`,
          auxiliaryDiagnostics,
        )
      : resolveFixedDisplay(
          fixed!,
          profile.display.auxiliary,
          `${surfacesPath}/auxiliary/fixed`,
          auxiliaryDiagnostics,
        )) ?? undefined;
    if (!resolvedAuxiliary) {
      featureAvailability.set(AUXILIARY_DISPLAY, false);
      featureAvailability.set(AUXILIARY_TOUCH, false);
    }
  }

  // A derived output must satisfy the same artifact-name contract an explicit
  // one is validated against — an entry like "app/Main.tsx" or "app/.tsx"
  // would otherwise smuggle an invalid name past the schema and fail much
  // later, inside a backend, blaming a plan the resolver itself produced.
  const OUTPUT_NAME = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
  const explicitOutput = chosen?.output ?? manifest.app.output;
  const output = explicitOutput ?? presentation.entry.split("/").pop()!.replace(/\.tsx?$/, "");
  if (!OUTPUT_NAME.test(output)) {
    diagnostics.push({
      code: "app.outputUnderivable",
      path: chosen?.output !== undefined
        ? `${presentationPath}/output`
        : manifest.app.output !== undefined
          ? "/app/output"
          : `${presentationPath}/entry`,
      message: `derived output ${JSON.stringify(output)} is not a valid artifact name — set app.output explicitly`,
    });
  }

  // A Pocket Applet (contracts/spec/applet.ts) is held to the applet rules
  // on every target, before a plan exists.
  diagnostics.push(...appletManifestDiagnostics(manifest));

  const worker = manifest.domains?.worker;
  if (requires.has("runtime.worker") && !worker) diagnostics.push({ code: "worker.entry", path: "/domains/worker", message: "runtime.worker requires a worker entry" });
  if (worker) {
    if (!requires.has("runtime.worker")) diagnostics.push({ code: "worker.required", path: "/engine/capabilities/requires", message: "A worker entry requires runtime.worker; UI fallback ownership is not supported by this version" });
    if (manifest.app.aot) diagnostics.push({ code: "worker.execution", path: "/domains/worker", message: "Worker entries require the guest execution class" });
    for (const field of ["nodes", "channels"] as const) {
      const names = new Set<string>();
      for (const [index, value] of (worker[field] ?? []).entries()) {
        if (names.has(value.name)) diagnostics.push({ code: "worker.duplicate", path: `/domains/worker/${field}/${index}/name`, message: `Duplicate worker ${field} name: ${value.name}` });
        names.add(value.name);
      }
    }
    for (const [index, node] of worker.nodes.entries()) {
      const capability = WORKER_RESOURCES[node.kind].capability;
      if (!requires.has(capability)) diagnostics.push({ code: "worker.nodeCapability", path: `/domains/worker/nodes/${index}`, message: `Worker ${node.kind} nodes require ${capability}` });
    }
  }

  if (diagnostics.length > 0 || !resolvedViewport) return { ok: false, diagnostics };

  const logical: Viewport = [resolvedViewport.logical[0], resolvedViewport.logical[1]];
  const physical: Viewport = [resolvedViewport.physical[0], resolvedViewport.physical[1]];
  // Plain codepoint sort — the same ordering canonicalJson uses for the plan
  // hash, so the pretty plan.json never depends on ICU collation.
  const features = Object.fromEntries(
    [...featureAvailability.entries()].sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0)),
  );

  // The old registry's absent rate has always meant 60 Hz. This one-way
  // adapter preserves that contract while every emitted plan names its rate.
  const softwareProfile = profileHashProjection({ id: request.target, ...profile, tickHz: profile.tickHz ?? 60 });
  const content: ResolvedBuildPlanContent = {
    profile: softwareProfile,
    profileHash: hashPocketProfile(softwareProfile),
    app: {
      id: manifest.id,
      title: manifest.title,
      version: manifest.version,
      entry: presentation.entry,
      output,
      framework: manifest.app.framework,
      ...(manifest.app.theme !== undefined ? { theme: manifest.app.theme } : {}),
      ...(manifest.app.aot !== undefined ? { aot: manifest.app.aot } : {}),
      ...(manifest.app.model !== undefined ? { model: manifest.app.model } : {}),
      ...(manifest.app.recursionLimit !== undefined ? { recursionLimit: manifest.app.recursionLimit } : {}),
    },
    ...(worker ? { domains: { worker } } : {}),
    presentation,
    target: {
      id: request.target,
      hostAbi: profile.hostAbi,
    },
    viewport: {
      logical,
      physical,
      presentation: resolvedViewport.presentation,
      rasterDensity: profile.display.rasterDensity,
      policy: resolvedViewport.policy,
    },
    ...(resolvedAuxiliary ? { surfaces: { auxiliary: resolvedAuxiliary } } : {}),
    modality,
    animation: deriveAnimationClass(profile),
    features,
    companions: manifest.app.companions ?? [],
    ...(request.hostExtension ? { hostExtension: request.hostExtension } : {}),
    ...(manifest.applet ? { applet: manifest.applet } : {}),
  };
  return { ok: true, plan: finalizeBuildPlan(content) };
}

export function validateAndResolveBuildPlan(
  input: unknown,
  request: ResolveBuildRequest,
  registry: PlatformContractRegistry = POCKET_PLATFORM_CONTRACTS,
): ResolutionResult {
  const validated = validatePocketManifest(input);
  if (!validated.ok) return validated;
  return resolveBuildPlan(validated.value, request, registry);
}
