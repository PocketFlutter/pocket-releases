import { OFFLOAD, type OffloadOps, type OffloadReply, type OffloadRequest } from "../../contracts/spec/offload.ts";
import { registerServicePump } from "./services.ts";

export { OFFLOAD };
export type { OffloadOps };
export { uploadIndexedImage, type IndexedImage } from "./indexed-image.ts";
/** Fixed-budget native resource upload when implemented by the host.
 * Optional column colors use one hex palette index per pixel column and
 * up to 16 concatenated RGB hex colors. They retain the one-upload budget. */
export function uploadCoverage(base64: string, width: number, height: number, foreground: number,
  colors?: { columns: string; palette: string }): number | undefined {
  return (globalThis as unknown as { offload?: OffloadOps }).offload?.uploadCoverage?.(base64, width, height, foreground, colors?.columns, colors?.palette);
}
export type OffloadResult = { ok: true; value: string } | { ok: false; error: string };
type Pending = { record: OffloadRequest; callback: (result: OffloadResult) => void; deadline: number; sent: boolean; session: number };

// The host ABI carries this bounded object through the direct-value bridge.
// Keep the admission check allocation-free: it is the B1 object envelope
// bound (including the magic byte), not a JSON serialization estimate.
const DIRECT_RECORD_FIXED_BYTES = 66;
function directStringMetrics(value: string, maxChars = Number.MAX_SAFE_INTEGER): { bytes: number; chars: number } {
  let bytes = 0, chars = 0;
  for (const char of value) {
    chars++;
    if (chars > maxChars) return { bytes: Number.MAX_SAFE_INTEGER, chars };
    const code = char.codePointAt(0)!;
    bytes += code < 0x80 ? 1 : code < 0x800 ? 2 : code < 0x10000 ? 3 : 4;
  }
  return { bytes, chars };
}
function directRecordMetrics(record: OffloadRequest): { bytes: number; payloadChars: number } {
  const method = directStringMetrics(record.method), payload = directStringMetrics(record.payload, OFFLOAD.payloadChars);
  return { bytes: DIRECT_RECORD_FIXED_BYTES + method.bytes + payload.bytes, payloadChars: payload.chars };
}
function isOffloadReply(value: unknown): value is OffloadReply {
  if (!value || typeof value !== "object") return false;
  const id = (value as { id?: unknown }).id;
  return typeof id === "number" && Number.isSafeInteger(id) && id > 0;
}

/** One client per JS realm. Capability payloads are bounded strings, while
 * the request/reply envelope stays a direct host value. */
export function createOffloadClient(ops: OffloadOps) {
  if (typeof ops.submitValue !== "function" || typeof ops.takeValue !== "function") {
    throw new Error("Offload host ABI requires submitValue(request) and takeValue()");
  }
  const pending = new Map<number, Pending>();
  let nextId = 1, frame = 0, disposed = false;
  const finish = (id: number, result: OffloadResult) => {
    const item = pending.get(id);
    if (!item) return;
    pending.delete(id);
    item.callback(result);
  };
  const eventDriven = () => (ops as OffloadOps & { eventDriven?: boolean }).eventDriven === true;
  const needsPump = () => {
    if (disposed) return false;
    if (!eventDriven()) return pending.size > 0;
    const session = ops.session();
    for (const item of pending.values()) {
      if (!item.sent || item.session !== session) return true;
    }
    return false;
  };
  return {
    connected: () => !disposed && ops.session() > 0,
    session: () => disposed ? 0 : ops.session(),
    pending: () => pending.size,
    needsPump,
    request(method: string, payload: string, callback: Pending["callback"]): number {
      if (disposed || pending.size >= OFFLOAD.pending) return 0;
      if (!/^[a-z][a-z0-9_.-]{0,63}$/.test(method)) throw new Error("Invalid offload capability");
      if (typeof payload !== "string") throw new Error("Offload payload exceeds budget");
      const id = nextId++;
      const record: OffloadRequest = { v: 1, id, method, payload };
      const metrics = directRecordMetrics(record);
      if (metrics.payloadChars > OFFLOAD.payloadChars) throw new Error("Offload payload exceeds budget");
      if (metrics.bytes > OFFLOAD.recordBytes) throw new Error("Offload record exceeds budget");
      pending.set(id, { record, callback, deadline: frame + OFFLOAD.timeoutFrames, sent: false, session: 0 });
      return id;
    },
    cancel(id: number) {
      const item = pending.get(id);
      if (!item) return;
      pending.delete(id);
      if (item.sent) (ops as OffloadOps & { cancel?: (id: number, session: number) => void }).cancel?.(id, item.session);
    },
    /** Called exactly once at the frame boundary by the realm service pump. */
    step() {
      if (disposed) return;
      frame++;
      const session = ops.session();
      let delivered = false;
      try {
        const reply = ops.takeValue();
        if (reply && isOffloadReply(reply)) {
          const item = pending.get(reply.id);
          if (item?.sent && item.session === session && session > 0) {
            delivered = true;
            finish(reply.id, typeof reply.payload === "string" && directStringMetrics(reply.payload, OFFLOAD.payloadChars).chars <= OFFLOAD.payloadChars
              ? { ok: true, value: reply.payload }
              : { ok: false, error: typeof reply.error === "string" ? reply.error.slice(0, 160) : "Malformed reply" });
          }
        }
      } catch { /* A malformed bounded value cannot stop the UI. */ }
      let submitted = 0;
      for (const [id, item] of pending) {
        if (!delivered && session <= 0) {
          delivered = true;
          finish(id, { ok: false, error: "Provider unavailable" });
        } else if (!delivered && ((!eventDriven() && frame >= item.deadline) || (item.sent && item.session !== session))) {
          delivered = true;
          finish(id, { ok: false, error: item.sent ? "Connection lost or request expired; outcome may be unknown" : "Provider unavailable" });
        } else if (!item.sent && session > 0 && submitted < OFFLOAD.submissionsPerFrame && ops.submitValue(item.record)) {
          item.sent = true; item.session = session; submitted++;
        }
      }
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      for (const [id, item] of pending) {
        if (item.sent) (ops as OffloadOps & { cancel?: (id: number, session: number) => void }).cancel?.(id, item.session);
      }
      pending.clear();
    },
  };
}

let client: ReturnType<typeof createOffloadClient> | undefined;
let localClient: ReturnType<typeof createOffloadClient> | undefined;
/** No synchronous FS, DB, DNS or socket operation is exposed to the guest. */
export function offload(provider: "companion" | "local" = "companion") {
  if (provider === "local" && localClient) return localClient;
  if (provider === "companion" && client) return client;
  const root = (globalThis as unknown as { offload?: OffloadOps }).offload;
  const ops = provider === "local" ? root?.local : root;
  if (!ops) throw new Error("Host does not implement io.offload");
  const next = createOffloadClient(ops);
  if (provider === "local") localClient = next; else client = next;
  registerServicePump(() => next.step(), () => next.needsPump());
  return next;
}
