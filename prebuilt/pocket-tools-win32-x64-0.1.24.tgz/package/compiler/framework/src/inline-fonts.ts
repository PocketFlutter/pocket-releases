import { INLINE_TEXT_FONT_SLOTS } from "./styles.generated.ts";

export type InlineFontRole = "body" | "bodyBold" | "headingBold" | "ruby";

/** Return a font atlas role emitted only when this build contains a real
 * InlineText/inlineFontSlot callsite. Calling it in a plain-text guest is an
 * explicit build error rather than silently shipping extra font atlases. */
export function inlineFontSlot(role: InlineFontRole): number {
  const slot = INLINE_TEXT_FONT_SLOTS[role];
  if (slot === undefined) {
    throw new Error(`PocketJS: inline font role '${role}' was not baked; use InlineText in a compiled module`);
  }
  return slot;
}
