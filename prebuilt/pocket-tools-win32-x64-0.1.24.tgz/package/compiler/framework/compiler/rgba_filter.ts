// Lossless RGBA tile filter used by the TILESET v2 cooker.
//
// The wire payload is intentionally smaller than a complete PNG: every row
// starts with a PNG filter byte (0..4), followed by RGBA residual bytes, and
// the complete filtered stream is wrapped with zlib DEFLATE.  The matching
// core helper reverses the row filters after bounded inflation.

import { deflateSync } from "node:zlib";

/**
 * Encode one tightly packed RGBA image as filtered, zlib-wrapped bytes.
 *
 * The encoder is deliberately independent of the TILESET header/codec code:
 * callers can put these bytes in a per-tile directory entry without pulling
 * PNG chunks, CRCs, or a browser image decoder into the runtime.
 */
export function encodeFilteredRgba(
  rgba: Uint8Array,
  width: number,
  height: number,
): Uint8Array {
  if (!Number.isSafeInteger(width) || width <= 0) {
    throw new Error(`rgba filter: invalid width ${width}`);
  }
  if (!Number.isSafeInteger(height) || height <= 0) {
    throw new Error(`rgba filter: invalid height ${height}`);
  }

  const rowBytes = width * 4;
  const rawBytes = rowBytes * height;
  const filteredBytes = (rowBytes + 1) * height;
  if (
    !Number.isSafeInteger(rowBytes) ||
    !Number.isSafeInteger(rawBytes) ||
    !Number.isSafeInteger(filteredBytes)
  ) {
    throw new Error("rgba filter: dimensions overflow");
  }
  if (rgba.byteLength !== rawBytes) {
    throw new Error(`rgba filter: length ${rgba.byteLength}, want ${rawBytes}`);
  }

  const filtered = new Uint8Array(filteredBytes);
  const candidate = new Uint8Array(rowBytes);
  const best = new Uint8Array(rowBytes);

  for (let y = 0; y < height; y++) {
    const row = y * rowBytes;
    const previous = row - rowBytes;
    const output = y * (rowBytes + 1);
    let bestFilter = 0;
    let bestScore = Number.POSITIVE_INFINITY;

    // The tie order is intentional: it gives stable output and prefers the
    // cheaper filters when two candidates have the same residual score.
    for (let filter = 0; filter <= 4; filter++) {
      let score = 0;
      for (let x = 0; x < rowBytes; x++) {
        const value = rgba[row + x];
        const left = x >= 4 ? rgba[row + x - 4] : 0;
        const up = y > 0 ? rgba[previous + x] : 0;
        const upLeft = y > 0 && x >= 4 ? rgba[previous + x - 4] : 0;
        let predictor: number;
        switch (filter) {
          case 0:
            predictor = 0;
            break;
          case 1:
            predictor = left;
            break;
          case 2:
            predictor = up;
            break;
          case 3:
            predictor = (left + up) >> 1;
            break;
          default:
            predictor = paeth(left, up, upLeft);
            break;
        }
        const residual = value - predictor;
        candidate[x] = residual & 0xff;
        // PNG's filter heuristic scores the stored byte as signed int8,
        // rather than the pre-modulo difference in [-255, 255].
        const signedResidual =
          residual > 127 ? residual - 256 : residual < -128 ? residual + 256 : residual;
        score += Math.abs(signedResidual);
      }
      if (score < bestScore) {
        bestScore = score;
        bestFilter = filter;
        best.set(candidate);
      }
    }

    filtered[output] = bestFilter;
    filtered.set(best, output + 1);
  }

  // zlib-wrapped DEFLATE is the format understood by miniz_oxide's
  // DataFormat::Zlib decoder.  No PNG container or host std::io is required.
  return new Uint8Array(deflateSync(filtered, { level: 9 }));
}

function paeth(left: number, up: number, upLeft: number): number {
  const p = left + up - upLeft;
  const pa = Math.abs(p - left);
  const pb = Math.abs(p - up);
  const pc = Math.abs(p - upLeft);
  return pa <= pb && pa <= pc ? left : pb <= pc ? up : upLeft;
}
