var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);

// targets/wechat/template/binary-bridge.js
var require_binary_bridge = __commonJS((exports, module) => {
  var MAX_BYTES = 64 * 1024;
  var MAX_DEPTH = 32;
  function utf8(value, maxBytes) {
    let length = 0;
    for (const character of value) {
      const code = character.codePointAt(0);
      length += code < 128 ? 1 : code < 2048 ? 2 : code < 65536 ? 3 : 4;
      if (length > maxBytes)
        throw new Error("Pocket binary message exceeds size limit");
    }
    const bytes = new Uint8Array(length);
    let offset = 0;
    const put = (byte) => {
      bytes[offset++] = byte;
    };
    for (const character of value) {
      let code = character.codePointAt(0);
      if (code >= 55296 && code <= 57343)
        code = 65533;
      if (code < 128)
        put(code);
      else if (code < 2048) {
        put(192 | code >> 6);
        put(128 | code & 63);
      } else if (code < 65536) {
        put(224 | code >> 12);
        put(128 | code >> 6 & 63);
        put(128 | code & 63);
      } else {
        put(240 | code >> 18);
        put(128 | code >> 12 & 63);
        put(128 | code >> 6 & 63);
        put(128 | code & 63);
      }
    }
    return bytes;
  }
  function text(bytes) {
    let binary = "";
    for (let i = 0;i < bytes.length; i += 8192)
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
    return decodeURIComponent(escape(binary));
  }
  function encodeMessage(value, limit = MAX_BYTES) {
    if (!Number.isInteger(limit) || limit < 1 || limit > 4 * 1024 * 1024)
      throw new Error("Invalid Pocket binary message limit");
    let bytes = new Uint8Array(Math.min(limit, 256));
    let view = new DataView(bytes.buffer);
    let offset = 0;
    const ancestors = new Set;
    function need(n) {
      if (n > limit - offset)
        throw new Error("Pocket binary message exceeds size limit");
      if (offset + n <= bytes.length)
        return;
      const grown = new Uint8Array(Math.min(limit, Math.max(offset + n, bytes.length * 2)));
      grown.set(bytes);
      bytes = grown;
      view = new DataView(bytes.buffer);
    }
    function u8(n) {
      need(1);
      bytes[offset++] = n;
    }
    function u32(n) {
      need(4);
      view.setUint32(offset, n, true);
      offset += 4;
    }
    function raw(value2) {
      u32(value2.length);
      need(value2.length);
      bytes.set(value2, offset);
      offset += value2.length;
    }
    function write(value2, depth) {
      if (depth > MAX_DEPTH)
        throw new Error("Pocket binary message nesting is too deep");
      if (value2 == null) {
        u8(0);
        return;
      }
      if (typeof value2 === "boolean") {
        u8(value2 ? 2 : 1);
        return;
      }
      if (typeof value2 === "number") {
        if (!Number.isFinite(value2))
          throw new Error("Pocket binary number must be finite");
        if (Number.isSafeInteger(value2)) {
          u8(3);
          need(8);
          view.setUint32(offset, value2 >>> 0, true);
          view.setInt32(offset + 4, Math.floor(value2 / 4294967296), true);
        } else {
          u8(4);
          need(8);
          view.setFloat64(offset, value2, true);
        }
        offset += 8;
        return;
      }
      if (typeof value2 === "string") {
        u8(5);
        raw(utf8(value2, limit - offset - 4));
        return;
      }
      if (value2 instanceof ArrayBuffer)
        value2 = new Uint8Array(value2);
      if (value2 instanceof Uint8Array) {
        u8(6);
        raw(value2);
        return;
      }
      if (typeof value2 !== "object")
        throw new Error("Unsupported Pocket binary value");
      if (ancestors.has(value2))
        throw new Error("Cyclic Pocket binary message");
      ancestors.add(value2);
      try {
        if (Array.isArray(value2)) {
          u8(7);
          u32(value2.length);
          for (let i = 0;i < value2.length; i++)
            write(value2[i], depth + 1);
        } else {
          const prototype = Object.getPrototypeOf(value2);
          if (prototype !== Object.prototype && prototype !== null)
            throw new Error("Pocket binary value must be a plain object");
          const keys = Object.keys(value2).filter((key) => value2[key] !== undefined && typeof value2[key] !== "function");
          u8(8);
          u32(keys.length);
          for (const key of keys) {
            raw(utf8(key, limit - offset - 4));
            write(value2[key], depth + 1);
          }
        }
      } finally {
        ancestors.delete(value2);
      }
    }
    if (!value || typeof value !== "object" || Array.isArray(value) || value instanceof Uint8Array)
      throw new Error("Pocket message root must be an object");
    u8(177);
    write(value, 0);
    return bytes.slice(0, offset);
  }
  function decodeMessage(bytes, limit = MAX_BYTES) {
    if (!(bytes instanceof Uint8Array) || bytes.length > limit)
      throw new Error("Invalid Pocket binary message size");
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let offset = 0;
    function need(n) {
      if (n > bytes.length - offset)
        throw new Error("Truncated Pocket binary message");
    }
    function u8() {
      need(1);
      return bytes[offset++];
    }
    function u32() {
      need(4);
      const n = view.getUint32(offset, true);
      offset += 4;
      return n;
    }
    function raw() {
      const n = u32();
      need(n);
      const value2 = bytes.slice(offset, offset + n);
      offset += n;
      return value2;
    }
    function read(depth) {
      if (depth > MAX_DEPTH)
        throw new Error("Pocket binary message nesting is too deep");
      const tag = u8();
      if (tag === 0)
        return null;
      if (tag === 1 || tag === 2)
        return tag === 2;
      if (tag === 3 || tag === 4) {
        need(8);
        const value2 = tag === 4 ? view.getFloat64(offset, true) : view.getInt32(offset + 4, true) * 4294967296 + view.getUint32(offset, true);
        offset += 8;
        if (!Number.isFinite(value2) || tag === 3 && !Number.isSafeInteger(value2))
          throw new Error("Invalid Pocket binary number");
        return value2;
      }
      if (tag === 5)
        return text(raw());
      if (tag === 6)
        return raw();
      if (tag === 7 || tag === 8) {
        const n = u32();
        if (n > bytes.length - offset)
          throw new Error("Invalid Pocket binary collection count");
        if (tag === 7) {
          const result2 = [];
          for (let i = 0;i < n; i++)
            result2.push(read(depth + 1));
          return result2;
        }
        const result = {};
        for (let i = 0;i < n; i++)
          Object.defineProperty(result, text(raw()), { value: read(depth + 1), writable: true, enumerable: true, configurable: true });
        return result;
      }
      throw new Error("Unknown Pocket binary tag");
    }
    if (u8() !== 177)
      throw new Error("Invalid Pocket binary message magic");
    const value = read(0);
    if (offset !== bytes.length || value === null || typeof value !== "object" || Array.isArray(value) || value instanceof Uint8Array)
      throw new Error("Invalid Pocket binary message root or trailing bytes");
    return value;
  }
  module.exports = { encodeMessage, decodeMessage };
});

// targets/wechat/template/wechat-system.js
var require_wechat_system = __commonJS((exports, module) => {
  var { decodeMessage } = require_binary_bridge();

  class PocketWechatSystem {
    constructor(root, createHost) {
      this.root = root;
      root.instanceId = "system-ui";
      root.runtimeGeneration = 1;
      this.createHost = createHost;
      this.apps = root.config.system.apps;
      this.runtimes = new Map;
      this.pending = new Map;
      this.captures = new Map;
      this.sequence = 0;
      this.generation = 1;
      this.compositing = false;
      this.configured = false;
      this.disposed = false;
    }
    handles(capability) {
      return capability.startsWith("system.runtime.") || capability.startsWith("system.storage.") || capability.startsWith("platform.apps.") || capability.startsWith("platform.storage.") || capability.startsWith("platform.messages.") || isWechatBuiltinCapability(capability);
    }
    async request(source, request, signal) {
      const cap = request.capability;
      const p = request.params || {};
      if (this.disposed)
        throw this.root.error("cancelled", "System disposed");
      if (isWechatBuiltinCapability(cap)) {
        return wechatBuiltinCapability(source, cap, p);
      }
      if (cap.startsWith("system.")) {
        if (source !== this.root)
          throw this.root.error("system_context_denied", "System controls are restricted to SystemUI");
        if (cap === "system.runtime.configure") {
          if (p.systemUI !== this.root.config.appId)
            throw this.root.error("system_context_denied", "SystemUI does not match the project");
          this.configured = true;
          return { systemInstanceId: "system-ui", generation: 1 };
        }
        if (!this.configured)
          throw this.root.error("system_not_configured", "SystemUI must configure its runtime first");
        if (cap === "system.runtime.prepareOpen") {
          const runtime = this.instance(p.instanceId);
          if (!runtime || runtime === this.root)
            throw this.root.error("runtime_destroyed", "App runtime is not live");
          if (Number(p.generation) !== runtime.runtimeGeneration)
            throw this.root.error("runtime_destroyed", "App generation is no longer live");
          return {
            instanceId: runtime.instanceId,
            appId: runtime.config.appId,
            previousGeneration: runtime.runtimeGeneration,
            generation: runtime.runtimeGeneration,
            updated: false,
            configured: false
          };
        }
        if (cap === "system.runtime.create") {
          const app = this.apps.find((app2) => app2.appId === p.appId && app2.index !== 0);
          if (!app)
            throw this.root.error("app_not_found", "App is outside the installed project catalog");
          if (this.runtimes.has(app.appId))
            throw this.root.error("runtime_exists", "App runtime already exists");
          const runtime = this.createHost(app, this);
          runtime.instanceId = `wechat-${++this.sequence}`;
          runtime.runtimeGeneration = ++this.generation;
          this.runtimes.set(app.appId, runtime);
          try {
            await runtime.start(this.root.logicalWidth, this.root.logicalHeight, this.root.scale || 1);
            if (signal.aborted || this.disposed || runtime.disposed)
              throw this.root.error("cancelled", "App launch cancelled");
            runtime.started = true;
            runtime.stopScheduled();
            runtime.visible = false;
            return {
              instanceId: runtime.instanceId,
              appId: app.appId,
              generation: runtime.runtimeGeneration,
              ...p.prepareForOpen === true ? { preparedForOpen: true } : {}
            };
          } catch (error) {
            this.runtimes.delete(app.appId);
            runtime.dispose();
            throw error;
          }
        }
        if (cap === "system.runtime.awaitFirstFrame") {
          const runtime = this.instance(p.instanceId);
          if (!runtime || runtime === this.root || Number(p.generation) !== runtime.runtimeGeneration)
            throw this.root.error("runtime_destroyed", "App generation is no longer live");
          this.upload(runtime);
          return { ready: true, generation: runtime.runtimeGeneration };
        }
        if (cap === "system.runtime.destroy") {
          const runtime = this.instance(p.instanceId);
          if (!runtime || runtime === this.root)
            throw this.root.error("runtime_destroyed", "App runtime is not live");
          this.runtimes.delete(runtime.config.appId);
          this.root.exports.web_free_surface(this.root.host, runtime.config.surfaceHandle);
          this.rejectSource(runtime);
          for (const [id, capture] of this.captures)
            if (capture.runtime === runtime)
              this.captures.delete(id);
          runtime.dispose();
          return { destroyed: true };
        }
        if (cap === "system.runtime.post") {
          const runtime = this.instance(p.instanceId);
          if (!runtime || typeof p.event !== "string")
            throw this.root.error("runtime_destroyed", "App event target is not live");
          runtime.deliverGuestEvent(p.event, p.params || {});
          return { accepted: true };
        }
        if (cap === "system.runtime.respond") {
          const pending = this.pending.get(p.requestId);
          if (!pending)
            return { accepted: true, stale: true };
          this.pending.delete(p.requestId);
          pending.cleanup();
          if (p.ok === true)
            pending.resolve(p.value === undefined ? null : p.value);
          else
            pending.reject(this.root.error(p.error?.code || "system_request_failed", p.error?.message || "SystemUI rejected the request"));
          return { accepted: true };
        }
        if (cap.startsWith("system.storage.")) {
          const receiver = {
            wx: this.root.wx,
            config: { appId: p.namespace ? "__shared__" : p.appId },
            error: this.root.error,
            storageKey: this.root.storageKey
          };
          return this.root.storage.call(receiver, cap.replace("system.storage.", "platform.storage."), p);
        }
        throw this.root.error("unsupported", `Unsupported System transport: ${cap}`);
      }
      if (!this.configured)
        throw this.root.error("system_not_configured", "SystemUI is not ready");
      return new Promise((resolve, reject) => {
        const requestId = `wechat-system-${++this.sequence}`;
        const abort = () => {
          this.pending.delete(requestId);
          reject(this.root.error("cancelled", "System request cancelled"));
        };
        const cleanup = () => signal.removeEventListener("abort", abort);
        if (signal.aborted) {
          abort();
          return;
        }
        signal.addEventListener("abort", abort);
        this.pending.set(requestId, { source, resolve, reject, cleanup });
        try {
          this.root.deliverGuestEvent("system.request", {
            requestId,
            sourceAppId: source.config.appId,
            sourceInstanceId: source === this.root ? "system-ui" : source.instanceId,
            sourceGeneration: source === this.root ? 1 : source.runtimeGeneration,
            capability: cap,
            params: p
          });
        } catch (error) {
          this.pending.delete(requestId);
          cleanup();
          reject(error);
        }
      });
    }
    instance(id) {
      return id === "system-ui" ? this.root : [...this.runtimes.values()].find((runtime) => runtime.instanceId === id);
    }
    frames() {
      const root = this.root;
      root.check(root.exports.web_compositor_frames(root.host), "System compositor frames unavailable");
      const bytes = new Uint8Array(root.exports.memory.buffer, root.exports.web_result_ptr(root.host), root.exports.web_result_len(root.host));
      const packet = decodeMessage(bytes);
      if (!Array.isArray(packet.frames))
        throw root.error("render_failed", "Invalid binary compositor frame packet");
      return packet.frames;
    }
    upload(runtime) {
      if (runtime.disposed || !runtime.exports || runtime.surfaceUploaded && !runtime.surfaceDirty)
        return;
      const density = Math.max(1, Number(runtime.scale || this.root.scale || 1));
      const { logicalWidth: width, logicalHeight: height } = runtime;
      const physicalWidth = Math.max(1, Math.ceil(width * density));
      const physicalHeight = Math.max(1, Math.ceil(height * density));
      const pointer = runtime.exports.web_capture(runtime.host, density, 2);
      if (!pointer)
        throw this.root.error("render_failed", "Child raster capture failed");
      const bytes = new Uint8Array(runtime.exports.memory.buffer, pointer, physicalWidth * physicalHeight * 4);
      const root = this.root;
      const buffer = root.exports.web_alloc(bytes.length);
      if (!buffer)
        throw root.error("allocation_failed", "System surface allocation failed");
      try {
        new Uint8Array(root.exports.memory.buffer, buffer, bytes.length).set(bytes);
        const handle = root.exports.web_wechat_upload_surface(root.host, runtime.config.surfaceHandle, buffer, bytes.length, physicalWidth, physicalHeight, density);
        if (handle !== runtime.config.surfaceHandle)
          throw root.error("render_failed", "System surface upload failed");
        runtime.surfaceUploaded = true;
        runtime.surfaceDirty = false;
      } finally {
        root.exports.web_free(buffer, bytes.length);
      }
    }
    composite() {
      if (this.compositing || this.disposed || !this.root.exports)
        return 0;
      this.compositing = true;
      try {
        const frames = this.frames();
        for (const runtime of this.runtimes.values()) {
          const candidates = frames.filter((frame) => frame.handle === runtime.config.surfaceHandle);
          const slot = candidates.find((frame) => frame.focused) || candidates[0];
          runtime.mounted = !!slot;
          if (slot && slot.full[2] > 0 && slot.full[3] > 0) {
            runtime.resize(Math.ceil(slot.full[2]), Math.ceil(slot.full[3]));
            if (slot.focused && this.root.visible && !runtime.visible)
              runtime.show();
            else if (!slot.focused && runtime.visible)
              runtime.hide();
            this.upload(runtime);
          } else if (runtime.started && runtime.visible)
            runtime.hide();
        }
        return this.root.exports.web_capture(this.root.host, this.root.scale, 3);
      } finally {
        this.compositing = false;
      }
    }
    childFrame(runtime) {
      runtime.surfaceDirty = true;
      if (runtime.mounted && !this.compositing && !this.disposed && this.root.exports)
        this.root.draw();
    }
    input(contacts) {
      const rootContacts = [], childContacts = new Map;
      const live = new Set(contacts.filter((contact) => !contact.cancelled).map((contact) => contact.id));
      const frames = this.frames();
      for (const contact of contacts) {
        let target = this.captures.get(contact.id);
        if (!target) {
          const handle = this.root.exports.web_wechat_hit_surface(this.root.host, contact.x, contact.y);
          const slot = frames.find((frame) => frame.handle === handle && frame.focused);
          const runtime = slot && [...this.runtimes.values()].find((child) => child.config.surfaceHandle === handle);
          target = runtime ? { runtime, full: [...slot.full] } : { runtime: this.root };
          this.captures.set(contact.id, target);
        }
        if (target.runtime === this.root)
          rootContacts.push(contact);
        else {
          const list = childContacts.get(target.runtime) || [];
          list.push({ ...contact, x: contact.x - target.full[0], y: contact.y - target.full[1] });
          childContacts.set(target.runtime, list);
        }
      }
      for (const target of this.captures.values())
        if (target.runtime !== this.root && !childContacts.has(target.runtime))
          childContacts.set(target.runtime, []);
      for (const [id] of this.captures)
        if (!live.has(id))
          this.captures.delete(id);
      for (const [runtime, input] of childContacts)
        runtime.inputFrame(input);
      this.root.advance(rootContacts);
      this.root.schedule();
    }
    suspend() {
      for (const runtime of this.runtimes.values())
        if (runtime.visible)
          runtime.hide();
    }
    rejectSource(source) {
      for (const [id, pending] of this.pending)
        if (pending.source === source) {
          this.pending.delete(id);
          pending.cleanup();
          pending.reject(this.root.error("runtime_destroyed", "App runtime destroyed"));
        }
    }
    dispose() {
      this.disposed = true;
      for (const runtime of this.runtimes.values())
        runtime.dispose();
      this.runtimes.clear();
      for (const pending of this.pending.values()) {
        pending.cleanup();
        pending.reject(this.root.error("cancelled", "System disposed"));
      }
      this.pending.clear();
      this.captures.clear();
    }
  }
  var BUILTIN_CAPABILITIES = new Set(["runtime.info", "runtime.performance", "plugins.list", "plugins.packageInfo", "updates.status"]);
  function isWechatBuiltinCapability(capability) {
    return BUILTIN_CAPABILITIES.has(capability);
  }
  function wechatBuiltinCapability(source, capability, params = {}) {
    const value = source.config.metadata;
    const metadata = value && typeof value === "object" && !Array.isArray(value) ? value : {};
    const appId = String(source.config.appId);
    const provider = typeof source.config.provider === "string" && source.config.provider ? source.config.provider : "wechat";
    const host = typeof source.config.host === "string" && source.config.host ? source.config.host : provider;
    const hostRuntime = typeof source.config.hostRuntime === "string" && source.config.hostRuntime ? source.config.hostRuntime : "WXWebAssembly + Canvas2D";
    const qjbc = metadata.qjbc && typeof metadata.qjbc === "object" && !Array.isArray(metadata.qjbc) ? metadata.qjbc : {};
    const version = metadata.version === undefined ? qjbc.version : metadata.version;
    const build = metadata.build === undefined ? qjbc.build : metadata.build;
    if (capability === "runtime.info") {
      return {
        appId,
        provider,
        host,
        source: "embedded",
        entryFormat: qjbc.entryFormat || "quickjs-bytecode",
        runtimeAbi: qjbc.runtimeAbi || null,
        engineAbi: qjbc.engineAbi || null,
        version: version === undefined ? null : version,
        build: build === undefined ? null : build,
        entryBytes: qjbc.bytecodeBytes === undefined ? null : qjbc.bytecodeBytes,
        tickHz: source?.config?.tickHz || qjbc.tickHz || 60,
        hostRuntime,
        logicalWidth: Number(source?.logicalWidth || 0),
        logicalHeight: Number(source?.logicalHeight || 0),
        scale: Number(source?.scale || 1),
        assetRasterDensity: Number(source.config.rasterDensity || source.system?.root?.config?.rasterDensity || 1),
        nativeFlutterTiming: false,
        features: { recording: false, flutterFrameTiming: false, nativeHardware: false }
      };
    }
    if (capability === "runtime.performance") {
      return {
        supported: false,
        nativeFlutterTiming: false,
        provider,
        reason: `${hostRuntime} does not expose Flutter FrameTiming`,
        context: params && params.context === undefined ? null : (params || {}).context
      };
    }
    if (capability === "plugins.list") {
      return { protocolVersion: 1, appId, provider, plugins: [] };
    }
    if (capability === "plugins.packageInfo") {
      const packageInfo = metadata.package && typeof metadata.package === "object" && !Array.isArray(metadata.package) ? metadata.package : {};
      let miniProgram = {};
      try {
        const account = source?.wx?.getAccountInfoSync?.();
        if (account?.miniProgram && typeof account.miniProgram === "object") {
          const value2 = account.miniProgram;
          miniProgram = {
            ...value2.appId === undefined ? {} : { appId: String(value2.appId) },
            ...value2.envVersion === undefined ? {} : { envVersion: String(value2.envVersion) },
            ...value2.version === undefined ? {} : { version: String(value2.version) }
          };
        }
      } catch (_) {}
      return {
        provider,
        appId,
        appName: packageInfo.name || packageInfo.title || appId,
        packageName: appId,
        version: version === undefined ? null : version,
        buildNumber: build === undefined || build === null ? null : String(build),
        miniProgram
      };
    }
    if (capability === "updates.status") {
      const active = { version: version === undefined ? null : version, build: build === undefined ? null : build, source: "embedded", active: true };
      return {
        configured: false,
        stage: "disabled",
        activeVersion: active.version,
        activeBuild: active.build,
        availableVersion: null,
        preparedUpdate: null,
        versions: [active],
        lastError: null,
        provider
      };
    }
    throw source.error("unsupported", `Unsupported ${provider === "web" ? "Web" : "WeChat"} builtin capability: ${capability}`);
  }
  module.exports = { PocketWechatSystem, wechatBuiltinCapability, isWechatBuiltinCapability };
});

// targets/wechat/template/wechat-host.js
var require_wechat_host = __commonJS((exports, module) => {
  var { encodeMessage, decodeMessage } = require_binary_bridge();
  var { PocketWechatSystem, wechatBuiltinCapability, isWechatBuiltinCapability } = require_wechat_system();
  var MAX_OUTBOUND = 32;
  var MAX_REQUESTS = 32;
  var REQUEST_TIMEOUT_MS = 15000;
  var MAX_STORAGE_ITEM_BYTES = 1024 * 1024;
  var NATIVE_CANVAS_DIMENSION = 1365;
  var BROWSER_CANVAS_DIMENSION = 4096;
  var capabilityHandlers = Object.create(null);
  var permissionHandler = null;
  function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function utf8Length(value) {
    return unescape(encodeURIComponent(value)).length;
  }
  function encodeUtf8(value) {
    const binary = unescape(encodeURIComponent(value));
    const bytes = new Uint8Array(binary.length);
    for (let index = 0;index < binary.length; index += 1)
      bytes[index] = binary.charCodeAt(index);
    return bytes;
  }
  function decodeUtf8(bytes) {
    let binary = "";
    for (let offset = 0;offset < bytes.length; offset += 8192) {
      binary += String.fromCharCode.apply(null, bytes.subarray(offset, Math.min(bytes.length, offset + 8192)));
    }
    return decodeURIComponent(escape(binary));
  }
  function createAbortController() {
    if (typeof globalThis.AbortController === "function")
      return new globalThis.AbortController;
    let aborted = false;
    const listeners = [];
    return {
      signal: {
        get aborted() {
          return aborted;
        },
        addEventListener(name, listener) {
          if (name === "abort" && typeof listener === "function")
            listeners.push(listener);
        },
        removeEventListener(name, listener) {
          if (name !== "abort")
            return;
          const index = listeners.indexOf(listener);
          if (index >= 0)
            listeners.splice(index, 1);
        }
      },
      abort() {
        if (aborted)
          return;
        aborted = true;
        for (const listener of listeners.slice()) {
          try {
            listener({ type: "abort" });
          } catch (_) {}
        }
        listeners.length = 0;
      }
    };
  }

  class PocketWechatHost {
    constructor(options) {
      this.headless = !!options.headless;
      this.system = options.system || null;
      this.wx = options.wx;
      this.config = options.config;
      this.canvas = options.canvas;
      this.context = options.context;
      this.onInput = options.onInput;
      this.onError = options.onError;
      this.onWorkerChannel = options.onWorkerChannel;
      this.isActive = options.isActive;
      this.sampleInput = options.sampleInput;
      this.capabilityHandlers = options.capabilityHandlers || Object.create(null);
      this.instance = null;
      this.exports = null;
      this.host = 0;
      this.scale = 1;
      this.devicePixelRatio = 1;
      this.logicalWidth = 1;
      this.logicalHeight = 1;
      this.width = 1;
      this.height = 1;
      this.scheduledIdle = null;
      this.imageData = null;
      this.outbound = [];
      this.contacts = [];
      this.pending = new Map;
      this.raf = 0;
      this.rafUsesCanvas = false;
      this.timer = 0;
      this.running = false;
      this.visible = false;
      this.disposed = false;
      this.draining = false;
      this.input = null;
      this.inputRevision = 0;
      this.generation = 1;
      this.lastClockUs = 0;
      if (!this.system && this.config.system) {
        this.system = new PocketWechatSystem(this, (app, system) => new PocketWechatHost({
          wx: this.wx,
          canvas: {},
          context: null,
          headless: true,
          system,
          config: { ...app, enginePath: this.config.enginePath },
          isActive: () => this.visible && !this.disposed,
          onInput: this.onInput,
          onError: this.onError,
          capabilityHandlers: this.capabilityHandlers
        }));
      }
    }
    canvasDimensionLimit() {
      return this.wx && this.wx.__pocketBrowserPreview === true ? BROWSER_CANVAS_DIMENSION : NATIVE_CANVAS_DIMENSION;
    }
    currentDevicePixelRatio(fallback = 1) {
      const provider = this.wx && this.wx.__pocketBrowserDevicePixelRatio;
      let value;
      try {
        value = typeof provider === "function" ? provider() : provider;
      } catch (_) {
        value = undefined;
      }
      if (!(Number.isFinite(Number(value)) && Number(value) > 0))
        value = fallback;
      return Math.min(4, Math.max(0.25, Number(value)));
    }
    pixelScale(width, height, devicePixelRatio) {
      const dimensionLimit = this.canvasDimensionLimit();
      const requested = this.currentDevicePixelRatio(devicePixelRatio || 1);
      return Math.min(4, Math.max(1, Math.ceil(requested)), Math.floor(dimensionLimit / Math.max(1, Math.floor(width))), Math.floor(dimensionLimit / Math.max(1, Math.floor(height))));
    }
    clockNowUs() {
      this.lastClockUs = Math.max(Date.now() * 1000, this.lastClockUs + 1);
      return this.lastClockUs;
    }
    hostLabel() {
      return this.config.provider === "web" ? "Web" : "WeChat";
    }
    async start(width, height, devicePixelRatio) {
      this.logicalWidth = Math.max(1, Math.floor(width));
      this.logicalHeight = Math.max(1, Math.floor(height));
      this.width = this.logicalWidth;
      this.height = this.logicalHeight;
      const dimensionLimit = this.canvasDimensionLimit();
      this.devicePixelRatio = this.currentDevicePixelRatio(devicePixelRatio || 1);
      const scale = this.pixelScale(this.logicalWidth, this.logicalHeight, this.devicePixelRatio);
      if (scale < 1)
        throw new Error(`PocketJS Canvas2D viewport exceeds the ${dimensionLimit}px surface limit.`);
      this.scale = scale;
      this.configureCanvas();
      const imports = {
        env: { __rquickjs_host_now_us: () => this.clockNowUs() },
        pocket_web_worker: {
          now_micros: () => this.clockNowUs(),
          operation: () => -6
        },
        pocket_wechat: {
          host_emit: (pointer, length) => this.enqueueFromWasm(pointer, length)
        }
      };
      const loaded = await this.wx.WXWebAssembly.instantiate(this.config.enginePath, imports);
      if (this.disposed)
        return;
      this.instance = loaded.instance || loaded;
      this.exports = this.instance.exports;
      this.host = this.exports.web_create(this.logicalWidth, this.logicalHeight, this.scale, 0, 0);
      if (!this.host)
        throw new Error("PocketJS WASM could not allocate its runtime host.");
      const external = this.config.externalGuest;
      if (external) {
        if (!(external.qjbc instanceof Uint8Array) || !(external.pak instanceof Uint8Array) || typeof this.exports.web_boot !== "function" || typeof this.exports.web_set_identity !== "function") {
          throw new Error("PocketJS external Guest requires QJBC, PAK and the generic Web boot ABI.");
        }
        const identity = encodeUtf8(String(this.config.appId || "pocket.web.guest"));
        this.withBytes(identity, (identityPointer, identityLength) => this.check(this.exports.web_set_identity(this.host, identityPointer, identityLength, Number(external.hostAbi || 1)), "PocketJS Web Guest identity was rejected."));
        const workerDeclaration = this.config.worker?.descriptor?.declaration || this.config.worker?.declaration;
        if (workerDeclaration?.channels?.length && typeof this.exports.web_worker_channels_configure === "function") {
          const channels = encodeUtf8(JSON.stringify(workerDeclaration.channels));
          this.withBytes(channels, (pointer, length) => this.check(this.exports.web_worker_channels_configure(this.host, pointer, length), "PocketJS Worker channel declaration was rejected."));
        }
        this.withBytes(external.qjbc, (qjbcPointer, qjbcLength) => this.withBytes(external.pak, (pakPointer, pakLength) => this.check(this.exports.web_boot(this.host, qjbcPointer, qjbcLength, pakPointer, pakLength, Number(external.tickHz || this.config.tickHz || 60), this.scale), "PocketJS external QuickJS guest did not boot.")));
      } else {
        this.check(this.exports.web_wechat_boot_index ? this.exports.web_wechat_boot_index(this.host, this.scale, this.config.index || 0) : this.exports.web_wechat_boot(this.host, this.scale), "PocketJS QuickJS guest did not boot.");
      }
      this.visible = !!this.isActive();
      this.reportViewport();
      this.draw();
      if (this.visible)
        this.drainOutbound();
      this.schedule();
    }
    reportViewport() {
      if (!this.exports || this.disposed || !this.visible)
        return;
      const info = this.wx.getWindowInfo ? this.wx.getWindowInfo() : this.wx.getSystemInfoSync?.() || {};
      const safe = info.safeArea || {};
      const top = Math.max(0, Number(safe.top) || Number(info.statusBarHeight) || 0);
      const right = Math.max(0, (Number(info.screenWidth) || this.logicalWidth) - (Number(safe.right) || this.logicalWidth));
      const bottom = Math.max(0, (Number(info.screenHeight) || this.logicalHeight) - (Number(safe.bottom) || this.logicalHeight));
      const regions = [];
      if (this.wx.getMenuButtonBoundingClientRect) {
        const capsule = this.wx.getMenuButtonBoundingClientRect();
        if (capsule?.width > 0 && capsule?.height > 0)
          regions.push({
            id: "wechat-capsule",
            kind: "occlusion",
            active: true,
            frame: { left: capsule.left, top: capsule.top, width: capsule.width, height: capsule.height },
            margins: { top: 0, left: 8, right: 0, bottom: 8 }
          });
      }
      if (this.headless)
        regions.push({
          id: "mini-app-close",
          kind: "occlusion",
          active: true,
          frame: { left: this.logicalWidth - right - 52, top: top + 8, width: 44, height: 44 },
          margins: { top: 0, left: 8, right: 0, bottom: 8 }
        });
      this.deliverGuestEvent("display.viewport", {
        width: this.logicalWidth,
        height: this.logicalHeight,
        safeArea: { top, right, bottom, left: Math.max(0, Number(safe.left) || 0) },
        keyboardInset: 0,
        reservedRegions: regions
      }, false);
    }
    configureCanvas() {
      if (this.headless)
        return;
      const width = this.logicalWidth * this.scale;
      const height = this.logicalHeight * this.scale;
      const dimensionLimit = this.canvasDimensionLimit();
      if (width > dimensionLimit || height > dimensionLimit)
        throw new Error(`PocketJS Canvas2D output exceeds the ${dimensionLimit}px surface limit.`);
      this.canvas.width = width;
      this.canvas.height = height;
      this.imageData = this.context.createImageData(width, height);
    }
    resize(width, height) {
      if (!this.exports || this.disposed)
        return;
      this.devicePixelRatio = this.currentDevicePixelRatio(this.devicePixelRatio || this.scale || 1);
      const maxLogical = Math.max(1, Math.floor(this.canvasDimensionLimit() / (this.scale || 1)));
      const nextWidth = Math.min(maxLogical, Math.max(1, Math.floor(Number(width) || this.width || this.logicalWidth || 1)));
      const nextHeight = Math.min(maxLogical, Math.max(1, Math.floor(Number(height) || this.height || this.logicalHeight || 1)));
      const changed = nextWidth !== this.logicalWidth || nextHeight !== this.logicalHeight;
      if (!changed)
        return;
      this.logicalWidth = nextWidth;
      this.width = nextWidth;
      this.logicalHeight = nextHeight;
      this.height = nextHeight;
      this.configureCanvas();
      this.stopScheduled();
      const resizeFn = this.exports.web_resize_viewport || this.exports.web_resize;
      this.check(resizeFn.call(this.exports, this.host, nextWidth, nextHeight), "PocketJS viewport resize failed.");
      this.reportViewport();
      this.draw();
      this.drainOutbound();
      this.schedule();
    }
    allocBytes(text) {
      const bytes = text instanceof Uint8Array ? text : encodeUtf8(text);
      const pointer = this.exports.web_alloc(bytes.length);
      if (!pointer)
        throw new Error("PocketJS WASM could not allocate an input buffer.");
      new Uint8Array(this.exports.memory.buffer, pointer, bytes.length).set(bytes);
      return { pointer, length: bytes.length };
    }
    withBytes(text, callback) {
      const buffer = this.allocBytes(text);
      try {
        return callback(buffer.pointer, buffer.length);
      } finally {
        this.exports.web_free(buffer.pointer, buffer.length);
      }
    }
    check(code, fallback) {
      if (code === 0)
        return;
      let detail = "";
      try {
        const pointer = this.exports.web_result_ptr(this.host);
        const length = this.exports.web_result_len(this.host);
        if (pointer && length)
          detail = decodeUtf8(new Uint8Array(this.exports.memory.buffer, pointer, length));
      } catch (_) {}
      throw new Error(detail ? `${fallback} ${detail}` : fallback);
    }
    enqueueFromWasm(pointer, length) {
      if (!this.exports || length <= 0 || length > 64 * 1024 || this.outbound.length >= MAX_OUTBOUND)
        return 0;
      try {
        this.outbound.push(decodeMessage(new Uint8Array(this.exports.memory.buffer, pointer, length)));
      } catch (_) {
        return 0;
      }
      return 1;
    }
    inputFrame(contacts) {
      if (!this.exports || this.disposed || !this.visible)
        return;
      this.stopScheduled();
      if (this.system && this.system.root === this)
        this.system.input(contacts);
      else {
        this.advance(contacts);
        this.schedule();
      }
    }
    pushWorkerChannel(channel, data) {
      if (!this.exports || this.disposed || typeof this.exports.web_worker_channels_push !== "function")
        return false;
      const bytes = data instanceof Uint8Array ? data : new Uint8Array(data || []);
      const status = this.withBytes(bytes, (pointer, length) => this.exports.web_worker_channels_push(this.host, channel, pointer, length));
      if (status !== 0)
        return false;
      if (this.visible)
        this.wake();
      return true;
    }
    drainWorkerChannels() {
      if (!this.exports || this.disposed || typeof this.exports.web_worker_channels_take !== "function" || typeof this.onWorkerChannel !== "function")
        return;
      for (let pass = 0;pass < 8; pass += 1) {
        if (this.exports.web_worker_channels_take(this.host) !== 0)
          return;
        const pointer = this.exports.web_result_ptr(this.host);
        const length = this.exports.web_result_len(this.host);
        if (!pointer || !length)
          return;
        let packet;
        try {
          packet = decodeMessage(new Uint8Array(this.exports.memory.buffer, pointer, length));
        } catch (_) {
          return;
        }
        const records = Array.isArray(packet?.records) ? packet.records : [];
        if (!records.length)
          return;
        for (const record of records) {
          const channel = Number(record?.channel || 0);
          const data = record?.data instanceof Uint8Array ? record.data : Array.isArray(record?.data) && record.data.every((value) => Number.isInteger(value) && value >= 0 && value <= 255) ? Uint8Array.from(record.data) : null;
          if (channel > 0 && data)
            this.onWorkerChannel(channel, data);
        }
        if (records.length < 8)
          return;
      }
    }
    advance(contacts = this.contacts) {
      this.contacts = contacts.filter((contact) => !contact.cancelled);
      const input = this.sampleInput?.() || {};
      const facts = encodeMessage({
        buttons: (input.buttons || 0) >>> 0,
        analog: input.analog ?? 32896,
        rightAnalog: input.rightAnalog ?? 32896,
        contacts,
        axisDeltas: []
      });
      this.withBytes(facts, (pointer, length) => this.check(this.exports.web_advance(this.host, pointer, length, 1), "PocketJS guest frame failed."));
      this.check(this.exports.web_present(this.host), "PocketJS renderer failed to present DrawOps.");
      this.draw();
      this.drainOutbound();
      this.drainWorkerChannels();
    }
    draw() {
      if (this.headless) {
        this.system?.childFrame(this);
        return;
      }
      if (!this.exports || !this.imageData || !this.context)
        return;
      const pointer = this.system ? this.system.composite() : this.exports.web_pixels(this.host);
      const length = this.system ? this.logicalWidth * this.logicalHeight * this.scale * this.scale * 4 : this.exports.web_pixels_len(this.host);
      if (!pointer || length !== this.imageData.data.length)
        return;
      this.imageData.data.set(new Uint8ClampedArray(this.exports.memory.buffer, pointer, length));
      this.context.putImageData(this.imageData, 0, 0);
    }
    workState() {
      this.check(this.exports.web_wechat_work_state(this.host), "PocketJS scheduler state is unavailable.");
      const pointer = this.exports.web_result_ptr(this.host);
      const length = this.exports.web_result_len(this.host);
      return decodeMessage(new Uint8Array(this.exports.memory.buffer, pointer, length));
    }
    schedule() {
      if (!this.exports || !this.visible || this.disposed || this.running)
        return;
      let state;
      try {
        state = this.workState();
      } catch (error) {
        this.onError(error);
        return;
      }
      if (state.continuous) {
        this.running = true;
        this.rafUsesCanvas = !!this.canvas.requestAnimationFrame;
        const scheduleFrame = this.rafUsesCanvas ? (callback) => this.canvas.requestAnimationFrame(callback) : (callback) => setTimeout(callback, 16);
        this.raf = scheduleFrame(() => {
          this.running = false;
          this.raf = 0;
          if (!this.visible || this.disposed)
            return;
          this.advance();
          this.schedule();
        });
        return;
      }
      const frames = Number(state.framesUntilTimer || 0);
      if (frames <= 0)
        return;
      this.running = true;
      this.scheduledIdle = frames > 1 ? { frames, scheduledAt: Date.now(), hz: Math.max(1, Number(state.simulationHz) || 60) } : null;
      const delay = Math.max(1, Math.ceil(frames * 1000 / Math.max(1, Number(state.simulationHz) || 60)));
      this.timer = setTimeout(() => {
        this.running = false;
        this.timer = 0;
        this.scheduledIdle = null;
        if (!this.visible || this.disposed)
          return;
        if (frames > 1 && !this.disposed && this.exports && this.host) {
          this.exports.web_wechat_skip_idle_frames(this.host, frames - 1);
        }
        this.advance();
        this.schedule();
      }, delay);
    }
    wake(deferred = false) {
      if (!this.exports || this.disposed || !this.visible)
        return;
      if (deferred) {
        if (this.running && !this.scheduledIdle)
          return;
        this.stopScheduled();
        this.running = true;
        this.timer = setTimeout(() => {
          this.running = false;
          this.timer = 0;
          if (!this.visible || this.disposed)
            return;
          this.advance();
          this.schedule();
        }, 16);
        return;
      }
      this.stopScheduled();
      this.advance();
      this.schedule();
    }
    stopScheduled() {
      if (this.scheduledIdle) {
        const info = this.scheduledIdle;
        this.scheduledIdle = null;
        if (!this.disposed && this.exports && this.host) {
          const elapsedMs = Math.max(0, Date.now() - info.scheduledAt);
          const elapsedFrames = Math.min(Math.max(0, info.frames - 1), Math.floor(elapsedMs * info.hz / 1000));
          if (elapsedFrames > 0) {
            this.exports.web_wechat_skip_idle_frames(this.host, elapsedFrames);
          }
        }
      }
      if (this.raf) {
        if (this.rafUsesCanvas && this.canvas && this.canvas.cancelAnimationFrame)
          this.canvas.cancelAnimationFrame(this.raf);
        else
          clearTimeout(this.raf);
      }
      if (this.timer)
        clearTimeout(this.timer);
      this.raf = 0;
      this.rafUsesCanvas = false;
      this.timer = 0;
      this.running = false;
    }
    show() {
      if (this.disposed || !this.exports)
        return;
      this.visible = true;
      this.reportViewport();
      this.wake();
    }
    hide() {
      if (this.disposed)
        return;
      const hadInput = Boolean(this.input);
      this.contacts = [];
      this.visible = false;
      if (this.system?.root === this)
        this.system.suspend();
      this.stopScheduled();
      this.cancelPending("page inactive");
      this.imeDismiss({});
      if (hadInput && this.wx.hideKeyboard)
        this.wx.hideKeyboard({ complete: () => {} });
    }
    declared(capability) {
      const requires = this.config.requires || [];
      const optional = this.config.optional || [];
      if (capability.startsWith("platform.storage.")) {
        return requires.includes(capability) || optional.includes(capability) || requires.includes("platform.storage") || optional.includes("platform.storage");
      }
      return requires.includes(capability) || optional.includes(capability);
    }
    drainOutbound() {
      if (this.draining || this.disposed)
        return;
      this.draining = true;
      try {
        let passes = 0;
        while (this.outbound.length && passes++ < MAX_OUTBOUND * 2) {
          const event = this.outbound.shift();
          if (!event)
            continue;
          const name = event.name || event.method;
          const payload = event.payload || event.params || {};
          if (name === "host.request")
            this.handleRequest(payload);
          else if (name === "textInput.open")
            this.openInput(payload);
          else if (name === "textInput.update")
            this.updateInput(payload);
          else if (name === "textInput.close")
            this.closeInput(true);
        }
      } finally {
        this.draining = false;
      }
    }
    async handleRequest(request) {
      if (!isRecord(request) || typeof request.requestId !== "string" || typeof request.capability !== "string")
        return;
      if (this.disposed || !this.exports || !this.host)
        return;
      if (!this.visible) {
        this.respond(request, false, null, { code: "cancelled", message: "page inactive" });
        return;
      }
      if (this.pending.size >= MAX_REQUESTS) {
        this.respond(request, false, null, { code: "request_quota", message: `${this.hostLabel()} host request limit reached` });
        return;
      }
      if (!this.declared(request.capability)) {
        this.respond(request, false, null, { code: "permission_denied", message: `Capability is not declared: ${request.capability}` });
        return;
      }
      const systemTransport = this.system && this.system.handles(request.capability);
      const generation = this.generation;
      const record = { request, generation, timer: 0, cancelled: false, controller: createAbortController() };
      this.pending.set(request.requestId, record);
      record.timer = setTimeout(() => {
        if (!this.pending.delete(request.requestId))
          return;
        record.cancelled = true;
        record.controller.abort();
        this.respond(request, false, null, { code: "timeout", message: `${this.hostLabel()} host request timed out` });
      }, REQUEST_TIMEOUT_MS);
      try {
        const authorize = permissionHandler;
        if (systemTransport || isWechatBuiltinCapability(request.capability) || Object.hasOwn(this.capabilityHandlers, request.capability)) {} else if (typeof authorize === "function") {
          const allowed = await authorize(request.capability, request.params || {}, {
            wx: this.wx,
            signal: record.controller.signal
          });
          if (!allowed)
            throw this.error("permission_denied", "Permission request was cancelled");
        } else if (!request.capability.startsWith("platform.storage.")) {
          throw this.error("unconfigured", `No ${this.hostLabel()} handler is configured for ${request.capability}`);
        }
        if (record.cancelled || generation !== this.generation)
          return;
        const result = systemTransport ? await this.system.request(this, request, record.controller.signal) : await this.dispatchCapability(request.capability, request.params || {}, record.controller.signal);
        if (!this.pending.has(request.requestId) || generation !== this.generation || record.cancelled)
          return;
        this.respond(request, true, result, null);
        this.pending.delete(request.requestId);
        clearTimeout(record.timer);
      } catch (error) {
        if (!this.pending.delete(request.requestId) || generation !== this.generation || record.cancelled)
          return;
        clearTimeout(record.timer);
        const shape = error && error.code ? { code: String(error.code), message: String(error.message || error.code) } : { code: "host_error", message: String(error && error.message || error) };
        this.respond(request, false, null, shape);
      }
    }
    error(code, message) {
      const error = new Error(message);
      error.code = code;
      return error;
    }
    async dispatchCapability(capability, params, signal) {
      if (Object.hasOwn(this.capabilityHandlers, capability)) {
        return this.capabilityHandlers[capability](params, { signal, wx: this.wx });
      }
      if (isWechatBuiltinCapability(capability))
        return wechatBuiltinCapability(this, capability, params);
      if (capability.startsWith("platform.storage."))
        return this.storage(capability, params);
      const handler = capabilityHandlers[capability];
      if (typeof handler !== "function")
        throw this.error("unconfigured", `No ${this.hostLabel()} handler is configured for ${capability}`);
      return handler(params, { signal, wx: this.wx });
    }
    storageKey(namespace, key) {
      if (typeof key !== "string" || key.length < 1 || key.length > 512)
        throw this.error("invalid_argument", "Storage key must be 1 to 512 characters");
      if (namespace !== undefined && (typeof namespace !== "string" || namespace.length > 128))
        throw this.error("invalid_argument", "Storage namespace must be at most 128 characters");
      return `pocketjs:v1:${this.config.appId}:${namespace || "app"}:${key}`;
    }
    storage(capability, params) {
      const operation = capability.slice("platform.storage.".length);
      if (operation === "get") {
        const key = this.storageKey(params.namespace, params.key);
        return new Promise((resolve, reject) => this.wx.getStorage({
          key,
          success: (result) => {
            try {
              resolve(JSON.parse(result.data));
            } catch (_) {
              reject(this.error("storage_corrupt", "Stored PocketJS value is invalid JSON"));
            }
          },
          fail: (error) => {
            const message = String(error && error.errMsg || "");
            if (message.includes("not found") || message.includes("data not found"))
              resolve(null);
            else
              reject(this.error("storage_failed", message || `${this.hostLabel()} storage read failed`));
          }
        }));
      }
      if (operation === "set") {
        const key = this.storageKey(params.namespace, params.key);
        let value;
        try {
          value = JSON.stringify(params.value);
        } catch (_) {
          throw this.error("invalid_argument", "Storage value must be JSON serializable");
        }
        if (value === undefined || utf8Length(value) > MAX_STORAGE_ITEM_BYTES)
          throw this.error("quota_exceeded", `${this.hostLabel()} storage values are limited to 1 MiB per key`);
        return new Promise((resolve, reject) => this.wx.setStorage({
          key,
          data: value,
          success: () => resolve(null),
          fail: (error) => reject(this.error("storage_failed", String(error && error.errMsg || `${this.hostLabel()} storage write failed`)))
        }));
      }
      if (operation === "remove") {
        const key = this.storageKey(params.namespace, params.key);
        return new Promise((resolve, reject) => this.wx.removeStorage({
          key,
          success: () => resolve(null),
          fail: (error) => reject(this.error("storage_failed", String(error && error.errMsg || `${this.hostLabel()} storage removal failed`)))
        }));
      }
      if (operation === "keys") {
        const prefix = `pocketjs:v1:${this.config.appId}:${params.namespace || "app"}:`;
        return new Promise((resolve, reject) => this.wx.getStorageInfo({
          success: (info) => resolve((info.keys || []).filter((key) => key.startsWith(prefix)).map((key) => key.slice(prefix.length)).sort()),
          fail: (error) => reject(this.error("storage_failed", String(error && error.errMsg || `${this.hostLabel()} storage listing failed`)))
        }));
      }
      throw this.error("unsupported", `Unsupported ${this.hostLabel()} storage operation: ${operation}`);
    }
    respond(request, ok, result, error) {
      const packet = encodeMessage({
        type: "event",
        name: "host.response",
        payload: {
          requestId: request.requestId,
          capability: request.capability,
          ok,
          ...ok ? { result: result === undefined ? null : result } : { error }
        }
      }, request.capability.startsWith("media.live2d.model.") ? 4 * 1024 * 1024 : 64 * 1024);
      this.deliverResponse(packet);
    }
    deliverResponse(packet) {
      if (!this.exports || this.disposed)
        return;
      this.withBytes(packet, (pointer, length) => this.check(this.exports.web_wechat_deliver(this.host, pointer, length), "PocketJS rejected a host response."));
      this.drainOutbound();
      this.wake(true);
    }
    deliverGuestEvent(method, params, wake = true) {
      if (!this.exports || this.disposed)
        return;
      const methodBytes = this.allocBytes(method);
      const paramsBytes = this.allocBytes(encodeMessage(params || {}));
      try {
        this.check(this.exports.web_wechat_guest_event(this.host, methodBytes.pointer, methodBytes.length, paramsBytes.pointer, paramsBytes.length), "PocketJS rejected a native input event.");
      } finally {
        this.exports.web_free(methodBytes.pointer, methodBytes.length);
        this.exports.web_free(paramsBytes.pointer, paramsBytes.length);
      }
      this.drainOutbound();
      if (wake)
        this.wake();
    }
    inputStyle(value) {
      const rect = isRecord(value.rect) ? value.rect : { x: 8, y: 8, width: 240, height: 38 };
      const x = Math.max(0, Number(rect.x) || 0);
      const y = Math.max(0, Number(rect.y) || 0);
      const width = Math.max(40, Number(rect.width) || 240);
      const height = Math.max(28, Number(rect.height) || 38);
      const fontSize = [12, 14, 16].includes(value.fontSize) ? value.fontSize : 14;
      const radius = Math.max(0, Math.min(24, Number(value.borderRadius) || 8));
      const paddingH = Math.max(0, Number(value.paddingHorizontal) || 12);
      const paddingV = Math.max(0, Number(value.paddingVertical) || 8);
      return [
        `left:${x}px`,
        `top:${y}px`,
        `width:${width}px`,
        `height:${height}px`,
        `font-size:${fontSize}px`,
        `line-height:${Math.max(20, height - paddingV * 2)}px`,
        `color:${value.textColor || "#283444"}`,
        `background:${value.fillColor || "#ffffff"}`,
        `border:1px solid ${value.focusedBorderColor || value.borderColor || "#2676cb"}`,
        `border-radius:${radius}px`,
        `padding:0 ${paddingH}px`
      ].join(";");
    }
    openInput(value) {
      if (this.disposed || !this.visible)
        return;
      if (this.system) {
        const previous = this.system.imeOwner;
        if (previous && previous !== this)
          previous.closeInput(true);
        this.system.imeOwner = this;
      }
      const text = String(value.text ?? "");
      const requestedCursor = Number.isInteger(value.selectionExtent) ? value.selectionExtent : text.length;
      this.input = {
        id: value.id,
        editingSession: value.editingSession,
        revision: Number(value.revision) || 0,
        jsRevision: Number(value.jsRevision) || 0,
        text,
        cursor: Math.max(0, Math.min(text.length, requestedCursor)),
        placeholder: String(value.placeholder || ""),
        confirmType: value.action === "search" ? "search" : value.action === "next" ? "next" : "done",
        cursorSpacing: Math.max(0, Number(value.paddingVertical) || 8),
        style: this.inputStyle(value)
      };
      this.inputRevision = this.input.revision;
      this.onInput({ ...this.input, visible: true, focus: true });
    }
    updateInput(value) {
      if (this.disposed || !this.visible)
        return;
      if (!this.input || value.id !== undefined && String(value.id) !== String(this.input.id))
        return;
      if (value.editingSession && value.editingSession !== this.input.editingSession)
        return;
      const nextText = value.text !== undefined ? String(value.text) : this.input.text;
      const textChanged = nextText !== this.input.text;
      const requestedCursor = Number.isInteger(value.selectionExtent) ? value.selectionExtent : textChanged ? nextText.length : this.input.cursor;
      const nextCursor = Math.max(0, Math.min(nextText.length, requestedCursor));
      const cursorChanged = nextCursor !== this.input.cursor;
      this.input = {
        ...this.input,
        ...textChanged || cursorChanged ? { text: nextText, cursor: nextCursor } : {},
        ...value.revision !== undefined ? { revision: Number(value.revision) || this.input.revision } : {},
        ...value.jsRevision !== undefined ? { jsRevision: Number(value.jsRevision) || this.input.jsRevision } : {},
        ...value.rect ? { style: this.inputStyle({ ...this.input, ...value }) } : {}
      };
      this.inputRevision = this.input.revision;
      if (textChanged || cursorChanged || value.rect)
        this.onInput({ ...this.input, visible: true, focus: true });
    }
    closeInput(hideKeyboard) {
      if (!this.input)
        return;
      this.input = null;
      if (this.system?.imeOwner === this)
        this.system.imeOwner = null;
      this.onInput({ visible: false });
      if (hideKeyboard && this.wx.hideKeyboard)
        this.wx.hideKeyboard({ complete: () => {} });
    }
    imeEdit(detail) {
      if (this.system?.root === this && this.system.imeOwner && this.system.imeOwner !== this)
        return this.system.imeOwner.imeEdit(detail);
      if (!this.input)
        return;
      this.inputRevision += 1;
      const text = String(detail.value ?? "");
      const requestedCursor = Number.isInteger(detail.cursor) ? detail.cursor : text.length;
      const cursor = Math.max(0, Math.min(text.length, requestedCursor));
      this.input.text = text;
      this.input.cursor = cursor;
      this.deliverGuestEvent("textInput.edit", {
        id: this.input.id,
        editingSession: this.input.editingSession,
        revision: this.inputRevision,
        jsRevision: this.input.jsRevision,
        text,
        selectionBase: cursor,
        selectionExtent: cursor,
        composingBase: -1,
        composingExtent: -1
      });
    }
    imeSubmit(detail) {
      if (this.system?.root === this && this.system.imeOwner && this.system.imeOwner !== this)
        return this.system.imeOwner.imeSubmit(detail);
      if (!this.input)
        return;
      const text = String(detail.value ?? this.input.text ?? "");
      this.deliverGuestEvent("textInput.submit", {
        id: this.input.id,
        editingSession: this.input.editingSession,
        revision: this.inputRevision,
        jsRevision: this.input.jsRevision,
        text,
        selectionBase: text.length,
        selectionExtent: text.length,
        composingBase: -1,
        composingExtent: -1,
        action: this.input.confirmType
      });
    }
    imeDismiss(detail) {
      if (this.system?.root === this && this.system.imeOwner && this.system.imeOwner !== this)
        return this.system.imeOwner.imeDismiss(detail);
      if (!this.input)
        return;
      const input = this.input;
      this.input = null;
      if (this.system?.imeOwner === this)
        this.system.imeOwner = null;
      this.onInput({ visible: false });
      this.deliverGuestEvent("textInput.dismiss", {
        id: input.id,
        editingSession: input.editingSession,
        revision: this.inputRevision,
        jsRevision: input.jsRevision,
        reason: "blur",
        text: String(detail.value ?? input.text ?? "")
      });
    }
    cancelPending(reason) {
      this.generation += 1;
      const entries = Array.from(this.pending.values());
      this.pending.clear();
      for (const entry of entries) {
        if (entry.timer)
          clearTimeout(entry.timer);
        entry.cancelled = true;
        try {
          entry.controller.abort();
        } catch (_) {}
        if (!this.disposed && this.exports && this.host) {
          try {
            this.respond(entry.request, false, null, { code: "cancelled", message: reason || "cancelled" });
          } catch (_) {}
        }
      }
    }
    dispose() {
      if (this.disposed)
        return;
      this.disposed = true;
      this.visible = false;
      try {
        this.stopScheduled();
        this.cancelPending("host disposed");
        if (this.system?.root === this)
          this.system.dispose();
        this.closeInput(true);
      } finally {
        const exports2 = this.exports;
        const host = this.host;
        this.host = 0;
        this.outbound.length = 0;
        this.instance = null;
        this.exports = null;
        if (exports2 && host)
          exports2.web_destroy(host);
      }
    }
  }
  function registerCapability(name, handler) {
    if (typeof name !== "string" || !name || typeof handler !== "function")
      throw new TypeError("Capability registration requires a name and handler");
    capabilityHandlers[name] = handler;
    return () => {
      if (capabilityHandlers[name] === handler)
        delete capabilityHandlers[name];
    };
  }
  function setPermissionHandler(handler) {
    if (handler !== null && typeof handler !== "function")
      throw new TypeError("Permission handler must be a function or null");
    permissionHandler = handler;
  }
  function registeredCapabilityNames() {
    return Object.keys(capabilityHandlers);
  }
  function invokeRegisteredCapability(name, params, context) {
    const handler = capabilityHandlers[name];
    if (typeof handler !== "function")
      throw Object.assign(new Error(`No Web handler is configured for ${name}`), { code: "unconfigured" });
    return handler(params, context);
  }
  function requestCapabilityPermission(name, params, context) {
    if (typeof permissionHandler === "function")
      return permissionHandler(name, params, context);
    if (name.startsWith("platform.storage."))
      return true;
    throw Object.assign(new Error(`No Web permission handler is configured for ${name}`), { code: "unconfigured" });
  }
  module.exports = {
    PocketWechatHost,
    registerCapability,
    setPermissionHandler,
    registeredCapabilityNames,
    invokeRegisteredCapability,
    requestCapabilityPermission
  };
});

// targets/web/worker_transport.js
var require_worker_transport = __commonJS((exports, module) => {
  function createPocketWorkerTransport(options = {}) {
    const descriptor = options.descriptor;
    if (!descriptor || typeof descriptor !== "object")
      throw new TypeError("Worker descriptor is required");
    const engineUrl = String(options.engineUrl || "");
    const qjbcUrl = String(options.qjbcUrl || "");
    if (!engineUrl || !qjbcUrl)
      throw new TypeError("Worker engineUrl and qjbcUrl are required");
    const workerScript = `
const descriptor = ${JSON.stringify(descriptor)};
const engineUrl = ${JSON.stringify(engineUrl)};
const qjbcUrl = ${JSON.stringify(qjbcUrl)};
const origins = new Set(${JSON.stringify(Array.isArray(options.workerHttpOrigins) ? options.workerHttpOrigins.map(String) : [])});
const FACT = { ready: 1, complete: 2, data: 3, end: 4, timer: 6, channel: 7, headers: 8, error: 9 };
const STATUS = { ok: 0, failed: -1, cancelled: -2, unknown: -3, busy: -4, invalid: -5, unsupported: -6 };
let exportsRef, memory, workerPtr = 0, scratch = 0;
let closed = false, active = true, pumping = false, timer = 0, clockOffset = 0, pausedAt = 0, outputSequence = 1;
const resources = new Map(), requests = new Map(), queuedMessages = [], pendingReceives = [], pendingActions = [], pendingOutputs = new Map();
const MAX_QUEUED_MESSAGES = 64, MAX_PENDING_ACTIONS = 512;
const encoder = new TextEncoder(), decoder = new TextDecoder();
function wallNowMicros() { return Math.max(1, Math.floor((self.performance?.timeOrigin || Date.now()) * 1000 + (self.performance?.now?.() || 0) * 1000)); }
function nowMicros() {
  const wall = wallNowMicros();
  if (!active) { if (!pausedAt) pausedAt = wall; return Math.max(1, pausedAt - clockOffset); }
  if (pausedAt) { clockOffset += Math.max(0, wall - pausedAt); pausedAt = 0; }
  return Math.max(1, wall - clockOffset);
}
function bytesAt(pointer, length) { return new Uint8Array(memory.buffer, pointer, length).slice(); }
function withBytes(bytes, callback) {
  const value = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
  const pointer = exportsRef.web_alloc(value.length || 1);
  if (!pointer) throw new Error("Worker WASM allocation failed");
  try { new Uint8Array(memory.buffer, pointer, value.length).set(value); return callback(pointer, value.length); }
  finally { exportsRef.web_free(pointer, value.length || 1); }
}
function allowed(url) { try { return origins.has(new URL(url).origin); } catch (_) { return false; } }
function errorMessage(status, action) { return "PocketJS Worker " + action + " failed with status " + status; }
function runtimeError(fallback) {
  const pointer = exportsRef?.web_worker_error?.(workerPtr);
  if (!pointer || !memory) return fallback;
  const view = new Uint8Array(memory.buffer);
  let end = pointer;
  while (end < view.length && view[end]) end += 1;
  const message = decoder.decode(view.subarray(pointer, end));
  return message || fallback;
}
function invokeAction(action) {
  if (action.type === "emit") {
    return withBytes(action.payload, (pointer, length) => exportsRef.web_worker_emit(
      workerPtr, action.request, action.kind, action.status, action.offset, pointer, length));
  }
  return exportsRef.web_worker_finish(workerPtr, action.request, action.handle, action.status, action.offset);
}
function flushActions() {
  if (closed || !workerPtr) return;
  while (pendingActions.length) {
    const action = pendingActions[0];
    let status;
    try { status = invokeAction(action); }
    catch (error) {
      pendingActions.shift(); action.reject?.(error);
      self.postMessage({ type: "error", message: String(error?.message || error) });
      continue;
    }
    if (status === STATUS.busy) break;
    pendingActions.shift();
    if (status !== STATUS.ok) {
      const error = new Error(errorMessage(status, action.type));
      action.reject?.(error);
      self.postMessage({ type: "error", message: error.message });
    } else action.resolve?.();
  }
}
function enqueueAction(action) {
  if (closed || !workerPtr) return Promise.reject(new Error("PocketJS Worker is closed"));
  if (pendingActions.length >= MAX_PENDING_ACTIONS) return Promise.reject(new Error("PocketJS Worker fact queue is full"));
  return new Promise((resolve, reject) => {
    action.resolve = resolve; action.reject = reject;
    pendingActions.push(action);
    if (active) { flushActions(); if (!pumping) pump(); }
  });
}
function emit(kind, handle, request, status, offset, payload) {
  const bytes = payload instanceof Uint8Array ? payload.slice() : new Uint8Array(payload || []);
  return enqueueAction({ type: "emit", kind, handle, request, status, offset, payload: bytes });
}
function finish(request, handle, status, offset) {
  return enqueueAction({ type: "finish", request, handle, status, offset });
}
function schedulePump() {
  if (closed || !active || timer || pumping || !workerPtr) return;
  if (pendingReceives.length || pendingActions.length) {
    timer = setTimeout(() => { timer = 0; pump(); }, 0);
    return;
  }
  const deadline = Number(exportsRef.web_worker_deadline(workerPtr));
  if (!Number.isFinite(deadline) || deadline < 0) return;
  const delay = Math.max(1, Math.ceil((deadline - nowMicros()) / 1000));
  timer = setTimeout(() => { timer = 0; pump(); }, delay);
}
function flushReceives() {
  if (closed || !workerPtr) return;
  while (pendingReceives.length) {
    const message = pendingReceives[0];
    const data = message.data instanceof Uint8Array ? message.data : new Uint8Array(message.data || []);
    let status;
    try {
      status = withBytes(data, (pointer, length) => exportsRef.web_worker_receive(
        workerPtr, Number(message.channel || 0), pointer, length));
    } catch (error) {
      pendingReceives.shift();
      self.postMessage({ type: "error", message: String(error?.message || error) });
      continue;
    }
    if (status === STATUS.busy) break;
    pendingReceives.shift();
    if (message.seq) self.postMessage({ type: "channelAck", seq: message.seq, status });
    if (status !== STATUS.ok) self.postMessage({ type: "error", message: errorMessage(status, "channel receive") });
  }
}
function drainChannels() {
  if (pendingOutputs.size >= 8) return;
  const channels = Array.isArray(descriptor.declaration?.channels) ? descriptor.declaration.channels : [];
  const output = new Uint8Array(1024);
  if (!scratch) scratch = exportsRef.web_alloc(output.length);
  if (!scratch) throw new Error("Worker channel buffer allocation failed");
  for (let id = 1; id <= channels.length; id += 1) {
    if (channels[id - 1]?.direction !== "worker-to-ui") continue;
    for (let count = 0; count < 8 && pendingOutputs.size < 8; count += 1) {
      const length = exportsRef.web_worker_take(workerPtr, id, scratch, output.length);
      if (length < 0) break;
      const bytes = new Uint8Array(memory.buffer, scratch, length).slice();
      const seq = outputSequence++;
      pendingOutputs.set(seq, true);
      self.postMessage({ type: "channel", seq, channel: id, data: bytes }, [bytes.buffer]);
      if (length === 0) break;
    }
  }
}
function pump() {
  if (closed || !active || pumping || !workerPtr) return;
  pumping = true;
  try {
    flushReceives(); flushActions();
    for (let count = 0; count < 128; count += 1) {
      const result = exportsRef.web_worker_step(workerPtr, nowMicros());
      drainChannels();
      flushReceives(); flushActions();
      if (result !== 1) {
        if (result < 0) {
          const pointer = exportsRef.web_worker_error(workerPtr);
          let message = "PocketJS Worker failed";
          if (pointer) message = runtimeError(message);
          self.postMessage({ type: "error", message });
        }
        break;
      }
    }
  } finally { pumping = false; schedulePump(); }
}
function startHttp(handle, request) {
  const resource = resources.get(handle);
  if (!resource || !allowed(resource.options.url)) {
    void emit(FACT.error, handle, request, STATUS.unsupported, 0, new Uint8Array())
      .then(() => finish(request, handle, STATUS.unsupported, 0)).catch(() => {});
    return;
  }
  const controller = new AbortController();
  requests.set(request, { handle, controller });
  const timeoutValue = Number(resource.options.timeoutMs);
  const timeout = Math.max(1, Math.min(0x7fffffff, Number.isFinite(timeoutValue) && timeoutValue > 0 ? timeoutValue : 30000));
  const timeoutId = setTimeout(() => controller.abort(), timeout);
  (async () => {
    let offset = 0;
    try {
      const response = await fetch(String(resource.options.url), { method: String(resource.options.method || "GET"), headers: resource.options.headers || {}, body: resource.options.body, redirect: "error", signal: controller.signal });
      const headers = {};
      response.headers?.forEach?.((value, key) => { if (Object.keys(headers).length < 32) headers[String(key).toLowerCase()] = String(value).slice(0, 256); });
      let headerBytes = encoder.encode(JSON.stringify({ status: response.status, url: response.url, headers }));
      if (headerBytes.length > 1024) headerBytes = encoder.encode(JSON.stringify({ status: response.status, url: response.url }));
      await emit(FACT.ready, handle, request, STATUS.ok, 0, new Uint8Array());
      await emit(FACT.headers, handle, request, STATUS.ok, 0, headerBytes);
      if (response.body && String(resource.options.method || "GET") !== "HEAD") {
        const reader = response.body.getReader();
        const maxValue = Number(resource.options.maxBytes);
        const maxBytes = Math.max(1, Math.min(262144, Number.isFinite(maxValue) && maxValue > 0 ? maxValue : 262144));
        while (true) {
          const part = await reader.read();
          if (part.done) break;
          const bytes = part.value instanceof Uint8Array ? part.value : new Uint8Array(part.value || []);
          if (offset + bytes.length > maxBytes) throw Object.assign(new Error("HTTP response exceeds maxBytes"), { code: STATUS.failed });
          for (let at = 0; at < bytes.length; at += 1024) {
            const chunk = bytes.slice(at, Math.min(bytes.length, at + 1024));
            await emit(FACT.data, handle, request, STATUS.ok, offset, chunk); offset += chunk.length;
          }
        }
      }
      // The pinned core owns END/COMPLETE ordering. web_worker_emit only
      // accepts non-terminal facts; web_worker_finish appends END followed
      // by the canonical completion once all queued headers/data are seen.
      await finish(request, handle, STATUS.ok, offset);
    } catch (error) {
      const status = error?.name === "AbortError" ? STATUS.cancelled : (Number(error?.code) || STATUS.failed);
      try { await emit(FACT.error, handle, request, status, offset, new Uint8Array()); await finish(request, handle, status, offset); }
      catch (_) { /* The worker realm is already faulted or being disposed. */ }
    } finally { clearTimeout(timeoutId); requests.delete(request); pump(); }
  })();
}
function operation(op, handle, request, opcode, payloadPointer, payloadLength, capacity) {
  if (closed) return STATUS.cancelled;
  const payload = payloadLength > 0 ? bytesAt(payloadPointer, payloadLength) : new Uint8Array();
  if (op === 0) {
    let options; try { options = JSON.parse(decoder.decode(payload)); } catch (_) { return STATUS.invalid; }
    if (typeof options.url !== "string" || !allowed(options.url)) return STATUS.unsupported;
    resources.set(handle, { options }); return STATUS.ok;
  }
  if (op === 1) {
    if (!resources.has(handle) || opcode !== 1) return STATUS.invalid;
    if (!request) return STATUS.invalid;
    startHttp(handle, request); return STATUS.ok;
  }
  if (op === 2) { const pending = requests.get(request); if (!pending) return STATUS.invalid; pending.controller.abort(); return STATUS.ok; }
  if (op === 3) { const resource = resources.get(handle); if (!resource) return STATUS.invalid; for (const [id, pending] of requests) if (pending.handle === handle) { pending.controller.abort(); requests.delete(id); } resources.delete(handle); return STATUS.ok; }
  if (op === 4) return STATUS.unsupported;
  if (op === 5) return resources.has(handle) && opcode === 1 && payloadLength === 0 && capacity === 0 ? STATUS.ok : STATUS.invalid;
  return STATUS.invalid;
}
function receiveChannel(message) {
  const id = Number(message.channel || 0);
  const channels = Array.isArray(descriptor.declaration?.channels) ? descriptor.declaration.channels : [];
  const channel = channels[id - 1];
  const data = message.data instanceof Uint8Array ? message.data.slice() : new Uint8Array(message.data || []);
  if (!channel || channel.direction !== "ui-to-worker" || data.length > Number(channel.recordBytes || 0)) {
    if (message.seq) self.postMessage({ type: "channelAck", seq: message.seq, status: STATUS.invalid });
    self.postMessage({ type: "error", message: "PocketJS Worker channel input violates its descriptor" }); return;
  }
  if (!workerPtr) {
    if (queuedMessages.length >= MAX_QUEUED_MESSAGES) { if (message.seq) self.postMessage({ type: "channelAck", seq: message.seq, status: STATUS.busy }); self.postMessage({ type: "error", message: "PocketJS Worker channel bootstrap queue is full" }); return; }
    queuedMessages.push({ channel: id, data, seq: message.seq }); return;
  }
  if (pendingReceives.length >= MAX_QUEUED_MESSAGES) { if (message.seq) self.postMessage({ type: "channelAck", seq: message.seq, status: STATUS.busy }); self.postMessage({ type: "error", message: "PocketJS Worker channel queue is full" }); return; }
  pendingReceives.push({ channel: id, data, seq: message.seq });
  if (active) { flushReceives(); if (!pumping) pump(); }
}
async function boot() {
  const [wasmResponse, qjbcResponse] = await Promise.all([fetch(engineUrl), fetch(qjbcUrl)]);
  if (!wasmResponse.ok || !qjbcResponse.ok) throw new Error("PocketJS Worker artifact fetch failed");
  const wasmBytes = await wasmResponse.arrayBuffer();
  const qjbc = new Uint8Array(await qjbcResponse.arrayBuffer());
  const imports = { env: { __rquickjs_host_now_us: nowMicros }, pocket_web_worker: { now_micros: nowMicros, operation }, pocket_wechat: { host_emit: () => 0 } };
  const loaded = await WebAssembly.instantiate(wasmBytes, imports);
  exportsRef = loaded.instance?.exports || loaded.exports; memory = exportsRef.memory;
  if (typeof exportsRef.web_worker_create !== "function") throw new Error("PocketJS Web engine has no pinned Worker ABI");
  const config = encoder.encode(JSON.stringify(descriptor));
  workerPtr = withBytes(qjbc, (qjbcPointer, qjbcLength) => withBytes(config, (configPointer, configLength) => exportsRef.web_worker_create(qjbcPointer, qjbcLength, configPointer, configLength, Number(descriptor.tickHz || 60))));
  if (!workerPtr) throw new Error(runtimeError("PocketJS Worker QJBC was rejected"));
  self.postMessage({ type: "ready" });
  while (queuedMessages.length) receiveChannel(queuedMessages.shift());
  pump();
}
self.onmessage = event => { const message = event.data || {}; if (message.type === "channel") receiveChannel(message); else if (message.type === "outputAck") { pendingOutputs.delete(Number(message.seq || 0)); if (active) pump(); } else if (message.type === "active") { if (message.active && !active) { active = true; nowMicros(); } else if (!message.active && active) { pausedAt = wallNowMicros(); active = false; if (timer) { clearTimeout(timer); timer = 0; } } if (active) pump(); } else if (message.type === "dispose") { if (timer) clearTimeout(timer); if (workerPtr) exportsRef.web_worker_destroy(workerPtr); workerPtr = 0; if (scratch) exportsRef?.web_free(scratch, 1024); scratch = 0; closed = true; close(); } };
boot().catch(error => self.postMessage({ type: "error", message: String(error?.message || error) }));
`;
    const blobUrl = URL.createObjectURL(new Blob([workerScript], { type: "text/javascript" }));
    const worker = new Worker(blobUrl);
    const listeners = new Set;
    const inbound = [], inflight = new Map;
    const maxInbound = 64, maxInflight = 8;
    let sequence = 1;
    const outbound = [];
    const maxOutbound = 64;
    let closed = false, active = true, outboundTimer = 0;
    let readyResolve, readyReject;
    let settled = false;
    const ready = new Promise((resolve, reject) => {
      readyResolve = resolve;
      readyReject = reject;
    });
    const fail = (error) => {
      const value = error instanceof Error ? error : new Error(String(error?.message || error || "PocketJS Worker failed"));
      if (!settled) {
        settled = true;
        readyReject(value);
      }
      options.onError?.(value);
    };
    const flushOutbound = () => {
      if (closed || !active || outboundTimer)
        return;
      while (outbound.length) {
        const message = outbound[0];
        const accepted = listeners.size > 0 && [...listeners].every((listener) => listener(message.channel, message.data) !== false);
        if (!accepted) {
          outboundTimer = setTimeout(() => {
            outboundTimer = 0;
            flushOutbound();
          }, 16);
          return;
        }
        outbound.shift();
        worker.postMessage({ type: "outputAck", seq: message.seq });
      }
    };
    const pumpInbound = () => {
      if (closed)
        return;
      while (inflight.size < maxInflight && inbound.length) {
        const message = inbound.shift();
        const seq = sequence++;
        inflight.set(seq, message);
        const copy = message.data.slice();
        worker.postMessage({ type: "channel", seq, channel: message.channel, data: copy }, [copy.buffer]);
      }
    };
    worker.onmessage = (event) => {
      if (closed)
        return;
      const message = event.data || {};
      if (message.type === "ready") {
        if (!settled) {
          settled = true;
          readyResolve();
        }
      } else if (message.type === "channelAck") {
        const pending = inflight.get(Number(message.seq || 0));
        if (!pending)
          return;
        inflight.delete(Number(message.seq || 0));
        const status = Number(message.status);
        if (status === -4)
          inbound.unshift(pending);
        else if (status !== 0)
          fail(new Error("PocketJS Worker channel receive failed with status " + status));
        if (active)
          pumpInbound();
      } else if (message.type === "channel") {
        if (outbound.length >= maxOutbound) {
          fail(new Error("PocketJS Worker output channel queue is full"));
          return;
        }
        outbound.push({ seq: Number(message.seq || 0), channel: Number(message.channel || 0), data: new Uint8Array(message.data || []) });
        flushOutbound();
      } else if (message.type === "error")
        fail(new Error(String(message.message || "PocketJS Worker failed")));
    };
    worker.onerror = (error) => fail(error);
    return {
      ready,
      setActive(value) {
        if (closed)
          return;
        active = !!value;
        if (!active && outboundTimer) {
          clearTimeout(outboundTimer);
          outboundTimer = 0;
        }
        worker.postMessage({ type: "active", active });
        if (active) {
          pumpInbound();
          flushOutbound();
        }
      },
      receive(channel, data) {
        if (closed)
          return false;
        if (inbound.length + inflight.size >= maxInbound) {
          fail(new Error("PocketJS Worker input channel queue is full"));
          return false;
        }
        const copy = data instanceof Uint8Array ? data.slice() : new Uint8Array(data || []);
        inbound.push({ channel, data: copy });
        if (active)
          pumpInbound();
        return true;
      },
      subscribe(listener) {
        listeners.add(listener);
        return () => listeners.delete(listener);
      },
      dispose() {
        if (closed)
          return;
        worker.postMessage({ type: "dispose" });
        closed = true;
        setTimeout(() => worker.terminate(), 1000);
        if (outboundTimer)
          clearTimeout(outboundTimer);
        URL.revokeObjectURL(blobUrl);
        listeners.clear();
        outbound.length = 0;
        inbound.length = 0;
        inflight.clear();
      }
    };
  }
  module.exports = { createPocketWorkerTransport };
});

// targets/web/render_observations.js
var require_render_observations = __commonJS((exports, module) => {
  function observeRenderHost(host, mode) {
    let frameCount = 0, frameDurationMs = 0;
    const advance = host.advance.bind(host);
    host.advance = (...args) => {
      const start = performance.now();
      try {
        const value = advance(...args);
        frameCount++;
        return value;
      } finally {
        frameDurationMs += performance.now() - start;
      }
    };
    return {
      inspect() {
        if (!host.exports || !host.host || host.disposed)
          throw new Error("PocketJS runtime is not mounted");
        const ex = host.exports, nodes = [], queue = [0, 1], seen = new Set;
        while (queue.length && seen.size < 16384) {
          const id = queue.shift();
          if (seen.has(id))
            continue;
          seen.add(id);
          if (ex.web_inspect(host.host, id) !== 0)
            throw new Error("PocketJS node inspection failed");
          const bytes = new Uint8Array(ex.memory.buffer, ex.web_result_ptr(host.host), ex.web_result_len(host.host));
          const node = JSON.parse(new TextDecoder().decode(bytes));
          if (!node)
            continue;
          nodes.push({ ...node, id });
          if (Array.isArray(node.children))
            queue.push(...node.children);
        }
        return { nodes };
      },
      stats() {
        return {
          mode,
          thread: mode === "worker" ? "worker" : "main",
          frameCount,
          frameDurationMs,
          width: host.logicalWidth,
          height: host.logicalHeight,
          pixelWidth: host.canvas.width,
          pixelHeight: host.canvas.height,
          visible: host.visible,
          disposed: host.disposed
        };
      }
    };
  }
  module.exports = { observeRenderHost };
});

// targets/web/render_worker.js
var require_render_worker = __commonJS((exports, module) => {
  var { PocketWechatHost, registerCapability, setPermissionHandler } = require_wechat_host();
  var { createPocketWorkerTransport } = require_worker_transport();
  var { observeRenderHost } = require_render_observations();
  var workerGlobal = typeof self !== "undefined" ? self : globalThis;
  var pendingBoundary = new Map;
  var boundarySequence = 1;
  var session = null;
  function post(message, transfer = []) {
    workerGlobal.postMessage?.(message, transfer);
  }
  function errorShape(error) {
    return { message: String(error?.message || error || "PocketJS render worker failed"), ...error?.code ? { code: String(error.code) } : {} };
  }
  function fail(code, message) {
    const error = new Error(message);
    error.code = code;
    return error;
  }
  function baseUrl() {
    try {
      return new URL(workerGlobal.location?.href || "http://localhost/");
    } catch (_) {
      return new URL("http://localhost/");
    }
  }
  function absoluteUrl(value, base = baseUrl()) {
    if (!value)
      return null;
    try {
      return new URL(String(value), base).href;
    } catch (_) {
      throw fail("invalid_argument", `Invalid render-worker URL: ${value}`);
    }
  }
  function boundary(operation, params, signal) {
    if (pendingBoundary.size >= 32)
      return Promise.reject(fail("request_quota", "Render-worker boundary queue is full"));
    const id = boundarySequence++;
    post({ type: "boundary", id, operation, params });
    return new Promise((resolve, reject) => {
      const pending = { resolve, reject, cleanup: () => {} };
      pendingBoundary.set(id, pending);
      const abort = () => {
        if (!pendingBoundary.delete(id))
          return;
        pending.cleanup();
        post({ type: "boundaryCancel", id });
        reject(fail("cancelled", "Render-worker boundary request cancelled"));
      };
      pending.cleanup = () => signal?.removeEventListener?.("abort", abort);
      if (signal?.aborted)
        abort();
      else
        signal?.addEventListener?.("abort", abort, { once: true });
    });
  }
  function browserWx(state) {
    const wx = {
      __pocketBrowserPreview: true,
      __pocketBrowserDevicePixelRatio: () => state.devicePixelRatio,
      WXWebAssembly: { instantiate: async (_path, imports) => {
        const response = await fetch(state.engineUrl, { cache: state.cache || "no-store" });
        if (!response.ok)
          throw new Error(`PocketJS WASM HTTP ${response.status}`);
        return WebAssembly.instantiate(await response.arrayBuffer(), imports);
      } },
      getWindowInfo: () => ({
        windowWidth: state.width,
        windowHeight: state.height,
        screenWidth: state.width,
        screenHeight: state.height,
        pixelRatio: state.devicePixelRatio,
        safeArea: { left: 0, top: 0, right: state.width, bottom: state.height }
      }),
      getSystemInfoSync: () => wx.getWindowInfo(),
      hideKeyboard: ({ complete } = {}) => {
        if (typeof complete === "function")
          complete();
      },
      getStorage: ({ key, success, fail: onFail } = {}) => {
        boundary("storage.get", { key: String(key) }).then((value) => {
          if (!value || typeof value !== "object" || !Object.prototype.hasOwnProperty.call(value, "data")) {
            onFail?.({ errMsg: "data not found" });
          } else
            success?.(value);
        }).catch((error) => onFail?.({ errMsg: String(error?.message || error) }));
      },
      setStorage: ({ key, data, success, fail: onFail } = {}) => {
        boundary("storage.set", { key: String(key), data }).then(() => success?.()).catch((error) => onFail?.({ errMsg: String(error?.message || error) }));
      },
      removeStorage: ({ key, success, fail: onFail } = {}) => {
        boundary("storage.remove", { key: String(key) }).then(() => success?.()).catch((error) => onFail?.({ errMsg: String(error?.message || error) }));
      },
      getStorageInfo: ({ success, fail: onFail } = {}) => {
        boundary("storage.info", {}).then((value) => success?.({ keys: value?.keys || [], currentSize: 0, limitSize: 0 })).catch((error) => onFail?.({ errMsg: String(error?.message || error) }));
      }
    };
    return wx;
  }
  function installBoundaryHandlers(names) {
    const unregister = [];
    for (const name of names) {
      if (typeof name !== "string" || !name)
        continue;
      unregister.push(registerCapability(name, (params, context) => boundary("capability.invoke", { capability: name, params }, context?.signal)));
    }
    setPermissionHandler((name, params, context) => boundary("permission", { capability: name, params }, context?.signal).then((value) => Boolean(value)));
    return unregister;
  }
  function currentState(state) {
    return state.observation.stats();
  }
  async function disposeSession() {
    const state = session;
    if (state && !state.disposed) {
      state.disposed = true;
      state.active = false;
      try {
        state.workerTransport?.dispose();
      } catch (_) {}
      try {
        state.host?.dispose();
      } catch (_) {}
      for (const unregister of state.unregister || []) {
        try {
          unregister();
        } catch (_) {}
      }
      state.unregister = [];
    }
    for (const [id, pending] of pendingBoundary) {
      pendingBoundary.delete(id);
      pending.cleanup?.();
      post({ type: "boundaryCancel", id });
      pending.reject(fail("cancelled", "Render-worker disposed"));
    }
    setPermissionHandler(null);
    session = null;
  }
  async function init(message) {
    if (session && !session.disposed)
      throw fail("invalid_state", "PocketJS render worker is already initialized");
    if (!message.canvas || typeof message.canvas.getContext !== "function")
      throw fail("invalid_argument", "Render worker requires a transferred OffscreenCanvas");
    const fallback = baseUrl();
    const state = {
      canvas: message.canvas,
      context: message.canvas.getContext("2d", { alpha: true }),
      engineUrl: absoluteUrl(message.engineUrl, fallback),
      qjbcUrl: absoluteUrl(message.qjbcUrl, fallback),
      pakUrl: absoluteUrl(message.pakUrl, fallback),
      cache: message.cache,
      width: Math.max(1, Math.floor(Number(message.width) || message.canvas.width || 1)),
      height: Math.max(1, Math.floor(Number(message.height) || message.canvas.height || 1)),
      devicePixelRatio: Math.max(0.25, Math.min(4, Number(message.devicePixelRatio) || 1)),
      active: true,
      disposed: false,
      inputSample: {},
      workerTransport: null,
      host: null,
      observation: null,
      unregister: []
    };
    if (!state.context)
      throw fail("unsupported", "Render worker requires OffscreenCanvas 2D context");
    if (Boolean(state.qjbcUrl) !== Boolean(state.pakUrl)) {
      throw fail("invalid_argument", "Render worker requires both qjbcUrl and pakUrl");
    }
    const config = { ...message.config || {}, provider: "web", host: "web", hostRuntime: "WebAssembly + OffscreenCanvas", enginePath: state.engineUrl };
    state.unregister = installBoundaryHandlers(Array.isArray(message.capabilityNames) ? message.capabilityNames : []);
    const host = new PocketWechatHost({
      wx: browserWx(state),
      config,
      canvas: state.canvas,
      context: state.context,
      onInput: (value) => post({ type: "input", value }),
      onError: (error) => post({ type: "error", error: errorShape(error) }),
      isActive: () => state.active && !state.disposed,
      sampleInput: () => state.inputSample,
      onWorkerChannel: (channel, data) => state.workerTransport?.receive(channel, data)
    });
    state.host = host;
    state.observation = observeRenderHost(host, "worker");
    session = state;
    try {
      if (state.qjbcUrl && state.pakUrl) {
        const [qjbcResponse, pakResponse] = await Promise.all([
          fetch(state.qjbcUrl, { cache: state.cache || "no-store" }),
          fetch(state.pakUrl, { cache: state.cache || "no-store" })
        ]);
        if (!qjbcResponse.ok || !pakResponse.ok)
          throw new Error("PocketJS render-worker Guest artifact fetch failed");
        const hostAbi = Number(config.bindingGeneration ?? config.hostAbi);
        if (!Number.isInteger(hostAbi) || hostAbi < 1) {
          throw fail("invalid_argument", "Render worker external Guest requires bindingGeneration");
        }
        config.externalGuest = {
          qjbc: new Uint8Array(await qjbcResponse.arrayBuffer()),
          pak: new Uint8Array(await pakResponse.arrayBuffer()),
          tickHz: Number(config.tickHz || 60),
          hostAbi
        };
      }
      await host.start(state.width, state.height, state.devicePixelRatio);
      const workerConfig = config.worker && typeof config.worker === "object" ? config.worker : null;
      const descriptor = workerConfig?.descriptor && typeof workerConfig.descriptor === "object" ? workerConfig.descriptor : workerConfig;
      if (workerConfig && descriptor) {
        const workerQjbc = absoluteUrl(workerConfig.bytecode || "app.worker.qjbc", state.qjbcUrl ? new URL(state.qjbcUrl) : fallback);
        state.workerTransport = createPocketWorkerTransport({
          descriptor,
          engineUrl: state.engineUrl,
          qjbcUrl: workerQjbc,
          workerHttpOrigins: config.workerHttpOrigins,
          onError: (error) => post({ type: "error", error: errorShape(error) })
        });
        state.workerTransport.subscribe((channel, data) => host.pushWorkerChannel(channel, data));
        await state.workerTransport.ready;
      }
      host.show();
      return { thread: "worker", width: state.width, height: state.height, scale: host.scale, worker: Boolean(state.workerTransport) };
    } catch (error) {
      await disposeSession();
      throw error;
    }
  }
  async function command(message) {
    if (!session || session.disposed || !session.host)
      throw fail("invalid_state", "PocketJS render worker is not mounted");
    const state = session, host = state.host, args = message.args && typeof message.args === "object" ? message.args : {};
    switch (message.method) {
      case "resize": {
        const width = Math.max(1, Math.floor(Number(args.width) || state.width));
        const height = Math.max(1, Math.floor(Number(args.height) || state.height));
        if (args.devicePixelRatio !== undefined) {
          const ratio = Number(args.devicePixelRatio);
          if (Number.isFinite(ratio) && ratio > 0)
            state.devicePixelRatio = Math.max(0.25, Math.min(4, ratio));
        }
        state.width = width;
        state.height = height;
        host.resize(width, height);
        return currentState(state);
      }
      case "show":
        state.active = true;
        host.show();
        state.workerTransport?.setActive(true);
        return currentState(state);
      case "hide":
        state.active = false;
        state.workerTransport?.setActive(false);
        host.hide();
        return currentState(state);
      case "inputFrame":
        state.inputSample = args.inputSample && typeof args.inputSample === "object" ? { ...args.inputSample } : {};
        host.inputFrame(Array.isArray(args.contacts) ? args.contacts : []);
        return currentState(state);
      case "imeEdit":
        host.imeEdit(args.detail || args);
        return null;
      case "imeSubmit":
        host.imeSubmit(args.detail || args);
        return null;
      case "imeDismiss":
        host.imeDismiss(args.detail || args);
        return null;
      case "inspect":
        return state.observation.inspect();
      case "stats":
        return currentState(state);
      case "dispose":
        await disposeSession();
        return { disposed: true, thread: "worker" };
      default:
        throw fail("unsupported", `Unsupported render-worker command: ${message.method}`);
    }
  }
  async function handle(message) {
    if (!message || typeof message !== "object")
      return;
    if (message.type === "boundaryResult") {
      const pending = pendingBoundary.get(Number(message.id));
      if (!pending)
        return;
      pendingBoundary.delete(Number(message.id));
      pending.cleanup?.();
      if (message.error || message.ok === false)
        pending.reject(fail(message.error?.code || "host_error", message.error?.message || "Render-worker boundary failed"));
      else
        pending.resolve(Object.prototype.hasOwnProperty.call(message, "result") ? message.result : message);
      return;
    }
    if (message.type !== "init" && message.type !== "command")
      return;
    try {
      post({ type: "reply", id: message.id, result: message.type === "init" ? await init(message) : await command(message) });
    } catch (error) {
      if (message.id !== undefined)
        post({ type: "reply", id: message.id, error: errorShape(error) });
      else
        post({ type: "error", error: errorShape(error) });
    }
  }
  workerGlobal.onmessage = (event) => {
    handle(event.data);
  };
  module.exports = { handle };
});
export default require_render_worker();
