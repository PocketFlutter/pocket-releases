var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);

// targets/wechat/template/binary-bridge.js
var require_binary_bridge = __commonJS((exports, module) => {
  var MAX_BYTES = 64 * 1024;
  var MAX_DEPTH = 32;
  function utf8(value, maxBytes) {
    let length = 0;
    for (const character of value) {
      const code = character.codePointAt(0);
      length += code < 128 ? 1 : code < 2048 ? 2 : code < 65536 ? 3 : 4;
      if (length > maxBytes)
        throw new Error("Pocket binary message exceeds size limit");
    }
    const bytes = new Uint8Array(length);
    let offset = 0;
    const put = (byte) => {
      bytes[offset++] = byte;
    };
    for (const character of value) {
      let code = character.codePointAt(0);
      if (code >= 55296 && code <= 57343)
        code = 65533;
      if (code < 128)
        put(code);
      else if (code < 2048) {
        put(192 | code >> 6);
        put(128 | code & 63);
      } else if (code < 65536) {
        put(224 | code >> 12);
        put(128 | code >> 6 & 63);
        put(128 | code & 63);
      } else {
        put(240 | code >> 18);
        put(128 | code >> 12 & 63);
        put(128 | code >> 6 & 63);
        put(128 | code & 63);
      }
    }
    return bytes;
  }
  function text(bytes) {
    let binary = "";
    for (let i = 0;i < bytes.length; i += 8192)
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
    return decodeURIComponent(escape(binary));
  }
  function encodeMessage(value, limit = MAX_BYTES) {
    if (!Number.isInteger(limit) || limit < 1 || limit > 4 * 1024 * 1024)
      throw new Error("Invalid Pocket binary message limit");
    let bytes = new Uint8Array(Math.min(limit, 256));
    let view = new DataView(bytes.buffer);
    let offset = 0;
    const ancestors = new Set;
    function need(n) {
      if (n > limit - offset)
        throw new Error("Pocket binary message exceeds size limit");
      if (offset + n <= bytes.length)
        return;
      const grown = new Uint8Array(Math.min(limit, Math.max(offset + n, bytes.length * 2)));
      grown.set(bytes);
      bytes = grown;
      view = new DataView(bytes.buffer);
    }
    function u8(n) {
      need(1);
      bytes[offset++] = n;
    }
    function u32(n) {
      need(4);
      view.setUint32(offset, n, true);
      offset += 4;
    }
    function raw(value2) {
      u32(value2.length);
      need(value2.length);
      bytes.set(value2, offset);
      offset += value2.length;
    }
    function write(value2, depth) {
      if (depth > MAX_DEPTH)
        throw new Error("Pocket binary message nesting is too deep");
      if (value2 == null) {
        u8(0);
        return;
      }
      if (typeof value2 === "boolean") {
        u8(value2 ? 2 : 1);
        return;
      }
      if (typeof value2 === "number") {
        if (!Number.isFinite(value2))
          throw new Error("Pocket binary number must be finite");
        if (Number.isSafeInteger(value2)) {
          u8(3);
          need(8);
          view.setUint32(offset, value2 >>> 0, true);
          view.setInt32(offset + 4, Math.floor(value2 / 4294967296), true);
        } else {
          u8(4);
          need(8);
          view.setFloat64(offset, value2, true);
        }
        offset += 8;
        return;
      }
      if (typeof value2 === "string") {
        u8(5);
        raw(utf8(value2, limit - offset - 4));
        return;
      }
      if (value2 instanceof ArrayBuffer)
        value2 = new Uint8Array(value2);
      if (value2 instanceof Uint8Array) {
        u8(6);
        raw(value2);
        return;
      }
      if (typeof value2 !== "object")
        throw new Error("Unsupported Pocket binary value");
      if (ancestors.has(value2))
        throw new Error("Cyclic Pocket binary message");
      ancestors.add(value2);
      try {
        if (Array.isArray(value2)) {
          u8(7);
          u32(value2.length);
          for (let i = 0;i < value2.length; i++)
            write(value2[i], depth + 1);
        } else {
          const prototype = Object.getPrototypeOf(value2);
          if (prototype !== Object.prototype && prototype !== null)
            throw new Error("Pocket binary value must be a plain object");
          const keys = Object.keys(value2).filter((key) => value2[key] !== undefined && typeof value2[key] !== "function");
          u8(8);
          u32(keys.length);
          for (const key of keys) {
            raw(utf8(key, limit - offset - 4));
            write(value2[key], depth + 1);
          }
        }
      } finally {
        ancestors.delete(value2);
      }
    }
    if (!value || typeof value !== "object" || Array.isArray(value) || value instanceof Uint8Array)
      throw new Error("Pocket message root must be an object");
    u8(177);
    write(value, 0);
    return bytes.slice(0, offset);
  }
  function decodeMessage(bytes, limit = MAX_BYTES) {
    if (!(bytes instanceof Uint8Array) || bytes.length > limit)
      throw new Error("Invalid Pocket binary message size");
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let offset = 0;
    function need(n) {
      if (n > bytes.length - offset)
        throw new Error("Truncated Pocket binary message");
    }
    function u8() {
      need(1);
      return bytes[offset++];
    }
    function u32() {
      need(4);
      const n = view.getUint32(offset, true);
      offset += 4;
      return n;
    }
    function raw() {
      const n = u32();
      need(n);
      const value2 = bytes.slice(offset, offset + n);
      offset += n;
      return value2;
    }
    function read(depth) {
      if (depth > MAX_DEPTH)
        throw new Error("Pocket binary message nesting is too deep");
      const tag = u8();
      if (tag === 0)
        return null;
      if (tag === 1 || tag === 2)
        return tag === 2;
      if (tag === 3 || tag === 4) {
        need(8);
        const value2 = tag === 4 ? view.getFloat64(offset, true) : view.getInt32(offset + 4, true) * 4294967296 + view.getUint32(offset, true);
        offset += 8;
        if (!Number.isFinite(value2) || tag === 3 && !Number.isSafeInteger(value2))
          throw new Error("Invalid Pocket binary number");
        return value2;
      }
      if (tag === 5)
        return text(raw());
      if (tag === 6)
        return raw();
      if (tag === 7 || tag === 8) {
        const n = u32();
        if (n > bytes.length - offset)
          throw new Error("Invalid Pocket binary collection count");
        if (tag === 7) {
          const result2 = [];
          for (let i = 0;i < n; i++)
            result2.push(read(depth + 1));
          return result2;
        }
        const result = {};
        for (let i = 0;i < n; i++)
          Object.defineProperty(result, text(raw()), { value: read(depth + 1), writable: true, enumerable: true, configurable: true });
        return result;
      }
      throw new Error("Unknown Pocket binary tag");
    }
    if (u8() !== 177)
      throw new Error("Invalid Pocket binary message magic");
    const value = read(0);
    if (offset !== bytes.length || value === null || typeof value !== "object" || Array.isArray(value) || value instanceof Uint8Array)
      throw new Error("Invalid Pocket binary message root or trailing bytes");
    return value;
  }
  module.exports = { encodeMessage, decodeMessage };
});

// targets/wechat/template/wechat-system.js
var require_wechat_system = __commonJS((exports, module) => {
  var { decodeMessage } = require_binary_bridge();

  class PocketWechatSystem {
    constructor(root, createHost) {
      this.root = root;
      root.instanceId = "system-ui";
      root.runtimeGeneration = 1;
      this.createHost = createHost;
      this.apps = root.config.system.apps;
      this.runtimes = new Map;
      this.pending = new Map;
      this.captures = new Map;
      this.sequence = 0;
      this.generation = 1;
      this.compositing = false;
      this.configured = false;
      this.disposed = false;
    }
    handles(capability) {
      return capability.startsWith("system.runtime.") || capability.startsWith("system.storage.") || capability.startsWith("platform.apps.") || capability.startsWith("platform.storage.") || capability.startsWith("platform.messages.") || isWechatBuiltinCapability(capability);
    }
    async request(source, request, signal) {
      const cap = request.capability;
      const p = request.params || {};
      if (this.disposed)
        throw this.root.error("cancelled", "System disposed");
      if (isWechatBuiltinCapability(cap)) {
        return wechatBuiltinCapability(source, cap, p);
      }
      if (cap.startsWith("system.")) {
        if (source !== this.root)
          throw this.root.error("system_context_denied", "System controls are restricted to SystemUI");
        if (cap === "system.runtime.configure") {
          if (p.systemUI !== this.root.config.appId)
            throw this.root.error("system_context_denied", "SystemUI does not match the project");
          this.configured = true;
          return { systemInstanceId: "system-ui", generation: 1 };
        }
        if (!this.configured)
          throw this.root.error("system_not_configured", "SystemUI must configure its runtime first");
        if (cap === "system.runtime.prepareOpen") {
          const runtime = this.instance(p.instanceId);
          if (!runtime || runtime === this.root)
            throw this.root.error("runtime_destroyed", "App runtime is not live");
          if (Number(p.generation) !== runtime.runtimeGeneration)
            throw this.root.error("runtime_destroyed", "App generation is no longer live");
          return {
            instanceId: runtime.instanceId,
            appId: runtime.config.appId,
            previousGeneration: runtime.runtimeGeneration,
            generation: runtime.runtimeGeneration,
            updated: false,
            configured: false
          };
        }
        if (cap === "system.runtime.create") {
          const app = this.apps.find((app2) => app2.appId === p.appId && app2.index !== 0);
          if (!app)
            throw this.root.error("app_not_found", "App is outside the installed project catalog");
          if (this.runtimes.has(app.appId))
            throw this.root.error("runtime_exists", "App runtime already exists");
          const runtime = this.createHost(app, this);
          runtime.instanceId = `wechat-${++this.sequence}`;
          runtime.runtimeGeneration = ++this.generation;
          this.runtimes.set(app.appId, runtime);
          try {
            await runtime.start(this.root.logicalWidth, this.root.logicalHeight, this.root.scale || 1);
            if (signal.aborted || this.disposed || runtime.disposed)
              throw this.root.error("cancelled", "App launch cancelled");
            runtime.started = true;
            runtime.stopScheduled();
            runtime.visible = false;
            return {
              instanceId: runtime.instanceId,
              appId: app.appId,
              generation: runtime.runtimeGeneration,
              ...p.prepareForOpen === true ? { preparedForOpen: true } : {}
            };
          } catch (error) {
            this.runtimes.delete(app.appId);
            runtime.dispose();
            throw error;
          }
        }
        if (cap === "system.runtime.awaitFirstFrame") {
          const runtime = this.instance(p.instanceId);
          if (!runtime || runtime === this.root || Number(p.generation) !== runtime.runtimeGeneration)
            throw this.root.error("runtime_destroyed", "App generation is no longer live");
          this.upload(runtime);
          return { ready: true, generation: runtime.runtimeGeneration };
        }
        if (cap === "system.runtime.destroy") {
          const runtime = this.instance(p.instanceId);
          if (!runtime || runtime === this.root)
            throw this.root.error("runtime_destroyed", "App runtime is not live");
          this.runtimes.delete(runtime.config.appId);
          this.root.exports.web_free_surface(this.root.host, runtime.config.surfaceHandle);
          this.rejectSource(runtime);
          for (const [id, capture] of this.captures)
            if (capture.runtime === runtime)
              this.captures.delete(id);
          runtime.dispose();
          return { destroyed: true };
        }
        if (cap === "system.runtime.post") {
          const runtime = this.instance(p.instanceId);
          if (!runtime || typeof p.event !== "string")
            throw this.root.error("runtime_destroyed", "App event target is not live");
          runtime.deliverGuestEvent(p.event, p.params || {});
          return { accepted: true };
        }
        if (cap === "system.runtime.respond") {
          const pending = this.pending.get(p.requestId);
          if (!pending)
            return { accepted: true, stale: true };
          this.pending.delete(p.requestId);
          pending.cleanup();
          if (p.ok === true)
            pending.resolve(p.value === undefined ? null : p.value);
          else
            pending.reject(this.root.error(p.error?.code || "system_request_failed", p.error?.message || "SystemUI rejected the request"));
          return { accepted: true };
        }
        if (cap.startsWith("system.storage.")) {
          const receiver = {
            wx: this.root.wx,
            config: { appId: p.namespace ? "__shared__" : p.appId },
            error: this.root.error,
            storageKey: this.root.storageKey
          };
          return this.root.storage.call(receiver, cap.replace("system.storage.", "platform.storage."), p);
        }
        throw this.root.error("unsupported", `Unsupported System transport: ${cap}`);
      }
      if (!this.configured)
        throw this.root.error("system_not_configured", "SystemUI is not ready");
      return new Promise((resolve, reject) => {
        const requestId = `wechat-system-${++this.sequence}`;
        const abort = () => {
          this.pending.delete(requestId);
          reject(this.root.error("cancelled", "System request cancelled"));
        };
        const cleanup = () => signal.removeEventListener("abort", abort);
        if (signal.aborted) {
          abort();
          return;
        }
        signal.addEventListener("abort", abort);
        this.pending.set(requestId, { source, resolve, reject, cleanup });
        try {
          this.root.deliverGuestEvent("system.request", {
            requestId,
            sourceAppId: source.config.appId,
            sourceInstanceId: source === this.root ? "system-ui" : source.instanceId,
            sourceGeneration: source === this.root ? 1 : source.runtimeGeneration,
            capability: cap,
            params: p
          });
        } catch (error) {
          this.pending.delete(requestId);
          cleanup();
          reject(error);
        }
      });
    }
    instance(id) {
      return id === "system-ui" ? this.root : [...this.runtimes.values()].find((runtime) => runtime.instanceId === id);
    }
    frames() {
      const root = this.root;
      root.check(root.exports.web_compositor_frames(root.host), "System compositor frames unavailable");
      const bytes = new Uint8Array(root.exports.memory.buffer, root.exports.web_result_ptr(root.host), root.exports.web_result_len(root.host));
      const packet = decodeMessage(bytes);
      if (!Array.isArray(packet.frames))
        throw root.error("render_failed", "Invalid binary compositor frame packet");
      return packet.frames;
    }
    upload(runtime) {
      if (runtime.disposed || !runtime.exports || runtime.surfaceUploaded && !runtime.surfaceDirty)
        return;
      const density = Math.max(1, Number(runtime.scale || this.root.scale || 1));
      const { logicalWidth: width, logicalHeight: height } = runtime;
      const physicalWidth = Math.max(1, Math.ceil(width * density));
      const physicalHeight = Math.max(1, Math.ceil(height * density));
      const pointer = runtime.exports.web_capture(runtime.host, density, 2);
      if (!pointer)
        throw this.root.error("render_failed", "Child raster capture failed");
      const bytes = new Uint8Array(runtime.exports.memory.buffer, pointer, physicalWidth * physicalHeight * 4);
      const root = this.root;
      const buffer = root.exports.web_alloc(bytes.length);
      if (!buffer)
        throw root.error("allocation_failed", "System surface allocation failed");
      try {
        new Uint8Array(root.exports.memory.buffer, buffer, bytes.length).set(bytes);
        const handle = root.exports.web_wechat_upload_surface(root.host, runtime.config.surfaceHandle, buffer, bytes.length, physicalWidth, physicalHeight, density);
        if (handle !== runtime.config.surfaceHandle)
          throw root.error("render_failed", "System surface upload failed");
        runtime.surfaceUploaded = true;
        runtime.surfaceDirty = false;
      } finally {
        root.exports.web_free(buffer, bytes.length);
      }
    }
    composite() {
      if (this.compositing || this.disposed || !this.root.exports)
        return 0;
      this.compositing = true;
      try {
        const frames = this.frames();
        for (const runtime of this.runtimes.values()) {
          const candidates = frames.filter((frame) => frame.handle === runtime.config.surfaceHandle);
          const slot = candidates.find((frame) => frame.focused) || candidates[0];
          runtime.mounted = !!slot;
          if (slot && slot.full[2] > 0 && slot.full[3] > 0) {
            runtime.resize(Math.ceil(slot.full[2]), Math.ceil(slot.full[3]));
            if (slot.focused && this.root.visible && !runtime.visible)
              runtime.show();
            else if (!slot.focused && runtime.visible)
              runtime.hide();
            this.upload(runtime);
          } else if (runtime.started && runtime.visible)
            runtime.hide();
        }
        return this.root.exports.web_capture(this.root.host, this.root.scale, 3);
      } finally {
        this.compositing = false;
      }
    }
    childFrame(runtime) {
      runtime.surfaceDirty = true;
      if (runtime.mounted && !this.compositing && !this.disposed && this.root.exports)
        this.root.draw();
    }
    input(contacts) {
      const rootContacts = [], childContacts = new Map;
      const live = new Set(contacts.filter((contact) => !contact.cancelled).map((contact) => contact.id));
      const frames = this.frames();
      for (const contact of contacts) {
        let target = this.captures.get(contact.id);
        if (!target) {
          const handle = this.root.exports.web_wechat_hit_surface(this.root.host, contact.x, contact.y);
          const slot = frames.find((frame) => frame.handle === handle && frame.focused);
          const runtime = slot && [...this.runtimes.values()].find((child) => child.config.surfaceHandle === handle);
          target = runtime ? { runtime, full: [...slot.full] } : { runtime: this.root };
          this.captures.set(contact.id, target);
        }
        if (target.runtime === this.root)
          rootContacts.push(contact);
        else {
          const list = childContacts.get(target.runtime) || [];
          list.push({ ...contact, x: contact.x - target.full[0], y: contact.y - target.full[1] });
          childContacts.set(target.runtime, list);
        }
      }
      for (const target of this.captures.values())
        if (target.runtime !== this.root && !childContacts.has(target.runtime))
          childContacts.set(target.runtime, []);
      for (const [id] of this.captures)
        if (!live.has(id))
          this.captures.delete(id);
      for (const [runtime, input] of childContacts)
        runtime.inputFrame(input);
      this.root.advance(rootContacts);
      this.root.schedule();
    }
    suspend() {
      for (const runtime of this.runtimes.values())
        if (runtime.visible)
          runtime.hide();
    }
    rejectSource(source) {
      for (const [id, pending] of this.pending)
        if (pending.source === source) {
          this.pending.delete(id);
          pending.cleanup();
          pending.reject(this.root.error("runtime_destroyed", "App runtime destroyed"));
        }
    }
    dispose() {
      this.disposed = true;
      for (const runtime of this.runtimes.values())
        runtime.dispose();
      this.runtimes.clear();
      for (const pending of this.pending.values()) {
        pending.cleanup();
        pending.reject(this.root.error("cancelled", "System disposed"));
      }
      this.pending.clear();
      this.captures.clear();
    }
  }
  var BUILTIN_CAPABILITIES = new Set(["runtime.info", "runtime.performance", "plugins.list", "plugins.packageInfo", "updates.status"]);
  function isWechatBuiltinCapability(capability) {
    return BUILTIN_CAPABILITIES.has(capability);
  }
  function wechatBuiltinCapability(source, capability, params = {}) {
    const value = source.config.metadata;
    const metadata = value && typeof value === "object" && !Array.isArray(value) ? value : {};
    const appId = String(source.config.appId);
    const provider = typeof source.config.provider === "string" && source.config.provider ? source.config.provider : "wechat";
    const host = typeof source.config.host === "string" && source.config.host ? source.config.host : provider;
    const hostRuntime = typeof source.config.hostRuntime === "string" && source.config.hostRuntime ? source.config.hostRuntime : "WXWebAssembly + Canvas2D";
    const qjbc = metadata.qjbc && typeof metadata.qjbc === "object" && !Array.isArray(metadata.qjbc) ? metadata.qjbc : {};
    const version = metadata.version === undefined ? qjbc.version : metadata.version;
    const build = metadata.build === undefined ? qjbc.build : metadata.build;
    if (capability === "runtime.info") {
      return {
        appId,
        provider,
        host,
        source: "embedded",
        entryFormat: qjbc.entryFormat || "quickjs-bytecode",
        runtimeAbi: qjbc.runtimeAbi || null,
        engineAbi: qjbc.engineAbi || null,
        version: version === undefined ? null : version,
        build: build === undefined ? null : build,
        entryBytes: qjbc.bytecodeBytes === undefined ? null : qjbc.bytecodeBytes,
        tickHz: source?.config?.tickHz || qjbc.tickHz || 60,
        hostRuntime,
        logicalWidth: Number(source?.logicalWidth || 0),
        logicalHeight: Number(source?.logicalHeight || 0),
        scale: Number(source?.scale || 1),
        assetRasterDensity: Number(source.config.rasterDensity || source.system?.root?.config?.rasterDensity || 1),
        nativeFlutterTiming: false,
        features: { recording: false, flutterFrameTiming: false, nativeHardware: false }
      };
    }
    if (capability === "runtime.performance") {
      return {
        supported: false,
        nativeFlutterTiming: false,
        provider,
        reason: `${hostRuntime} does not expose Flutter FrameTiming`,
        context: params && params.context === undefined ? null : (params || {}).context
      };
    }
    if (capability === "plugins.list") {
      return { protocolVersion: 1, appId, provider, plugins: [] };
    }
    if (capability === "plugins.packageInfo") {
      const packageInfo = metadata.package && typeof metadata.package === "object" && !Array.isArray(metadata.package) ? metadata.package : {};
      let miniProgram = {};
      try {
        const account = source?.wx?.getAccountInfoSync?.();
        if (account?.miniProgram && typeof account.miniProgram === "object") {
          const value2 = account.miniProgram;
          miniProgram = {
            ...value2.appId === undefined ? {} : { appId: String(value2.appId) },
            ...value2.envVersion === undefined ? {} : { envVersion: String(value2.envVersion) },
            ...value2.version === undefined ? {} : { version: String(value2.version) }
          };
        }
      } catch (_) {}
      return {
        provider,
        appId,
        appName: packageInfo.name || packageInfo.title || appId,
        packageName: appId,
        version: version === undefined ? null : version,
        buildNumber: build === undefined || build === null ? null : String(build),
        miniProgram
      };
    }
    if (capability === "updates.status") {
      const active = { version: version === undefined ? null : version, build: build === undefined ? null : build, source: "embedded", active: true };
      return {
        configured: false,
        stage: "disabled",
        activeVersion: active.version,
        activeBuild: active.build,
        availableVersion: null,
        preparedUpdate: null,
        versions: [active],
        lastError: null,
        provider
      };
    }
    throw source.error("unsupported", `Unsupported ${provider === "web" ? "Web" : "WeChat"} builtin capability: ${capability}`);
  }
  module.exports = { PocketWechatSystem, wechatBuiltinCapability, isWechatBuiltinCapability };
});

// targets/wechat/template/wechat-host.js
var require_wechat_host = __commonJS((exports, module) => {
  var { encodeMessage, decodeMessage } = require_binary_bridge();
  var { PocketWechatSystem, wechatBuiltinCapability, isWechatBuiltinCapability } = require_wechat_system();
  var MAX_OUTBOUND = 32;
  var MAX_REQUESTS = 32;
  var REQUEST_TIMEOUT_MS = 15000;
  var MAX_STORAGE_ITEM_BYTES = 1024 * 1024;
  var NATIVE_CANVAS_DIMENSION = 1365;
  var BROWSER_CANVAS_DIMENSION = 4096;
  var capabilityHandlers = Object.create(null);
  var permissionHandler = null;
  function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function utf8Length(value) {
    return unescape(encodeURIComponent(value)).length;
  }
  function encodeUtf8(value) {
    const binary = unescape(encodeURIComponent(value));
    const bytes = new Uint8Array(binary.length);
    for (let index = 0;index < binary.length; index += 1)
      bytes[index] = binary.charCodeAt(index);
    return bytes;
  }
  function decodeUtf8(bytes) {
    let binary = "";
    for (let offset = 0;offset < bytes.length; offset += 8192) {
      binary += String.fromCharCode.apply(null, bytes.subarray(offset, Math.min(bytes.length, offset + 8192)));
    }
    return decodeURIComponent(escape(binary));
  }
  function createAbortController() {
    if (typeof globalThis.AbortController === "function")
      return new globalThis.AbortController;
    let aborted = false;
    const listeners = [];
    return {
      signal: {
        get aborted() {
          return aborted;
        },
        addEventListener(name, listener) {
          if (name === "abort" && typeof listener === "function")
            listeners.push(listener);
        },
        removeEventListener(name, listener) {
          if (name !== "abort")
            return;
          const index = listeners.indexOf(listener);
          if (index >= 0)
            listeners.splice(index, 1);
        }
      },
      abort() {
        if (aborted)
          return;
        aborted = true;
        for (const listener of listeners.slice()) {
          try {
            listener({ type: "abort" });
          } catch (_) {}
        }
        listeners.length = 0;
      }
    };
  }

  class PocketWechatHost {
    constructor(options) {
      this.headless = !!options.headless;
      this.system = options.system || null;
      this.wx = options.wx;
      this.config = options.config;
      this.canvas = options.canvas;
      this.context = options.context;
      this.onInput = options.onInput;
      this.onError = options.onError;
      this.onWorkerChannel = options.onWorkerChannel;
      this.isActive = options.isActive;
      this.sampleInput = options.sampleInput;
      this.capabilityHandlers = options.capabilityHandlers || Object.create(null);
      this.instance = null;
      this.exports = null;
      this.host = 0;
      this.scale = 1;
      this.devicePixelRatio = 1;
      this.logicalWidth = 1;
      this.logicalHeight = 1;
      this.width = 1;
      this.height = 1;
      this.scheduledIdle = null;
      this.imageData = null;
      this.outbound = [];
      this.contacts = [];
      this.pending = new Map;
      this.raf = 0;
      this.rafUsesCanvas = false;
      this.timer = 0;
      this.running = false;
      this.visible = false;
      this.disposed = false;
      this.draining = false;
      this.input = null;
      this.inputRevision = 0;
      this.generation = 1;
      this.lastClockUs = 0;
      if (!this.system && this.config.system) {
        this.system = new PocketWechatSystem(this, (app, system) => new PocketWechatHost({
          wx: this.wx,
          canvas: {},
          context: null,
          headless: true,
          system,
          config: { ...app, enginePath: this.config.enginePath },
          isActive: () => this.visible && !this.disposed,
          onInput: this.onInput,
          onError: this.onError,
          capabilityHandlers: this.capabilityHandlers
        }));
      }
    }
    canvasDimensionLimit() {
      return this.wx && this.wx.__pocketBrowserPreview === true ? BROWSER_CANVAS_DIMENSION : NATIVE_CANVAS_DIMENSION;
    }
    currentDevicePixelRatio(fallback = 1) {
      const provider = this.wx && this.wx.__pocketBrowserDevicePixelRatio;
      let value;
      try {
        value = typeof provider === "function" ? provider() : provider;
      } catch (_) {
        value = undefined;
      }
      if (!(Number.isFinite(Number(value)) && Number(value) > 0))
        value = fallback;
      return Math.min(4, Math.max(0.25, Number(value)));
    }
    pixelScale(width, height, devicePixelRatio) {
      const dimensionLimit = this.canvasDimensionLimit();
      const requested = this.currentDevicePixelRatio(devicePixelRatio || 1);
      return Math.min(4, Math.max(1, Math.ceil(requested)), Math.floor(dimensionLimit / Math.max(1, Math.floor(width))), Math.floor(dimensionLimit / Math.max(1, Math.floor(height))));
    }
    clockNowUs() {
      this.lastClockUs = Math.max(Date.now() * 1000, this.lastClockUs + 1);
      return this.lastClockUs;
    }
    hostLabel() {
      return this.config.provider === "web" ? "Web" : "WeChat";
    }
    async start(width, height, devicePixelRatio) {
      this.logicalWidth = Math.max(1, Math.floor(width));
      this.logicalHeight = Math.max(1, Math.floor(height));
      this.width = this.logicalWidth;
      this.height = this.logicalHeight;
      const dimensionLimit = this.canvasDimensionLimit();
      this.devicePixelRatio = this.currentDevicePixelRatio(devicePixelRatio || 1);
      const scale = this.pixelScale(this.logicalWidth, this.logicalHeight, this.devicePixelRatio);
      if (scale < 1)
        throw new Error(`PocketJS Canvas2D viewport exceeds the ${dimensionLimit}px surface limit.`);
      this.scale = scale;
      this.configureCanvas();
      const imports = {
        env: { __rquickjs_host_now_us: () => this.clockNowUs() },
        pocket_web_worker: {
          now_micros: () => this.clockNowUs(),
          operation: () => -6
        },
        pocket_wechat: {
          host_emit: (pointer, length) => this.enqueueFromWasm(pointer, length)
        }
      };
      const loaded = await this.wx.WXWebAssembly.instantiate(this.config.enginePath, imports);
      if (this.disposed)
        return;
      this.instance = loaded.instance || loaded;
      this.exports = this.instance.exports;
      this.host = this.exports.web_create(this.logicalWidth, this.logicalHeight, this.scale, 0, 0);
      if (!this.host)
        throw new Error("PocketJS WASM could not allocate its runtime host.");
      const external = this.config.externalGuest;
      if (external) {
        if (!(external.qjbc instanceof Uint8Array) || !(external.pak instanceof Uint8Array) || typeof this.exports.web_boot !== "function" || typeof this.exports.web_set_identity !== "function") {
          throw new Error("PocketJS external Guest requires QJBC, PAK and the generic Web boot ABI.");
        }
        const identity = encodeUtf8(String(this.config.appId || "pocket.web.guest"));
        this.withBytes(identity, (identityPointer, identityLength) => this.check(this.exports.web_set_identity(this.host, identityPointer, identityLength, Number(external.hostAbi || 1)), "PocketJS Web Guest identity was rejected."));
        const workerDeclaration = this.config.worker?.descriptor?.declaration || this.config.worker?.declaration;
        if (workerDeclaration?.channels?.length && typeof this.exports.web_worker_channels_configure === "function") {
          const channels = encodeUtf8(JSON.stringify(workerDeclaration.channels));
          this.withBytes(channels, (pointer, length) => this.check(this.exports.web_worker_channels_configure(this.host, pointer, length), "PocketJS Worker channel declaration was rejected."));
        }
        this.withBytes(external.qjbc, (qjbcPointer, qjbcLength) => this.withBytes(external.pak, (pakPointer, pakLength) => this.check(this.exports.web_boot(this.host, qjbcPointer, qjbcLength, pakPointer, pakLength, Number(external.tickHz || this.config.tickHz || 60), this.scale), "PocketJS external QuickJS guest did not boot.")));
      } else {
        this.check(this.exports.web_wechat_boot_index ? this.exports.web_wechat_boot_index(this.host, this.scale, this.config.index || 0) : this.exports.web_wechat_boot(this.host, this.scale), "PocketJS QuickJS guest did not boot.");
      }
      this.visible = !!this.isActive();
      this.reportViewport();
      this.draw();
      if (this.visible)
        this.drainOutbound();
      this.schedule();
    }
    reportViewport() {
      if (!this.exports || this.disposed || !this.visible)
        return;
      const info = this.wx.getWindowInfo ? this.wx.getWindowInfo() : this.wx.getSystemInfoSync?.() || {};
      const safe = info.safeArea || {};
      const top = Math.max(0, Number(safe.top) || Number(info.statusBarHeight) || 0);
      const right = Math.max(0, (Number(info.screenWidth) || this.logicalWidth) - (Number(safe.right) || this.logicalWidth));
      const bottom = Math.max(0, (Number(info.screenHeight) || this.logicalHeight) - (Number(safe.bottom) || this.logicalHeight));
      const regions = [];
      if (this.wx.getMenuButtonBoundingClientRect) {
        const capsule = this.wx.getMenuButtonBoundingClientRect();
        if (capsule?.width > 0 && capsule?.height > 0)
          regions.push({
            id: "wechat-capsule",
            kind: "occlusion",
            active: true,
            frame: { left: capsule.left, top: capsule.top, width: capsule.width, height: capsule.height },
            margins: { top: 0, left: 8, right: 0, bottom: 8 }
          });
      }
      if (this.headless)
        regions.push({
          id: "mini-app-close",
          kind: "occlusion",
          active: true,
          frame: { left: this.logicalWidth - right - 52, top: top + 8, width: 44, height: 44 },
          margins: { top: 0, left: 8, right: 0, bottom: 8 }
        });
      this.deliverGuestEvent("display.viewport", {
        width: this.logicalWidth,
        height: this.logicalHeight,
        safeArea: { top, right, bottom, left: Math.max(0, Number(safe.left) || 0) },
        keyboardInset: 0,
        reservedRegions: regions
      }, false);
    }
    configureCanvas() {
      if (this.headless)
        return;
      const width = this.logicalWidth * this.scale;
      const height = this.logicalHeight * this.scale;
      const dimensionLimit = this.canvasDimensionLimit();
      if (width > dimensionLimit || height > dimensionLimit)
        throw new Error(`PocketJS Canvas2D output exceeds the ${dimensionLimit}px surface limit.`);
      this.canvas.width = width;
      this.canvas.height = height;
      this.imageData = this.context.createImageData(width, height);
    }
    resize(width, height) {
      if (!this.exports || this.disposed)
        return;
      this.devicePixelRatio = this.currentDevicePixelRatio(this.devicePixelRatio || this.scale || 1);
      const maxLogical = Math.max(1, Math.floor(this.canvasDimensionLimit() / (this.scale || 1)));
      const nextWidth = Math.min(maxLogical, Math.max(1, Math.floor(Number(width) || this.width || this.logicalWidth || 1)));
      const nextHeight = Math.min(maxLogical, Math.max(1, Math.floor(Number(height) || this.height || this.logicalHeight || 1)));
      const changed = nextWidth !== this.logicalWidth || nextHeight !== this.logicalHeight;
      if (!changed)
        return;
      this.logicalWidth = nextWidth;
      this.width = nextWidth;
      this.logicalHeight = nextHeight;
      this.height = nextHeight;
      this.configureCanvas();
      this.stopScheduled();
      const resizeFn = this.exports.web_resize_viewport || this.exports.web_resize;
      this.check(resizeFn.call(this.exports, this.host, nextWidth, nextHeight), "PocketJS viewport resize failed.");
      this.reportViewport();
      this.draw();
      this.drainOutbound();
      this.schedule();
    }
    allocBytes(text) {
      const bytes = text instanceof Uint8Array ? text : encodeUtf8(text);
      const pointer = this.exports.web_alloc(bytes.length);
      if (!pointer)
        throw new Error("PocketJS WASM could not allocate an input buffer.");
      new Uint8Array(this.exports.memory.buffer, pointer, bytes.length).set(bytes);
      return { pointer, length: bytes.length };
    }
    withBytes(text, callback) {
      const buffer = this.allocBytes(text);
      try {
        return callback(buffer.pointer, buffer.length);
      } finally {
        this.exports.web_free(buffer.pointer, buffer.length);
      }
    }
    check(code, fallback) {
      if (code === 0)
        return;
      let detail = "";
      try {
        const pointer = this.exports.web_result_ptr(this.host);
        const length = this.exports.web_result_len(this.host);
        if (pointer && length)
          detail = decodeUtf8(new Uint8Array(this.exports.memory.buffer, pointer, length));
      } catch (_) {}
      throw new Error(detail ? `${fallback} ${detail}` : fallback);
    }
    enqueueFromWasm(pointer, length) {
      if (!this.exports || length <= 0 || length > 64 * 1024 || this.outbound.length >= MAX_OUTBOUND)
        return 0;
      try {
        this.outbound.push(decodeMessage(new Uint8Array(this.exports.memory.buffer, pointer, length)));
      } catch (_) {
        return 0;
      }
      return 1;
    }
    inputFrame(contacts) {
      if (!this.exports || this.disposed || !this.visible)
        return;
      this.stopScheduled();
      if (this.system && this.system.root === this)
        this.system.input(contacts);
      else {
        this.advance(contacts);
        this.schedule();
      }
    }
    pushWorkerChannel(channel, data) {
      if (!this.exports || this.disposed || typeof this.exports.web_worker_channels_push !== "function")
        return false;
      const bytes = data instanceof Uint8Array ? data : new Uint8Array(data || []);
      const status = this.withBytes(bytes, (pointer, length) => this.exports.web_worker_channels_push(this.host, channel, pointer, length));
      if (status !== 0)
        return false;
      if (this.visible)
        this.wake();
      return true;
    }
    drainWorkerChannels() {
      if (!this.exports || this.disposed || typeof this.exports.web_worker_channels_take !== "function" || typeof this.onWorkerChannel !== "function")
        return;
      for (let pass = 0;pass < 8; pass += 1) {
        if (this.exports.web_worker_channels_take(this.host) !== 0)
          return;
        const pointer = this.exports.web_result_ptr(this.host);
        const length = this.exports.web_result_len(this.host);
        if (!pointer || !length)
          return;
        let packet;
        try {
          packet = decodeMessage(new Uint8Array(this.exports.memory.buffer, pointer, length));
        } catch (_) {
          return;
        }
        const records = Array.isArray(packet?.records) ? packet.records : [];
        if (!records.length)
          return;
        for (const record of records) {
          const channel = Number(record?.channel || 0);
          const data = record?.data instanceof Uint8Array ? record.data : Array.isArray(record?.data) && record.data.every((value) => Number.isInteger(value) && value >= 0 && value <= 255) ? Uint8Array.from(record.data) : null;
          if (channel > 0 && data)
            this.onWorkerChannel(channel, data);
        }
        if (records.length < 8)
          return;
      }
    }
    advance(contacts = this.contacts) {
      this.contacts = contacts.filter((contact) => !contact.cancelled);
      const input = this.sampleInput?.() || {};
      const facts = encodeMessage({
        buttons: (input.buttons || 0) >>> 0,
        analog: input.analog ?? 32896,
        rightAnalog: input.rightAnalog ?? 32896,
        contacts,
        axisDeltas: []
      });
      this.withBytes(facts, (pointer, length) => this.check(this.exports.web_advance(this.host, pointer, length, 1), "PocketJS guest frame failed."));
      this.check(this.exports.web_present(this.host), "PocketJS renderer failed to present DrawOps.");
      this.draw();
      this.drainOutbound();
      this.drainWorkerChannels();
    }
    draw() {
      if (this.headless) {
        this.system?.childFrame(this);
        return;
      }
      if (!this.exports || !this.imageData || !this.context)
        return;
      const pointer = this.system ? this.system.composite() : this.exports.web_pixels(this.host);
      const length = this.system ? this.logicalWidth * this.logicalHeight * this.scale * this.scale * 4 : this.exports.web_pixels_len(this.host);
      if (!pointer || length !== this.imageData.data.length)
        return;
      this.imageData.data.set(new Uint8ClampedArray(this.exports.memory.buffer, pointer, length));
      this.context.putImageData(this.imageData, 0, 0);
    }
    workState() {
      this.check(this.exports.web_wechat_work_state(this.host), "PocketJS scheduler state is unavailable.");
      const pointer = this.exports.web_result_ptr(this.host);
      const length = this.exports.web_result_len(this.host);
      return decodeMessage(new Uint8Array(this.exports.memory.buffer, pointer, length));
    }
    schedule() {
      if (!this.exports || !this.visible || this.disposed || this.running)
        return;
      let state;
      try {
        state = this.workState();
      } catch (error) {
        this.onError(error);
        return;
      }
      if (state.continuous) {
        this.running = true;
        this.rafUsesCanvas = !!this.canvas.requestAnimationFrame;
        const scheduleFrame = this.rafUsesCanvas ? (callback) => this.canvas.requestAnimationFrame(callback) : (callback) => setTimeout(callback, 16);
        this.raf = scheduleFrame(() => {
          this.running = false;
          this.raf = 0;
          if (!this.visible || this.disposed)
            return;
          this.advance();
          this.schedule();
        });
        return;
      }
      const frames = Number(state.framesUntilTimer || 0);
      if (frames <= 0)
        return;
      this.running = true;
      this.scheduledIdle = frames > 1 ? { frames, scheduledAt: Date.now(), hz: Math.max(1, Number(state.simulationHz) || 60) } : null;
      const delay = Math.max(1, Math.ceil(frames * 1000 / Math.max(1, Number(state.simulationHz) || 60)));
      this.timer = setTimeout(() => {
        this.running = false;
        this.timer = 0;
        this.scheduledIdle = null;
        if (!this.visible || this.disposed)
          return;
        if (frames > 1 && !this.disposed && this.exports && this.host) {
          this.exports.web_wechat_skip_idle_frames(this.host, frames - 1);
        }
        this.advance();
        this.schedule();
      }, delay);
    }
    wake(deferred = false) {
      if (!this.exports || this.disposed || !this.visible)
        return;
      if (deferred) {
        if (this.running && !this.scheduledIdle)
          return;
        this.stopScheduled();
        this.running = true;
        this.timer = setTimeout(() => {
          this.running = false;
          this.timer = 0;
          if (!this.visible || this.disposed)
            return;
          this.advance();
          this.schedule();
        }, 16);
        return;
      }
      this.stopScheduled();
      this.advance();
      this.schedule();
    }
    stopScheduled() {
      if (this.scheduledIdle) {
        const info = this.scheduledIdle;
        this.scheduledIdle = null;
        if (!this.disposed && this.exports && this.host) {
          const elapsedMs = Math.max(0, Date.now() - info.scheduledAt);
          const elapsedFrames = Math.min(Math.max(0, info.frames - 1), Math.floor(elapsedMs * info.hz / 1000));
          if (elapsedFrames > 0) {
            this.exports.web_wechat_skip_idle_frames(this.host, elapsedFrames);
          }
        }
      }
      if (this.raf) {
        if (this.rafUsesCanvas && this.canvas && this.canvas.cancelAnimationFrame)
          this.canvas.cancelAnimationFrame(this.raf);
        else
          clearTimeout(this.raf);
      }
      if (this.timer)
        clearTimeout(this.timer);
      this.raf = 0;
      this.rafUsesCanvas = false;
      this.timer = 0;
      this.running = false;
    }
    show() {
      if (this.disposed || !this.exports)
        return;
      this.visible = true;
      this.reportViewport();
      this.wake();
    }
    hide() {
      if (this.disposed)
        return;
      const hadInput = Boolean(this.input);
      this.contacts = [];
      this.visible = false;
      if (this.system?.root === this)
        this.system.suspend();
      this.stopScheduled();
      this.cancelPending("page inactive");
      this.imeDismiss({});
      if (hadInput && this.wx.hideKeyboard)
        this.wx.hideKeyboard({ complete: () => {} });
    }
    declared(capability) {
      const requires = this.config.requires || [];
      const optional = this.config.optional || [];
      if (capability.startsWith("platform.storage.")) {
        return requires.includes(capability) || optional.includes(capability) || requires.includes("platform.storage") || optional.includes("platform.storage");
      }
      return requires.includes(capability) || optional.includes(capability);
    }
    drainOutbound() {
      if (this.draining || this.disposed)
        return;
      this.draining = true;
      try {
        let passes = 0;
        while (this.outbound.length && passes++ < MAX_OUTBOUND * 2) {
          const event = this.outbound.shift();
          if (!event)
            continue;
          const name = event.name || event.method;
          const payload = event.payload || event.params || {};
          if (name === "host.request")
            this.handleRequest(payload);
          else if (name === "textInput.open")
            this.openInput(payload);
          else if (name === "textInput.update")
            this.updateInput(payload);
          else if (name === "textInput.close")
            this.closeInput(true);
        }
      } finally {
        this.draining = false;
      }
    }
    async handleRequest(request) {
      if (!isRecord(request) || typeof request.requestId !== "string" || typeof request.capability !== "string")
        return;
      if (this.disposed || !this.exports || !this.host)
        return;
      if (!this.visible) {
        this.respond(request, false, null, { code: "cancelled", message: "page inactive" });
        return;
      }
      if (this.pending.size >= MAX_REQUESTS) {
        this.respond(request, false, null, { code: "request_quota", message: `${this.hostLabel()} host request limit reached` });
        return;
      }
      if (!this.declared(request.capability)) {
        this.respond(request, false, null, { code: "permission_denied", message: `Capability is not declared: ${request.capability}` });
        return;
      }
      const systemTransport = this.system && this.system.handles(request.capability);
      const generation = this.generation;
      const record = { request, generation, timer: 0, cancelled: false, controller: createAbortController() };
      this.pending.set(request.requestId, record);
      record.timer = setTimeout(() => {
        if (!this.pending.delete(request.requestId))
          return;
        record.cancelled = true;
        record.controller.abort();
        this.respond(request, false, null, { code: "timeout", message: `${this.hostLabel()} host request timed out` });
      }, REQUEST_TIMEOUT_MS);
      try {
        const authorize = permissionHandler;
        if (systemTransport || isWechatBuiltinCapability(request.capability) || Object.hasOwn(this.capabilityHandlers, request.capability)) {} else if (typeof authorize === "function") {
          const allowed = await authorize(request.capability, request.params || {}, {
            wx: this.wx,
            signal: record.controller.signal
          });
          if (!allowed)
            throw this.error("permission_denied", "Permission request was cancelled");
        } else if (!request.capability.startsWith("platform.storage.")) {
          throw this.error("unconfigured", `No ${this.hostLabel()} handler is configured for ${request.capability}`);
        }
        if (record.cancelled || generation !== this.generation)
          return;
        const result = systemTransport ? await this.system.request(this, request, record.controller.signal) : await this.dispatchCapability(request.capability, request.params || {}, record.controller.signal);
        if (!this.pending.has(request.requestId) || generation !== this.generation || record.cancelled)
          return;
        this.respond(request, true, result, null);
        this.pending.delete(request.requestId);
        clearTimeout(record.timer);
      } catch (error) {
        if (!this.pending.delete(request.requestId) || generation !== this.generation || record.cancelled)
          return;
        clearTimeout(record.timer);
        const shape = error && error.code ? { code: String(error.code), message: String(error.message || error.code) } : { code: "host_error", message: String(error && error.message || error) };
        this.respond(request, false, null, shape);
      }
    }
    error(code, message) {
      const error = new Error(message);
      error.code = code;
      return error;
    }
    async dispatchCapability(capability, params, signal) {
      if (Object.hasOwn(this.capabilityHandlers, capability)) {
        return this.capabilityHandlers[capability](params, { signal, wx: this.wx });
      }
      if (isWechatBuiltinCapability(capability))
        return wechatBuiltinCapability(this, capability, params);
      if (capability.startsWith("platform.storage."))
        return this.storage(capability, params);
      const handler = capabilityHandlers[capability];
      if (typeof handler !== "function")
        throw this.error("unconfigured", `No ${this.hostLabel()} handler is configured for ${capability}`);
      return handler(params, { signal, wx: this.wx });
    }
    storageKey(namespace, key) {
      if (typeof key !== "string" || key.length < 1 || key.length > 512)
        throw this.error("invalid_argument", "Storage key must be 1 to 512 characters");
      if (namespace !== undefined && (typeof namespace !== "string" || namespace.length > 128))
        throw this.error("invalid_argument", "Storage namespace must be at most 128 characters");
      return `pocketjs:v1:${this.config.appId}:${namespace || "app"}:${key}`;
    }
    storage(capability, params) {
      const operation = capability.slice("platform.storage.".length);
      if (operation === "get") {
        const key = this.storageKey(params.namespace, params.key);
        return new Promise((resolve, reject) => this.wx.getStorage({
          key,
          success: (result) => {
            try {
              resolve(JSON.parse(result.data));
            } catch (_) {
              reject(this.error("storage_corrupt", "Stored PocketJS value is invalid JSON"));
            }
          },
          fail: (error) => {
            const message = String(error && error.errMsg || "");
            if (message.includes("not found") || message.includes("data not found"))
              resolve(null);
            else
              reject(this.error("storage_failed", message || `${this.hostLabel()} storage read failed`));
          }
        }));
      }
      if (operation === "set") {
        const key = this.storageKey(params.namespace, params.key);
        let value;
        try {
          value = JSON.stringify(params.value);
        } catch (_) {
          throw this.error("invalid_argument", "Storage value must be JSON serializable");
        }
        if (value === undefined || utf8Length(value) > MAX_STORAGE_ITEM_BYTES)
          throw this.error("quota_exceeded", `${this.hostLabel()} storage values are limited to 1 MiB per key`);
        return new Promise((resolve, reject) => this.wx.setStorage({
          key,
          data: value,
          success: () => resolve(null),
          fail: (error) => reject(this.error("storage_failed", String(error && error.errMsg || `${this.hostLabel()} storage write failed`)))
        }));
      }
      if (operation === "remove") {
        const key = this.storageKey(params.namespace, params.key);
        return new Promise((resolve, reject) => this.wx.removeStorage({
          key,
          success: () => resolve(null),
          fail: (error) => reject(this.error("storage_failed", String(error && error.errMsg || `${this.hostLabel()} storage removal failed`)))
        }));
      }
      if (operation === "keys") {
        const prefix = `pocketjs:v1:${this.config.appId}:${params.namespace || "app"}:`;
        return new Promise((resolve, reject) => this.wx.getStorageInfo({
          success: (info) => resolve((info.keys || []).filter((key) => key.startsWith(prefix)).map((key) => key.slice(prefix.length)).sort()),
          fail: (error) => reject(this.error("storage_failed", String(error && error.errMsg || `${this.hostLabel()} storage listing failed`)))
        }));
      }
      throw this.error("unsupported", `Unsupported ${this.hostLabel()} storage operation: ${operation}`);
    }
    respond(request, ok, result, error) {
      const packet = encodeMessage({
        type: "event",
        name: "host.response",
        payload: {
          requestId: request.requestId,
          capability: request.capability,
          ok,
          ...ok ? { result: result === undefined ? null : result } : { error }
        }
      }, request.capability.startsWith("media.live2d.model.") ? 4 * 1024 * 1024 : 64 * 1024);
      this.deliverResponse(packet);
    }
    deliverResponse(packet) {
      if (!this.exports || this.disposed)
        return;
      this.withBytes(packet, (pointer, length) => this.check(this.exports.web_wechat_deliver(this.host, pointer, length), "PocketJS rejected a host response."));
      this.drainOutbound();
      this.wake(true);
    }
    deliverGuestEvent(method, params, wake = true) {
      if (!this.exports || this.disposed)
        return;
      const methodBytes = this.allocBytes(method);
      const paramsBytes = this.allocBytes(encodeMessage(params || {}));
      try {
        this.check(this.exports.web_wechat_guest_event(this.host, methodBytes.pointer, methodBytes.length, paramsBytes.pointer, paramsBytes.length), "PocketJS rejected a native input event.");
      } finally {
        this.exports.web_free(methodBytes.pointer, methodBytes.length);
        this.exports.web_free(paramsBytes.pointer, paramsBytes.length);
      }
      this.drainOutbound();
      if (wake)
        this.wake();
    }
    inputStyle(value) {
      const rect = isRecord(value.rect) ? value.rect : { x: 8, y: 8, width: 240, height: 38 };
      const x = Math.max(0, Number(rect.x) || 0);
      const y = Math.max(0, Number(rect.y) || 0);
      const width = Math.max(40, Number(rect.width) || 240);
      const height = Math.max(28, Number(rect.height) || 38);
      const fontSize = [12, 14, 16].includes(value.fontSize) ? value.fontSize : 14;
      const radius = Math.max(0, Math.min(24, Number(value.borderRadius) || 8));
      const paddingH = Math.max(0, Number(value.paddingHorizontal) || 12);
      const paddingV = Math.max(0, Number(value.paddingVertical) || 8);
      return [
        `left:${x}px`,
        `top:${y}px`,
        `width:${width}px`,
        `height:${height}px`,
        `font-size:${fontSize}px`,
        `line-height:${Math.max(20, height - paddingV * 2)}px`,
        `color:${value.textColor || "#283444"}`,
        `background:${value.fillColor || "#ffffff"}`,
        `border:1px solid ${value.focusedBorderColor || value.borderColor || "#2676cb"}`,
        `border-radius:${radius}px`,
        `padding:0 ${paddingH}px`
      ].join(";");
    }
    openInput(value) {
      if (this.disposed || !this.visible)
        return;
      if (this.system) {
        const previous = this.system.imeOwner;
        if (previous && previous !== this)
          previous.closeInput(true);
        this.system.imeOwner = this;
      }
      const text = String(value.text ?? "");
      const requestedCursor = Number.isInteger(value.selectionExtent) ? value.selectionExtent : text.length;
      this.input = {
        id: value.id,
        editingSession: value.editingSession,
        revision: Number(value.revision) || 0,
        jsRevision: Number(value.jsRevision) || 0,
        text,
        cursor: Math.max(0, Math.min(text.length, requestedCursor)),
        placeholder: String(value.placeholder || ""),
        confirmType: value.action === "search" ? "search" : value.action === "next" ? "next" : "done",
        cursorSpacing: Math.max(0, Number(value.paddingVertical) || 8),
        style: this.inputStyle(value)
      };
      this.inputRevision = this.input.revision;
      this.onInput({ ...this.input, visible: true, focus: true });
    }
    updateInput(value) {
      if (this.disposed || !this.visible)
        return;
      if (!this.input || value.id !== undefined && String(value.id) !== String(this.input.id))
        return;
      if (value.editingSession && value.editingSession !== this.input.editingSession)
        return;
      const nextText = value.text !== undefined ? String(value.text) : this.input.text;
      const textChanged = nextText !== this.input.text;
      const requestedCursor = Number.isInteger(value.selectionExtent) ? value.selectionExtent : textChanged ? nextText.length : this.input.cursor;
      const nextCursor = Math.max(0, Math.min(nextText.length, requestedCursor));
      const cursorChanged = nextCursor !== this.input.cursor;
      this.input = {
        ...this.input,
        ...textChanged || cursorChanged ? { text: nextText, cursor: nextCursor } : {},
        ...value.revision !== undefined ? { revision: Number(value.revision) || this.input.revision } : {},
        ...value.jsRevision !== undefined ? { jsRevision: Number(value.jsRevision) || this.input.jsRevision } : {},
        ...value.rect ? { style: this.inputStyle({ ...this.input, ...value }) } : {}
      };
      this.inputRevision = this.input.revision;
      if (textChanged || cursorChanged || value.rect)
        this.onInput({ ...this.input, visible: true, focus: true });
    }
    closeInput(hideKeyboard) {
      if (!this.input)
        return;
      this.input = null;
      if (this.system?.imeOwner === this)
        this.system.imeOwner = null;
      this.onInput({ visible: false });
      if (hideKeyboard && this.wx.hideKeyboard)
        this.wx.hideKeyboard({ complete: () => {} });
    }
    imeEdit(detail) {
      if (this.system?.root === this && this.system.imeOwner && this.system.imeOwner !== this)
        return this.system.imeOwner.imeEdit(detail);
      if (!this.input)
        return;
      this.inputRevision += 1;
      const text = String(detail.value ?? "");
      const requestedCursor = Number.isInteger(detail.cursor) ? detail.cursor : text.length;
      const cursor = Math.max(0, Math.min(text.length, requestedCursor));
      this.input.text = text;
      this.input.cursor = cursor;
      this.deliverGuestEvent("textInput.edit", {
        id: this.input.id,
        editingSession: this.input.editingSession,
        revision: this.inputRevision,
        jsRevision: this.input.jsRevision,
        text,
        selectionBase: cursor,
        selectionExtent: cursor,
        composingBase: -1,
        composingExtent: -1
      });
    }
    imeSubmit(detail) {
      if (this.system?.root === this && this.system.imeOwner && this.system.imeOwner !== this)
        return this.system.imeOwner.imeSubmit(detail);
      if (!this.input)
        return;
      const text = String(detail.value ?? this.input.text ?? "");
      this.deliverGuestEvent("textInput.submit", {
        id: this.input.id,
        editingSession: this.input.editingSession,
        revision: this.inputRevision,
        jsRevision: this.input.jsRevision,
        text,
        selectionBase: text.length,
        selectionExtent: text.length,
        composingBase: -1,
        composingExtent: -1,
        action: this.input.confirmType
      });
    }
    imeDismiss(detail) {
      if (this.system?.root === this && this.system.imeOwner && this.system.imeOwner !== this)
        return this.system.imeOwner.imeDismiss(detail);
      if (!this.input)
        return;
      const input = this.input;
      this.input = null;
      if (this.system?.imeOwner === this)
        this.system.imeOwner = null;
      this.onInput({ visible: false });
      this.deliverGuestEvent("textInput.dismiss", {
        id: input.id,
        editingSession: input.editingSession,
        revision: this.inputRevision,
        jsRevision: input.jsRevision,
        reason: "blur",
        text: String(detail.value ?? input.text ?? "")
      });
    }
    cancelPending(reason) {
      this.generation += 1;
      const entries = Array.from(this.pending.values());
      this.pending.clear();
      for (const entry of entries) {
        if (entry.timer)
          clearTimeout(entry.timer);
        entry.cancelled = true;
        try {
          entry.controller.abort();
        } catch (_) {}
        if (!this.disposed && this.exports && this.host) {
          try {
            this.respond(entry.request, false, null, { code: "cancelled", message: reason || "cancelled" });
          } catch (_) {}
        }
      }
    }
    dispose() {
      if (this.disposed)
        return;
      this.disposed = true;
      this.visible = false;
      try {
        this.stopScheduled();
        this.cancelPending("host disposed");
        if (this.system?.root === this)
          this.system.dispose();
        this.closeInput(true);
      } finally {
        const exports2 = this.exports;
        const host = this.host;
        this.host = 0;
        this.outbound.length = 0;
        this.instance = null;
        this.exports = null;
        if (exports2 && host)
          exports2.web_destroy(host);
      }
    }
  }
  function registerCapability(name, handler) {
    if (typeof name !== "string" || !name || typeof handler !== "function")
      throw new TypeError("Capability registration requires a name and handler");
    capabilityHandlers[name] = handler;
    return () => {
      if (capabilityHandlers[name] === handler)
        delete capabilityHandlers[name];
    };
  }
  function setPermissionHandler(handler) {
    if (handler !== null && typeof handler !== "function")
      throw new TypeError("Permission handler must be a function or null");
    permissionHandler = handler;
  }
  function registeredCapabilityNames() {
    return Object.keys(capabilityHandlers);
  }
  function invokeRegisteredCapability(name, params, context) {
    const handler = capabilityHandlers[name];
    if (typeof handler !== "function")
      throw Object.assign(new Error(`No Web handler is configured for ${name}`), { code: "unconfigured" });
    return handler(params, context);
  }
  function requestCapabilityPermission(name, params, context) {
    if (typeof permissionHandler === "function")
      return permissionHandler(name, params, context);
    if (name.startsWith("platform.storage."))
      return true;
    throw Object.assign(new Error(`No Web permission handler is configured for ${name}`), { code: "unconfigured" });
  }
  module.exports = {
    PocketWechatHost,
    registerCapability,
    setPermissionHandler,
    registeredCapabilityNames,
    invokeRegisteredCapability,
    requestCapabilityPermission
  };
});

// targets/web/game_input.js
var require_game_input = __commonJS((exports, module) => {
  var BTN = Object.freeze({
    SELECT: 1,
    START: 8,
    UP: 16,
    RIGHT: 32,
    DOWN: 64,
    LEFT: 128,
    LTRIGGER: 256,
    RTRIGGER: 512,
    ZL: 1024,
    ZR: 2048,
    TRIANGLE: 4096,
    CIRCLE: 8192,
    CROSS: 16384,
    SQUARE: 32768
  });
  var KEYS = Object.freeze({
    ArrowUp: BTN.UP,
    ArrowRight: BTN.RIGHT,
    ArrowDown: BTN.DOWN,
    ArrowLeft: BTN.LEFT,
    KeyW: BTN.UP,
    KeyD: BTN.RIGHT,
    KeyS: BTN.DOWN,
    KeyA: BTN.LEFT,
    KeyZ: BTN.CROSS,
    Space: BTN.CROSS,
    KeyX: BTN.CIRCLE,
    Escape: BTN.CIRCLE,
    KeyJ: BTN.SQUARE,
    KeyK: BTN.TRIANGLE,
    KeyQ: BTN.LTRIGGER,
    KeyE: BTN.RTRIGGER,
    Enter: BTN.START,
    Tab: BTN.SELECT
  });
  var PAD_BUTTONS = [
    BTN.CROSS,
    BTN.CIRCLE,
    BTN.SQUARE,
    BTN.TRIANGLE,
    BTN.LTRIGGER,
    BTN.RTRIGGER,
    BTN.ZL,
    BTN.ZR,
    BTN.SELECT,
    BTN.START,
    0,
    0,
    BTN.UP,
    BTN.DOWN,
    BTN.LEFT,
    BTN.RIGHT
  ];
  var NEUTRAL = Object.freeze({ buttons: 0, analog: 32896, rightAnalog: 32896 });
  function axis(value, deadzone) {
    const finite = Number.isFinite(value) ? Math.max(-1, Math.min(1, value)) : 0;
    if (Math.abs(finite) <= deadzone)
      return 128;
    const normalized = Math.sign(finite) * (Math.abs(finite) - deadzone) / (1 - deadzone);
    return normalized < 0 ? Math.round(128 + normalized * 128) : Math.round(128 + normalized * 127);
  }

  class BrowserGameInput {
    constructor({ canvas, onChange, environment = globalThis, deadzone = 0.15 }) {
      if (!(deadzone >= 0 && deadzone < 1))
        throw new RangeError("Gamepad deadzone must be in [0, 1)");
      this.canvas = canvas;
      this.environment = environment;
      this.onChange = onChange;
      this.deadzone = deadzone;
      this.keys = new Set;
      this.value = { ...NEUTRAL };
      this.active = false;
      this.disposed = false;
      this.raf = null;
      this.originalTabIndex = canvas.getAttribute?.("tabindex") ?? null;
      if (canvas.tabIndex < 0)
        canvas.tabIndex = 0;
      this.keyDown = (event) => {
        if (!this.focused() || event.isComposing || event.ctrlKey || event.metaKey || event.altKey || !KEYS[event.code])
          return;
        this.keys.add(event.code);
        event.preventDefault();
        this.sample();
      };
      this.keyUp = (event) => {
        if (!this.keys.delete(event.code))
          return;
        event.preventDefault();
        this.sample();
      };
      this.focus = () => {
        this.sample();
        this.poll();
      };
      this.blur = () => {
        this.keys.clear();
        this.stopPoll();
        this.publish(NEUTRAL);
      };
      this.deviceChanged = () => {
        this.sample();
        this.poll();
      };
      canvas.addEventListener("keydown", this.keyDown);
      canvas.addEventListener("focus", this.focus);
      canvas.addEventListener("blur", this.blur);
      environment.addEventListener("keyup", this.keyUp);
      environment.addEventListener("blur", this.blur);
      environment.addEventListener("focus", this.focus);
      environment.addEventListener("gamepadconnected", this.deviceChanged);
      environment.addEventListener("gamepaddisconnected", this.deviceChanged);
    }
    focused() {
      const document2 = this.environment.document;
      return this.active && !this.disposed && document2?.activeElement === this.canvas && (!document2.hasFocus || document2.hasFocus());
    }
    state() {
      return { ...this.value };
    }
    pads() {
      try {
        return Array.from(this.environment.navigator?.getGamepads?.() || []).filter((pad) => pad?.connected && pad.mapping === "standard");
      } catch (_) {
        return [];
      }
    }
    publish(value) {
      if (this.value.buttons === value.buttons && this.value.analog === value.analog && this.value.rightAnalog === value.rightAnalog)
        return;
      this.value = { ...value };
      this.onChange?.(this.state());
    }
    sample() {
      if (!this.focused()) {
        this.publish(NEUTRAL);
        return;
      }
      let buttons = 0;
      for (const key of this.keys)
        buttons |= KEYS[key] || 0;
      const pad = this.pads()[0];
      if (pad)
        for (let index = 0;index < PAD_BUTTONS.length; index++) {
          if (pad.buttons[index]?.pressed)
            buttons |= PAD_BUTTONS[index];
        }
      const packed = (offset) => pad ? axis(pad.axes[offset], this.deadzone) << 8 | axis(pad.axes[offset + 1], this.deadzone) : 32896;
      this.publish({ buttons, analog: packed(0), rightAnalog: packed(2) });
    }
    poll() {
      if (this.raf !== null || !this.focused() || !this.pads().length)
        return;
      this.raf = this.environment.requestAnimationFrame(() => {
        this.raf = null;
        this.sample();
        this.poll();
      });
    }
    stopPoll() {
      if (this.raf !== null)
        this.environment.cancelAnimationFrame(this.raf);
      this.raf = null;
    }
    setActive(value) {
      this.active = !!value;
      if (!this.active)
        this.blur();
      else {
        this.sample();
        this.poll();
      }
    }
    dispose() {
      if (this.disposed)
        return;
      this.setActive(false);
      this.disposed = true;
      this.canvas.removeEventListener("keydown", this.keyDown);
      this.canvas.removeEventListener("focus", this.focus);
      this.canvas.removeEventListener("blur", this.blur);
      for (const [name, listener] of [
        ["keyup", this.keyUp],
        ["blur", this.blur],
        ["focus", this.focus],
        ["gamepadconnected", this.deviceChanged],
        ["gamepaddisconnected", this.deviceChanged]
      ]) {
        this.environment.removeEventListener(name, listener);
      }
      if (this.originalTabIndex === null)
        this.canvas.removeAttribute?.("tabindex");
      else
        this.canvas.setAttribute?.("tabindex", this.originalTabIndex);
    }
  }
  module.exports = { BrowserGameInput, BTN };
});

// targets/web/worker_transport.js
var require_worker_transport = __commonJS((exports, module) => {
  function createPocketWorkerTransport(options = {}) {
    const descriptor = options.descriptor;
    if (!descriptor || typeof descriptor !== "object")
      throw new TypeError("Worker descriptor is required");
    const engineUrl = String(options.engineUrl || "");
    const qjbcUrl = String(options.qjbcUrl || "");
    if (!engineUrl || !qjbcUrl)
      throw new TypeError("Worker engineUrl and qjbcUrl are required");
    const workerScript = `
const descriptor = ${JSON.stringify(descriptor)};
const engineUrl = ${JSON.stringify(engineUrl)};
const qjbcUrl = ${JSON.stringify(qjbcUrl)};
const origins = new Set(${JSON.stringify(Array.isArray(options.workerHttpOrigins) ? options.workerHttpOrigins.map(String) : [])});
const FACT = { ready: 1, complete: 2, data: 3, end: 4, timer: 6, channel: 7, headers: 8, error: 9 };
const STATUS = { ok: 0, failed: -1, cancelled: -2, unknown: -3, busy: -4, invalid: -5, unsupported: -6 };
let exportsRef, memory, workerPtr = 0, scratch = 0;
let closed = false, active = true, pumping = false, timer = 0, clockOffset = 0, pausedAt = 0, outputSequence = 1;
const resources = new Map(), requests = new Map(), queuedMessages = [], pendingReceives = [], pendingActions = [], pendingOutputs = new Map();
const MAX_QUEUED_MESSAGES = 64, MAX_PENDING_ACTIONS = 512;
const encoder = new TextEncoder(), decoder = new TextDecoder();
function wallNowMicros() { return Math.max(1, Math.floor((self.performance?.timeOrigin || Date.now()) * 1000 + (self.performance?.now?.() || 0) * 1000)); }
function nowMicros() {
  const wall = wallNowMicros();
  if (!active) { if (!pausedAt) pausedAt = wall; return Math.max(1, pausedAt - clockOffset); }
  if (pausedAt) { clockOffset += Math.max(0, wall - pausedAt); pausedAt = 0; }
  return Math.max(1, wall - clockOffset);
}
function bytesAt(pointer, length) { return new Uint8Array(memory.buffer, pointer, length).slice(); }
function withBytes(bytes, callback) {
  const value = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
  const pointer = exportsRef.web_alloc(value.length || 1);
  if (!pointer) throw new Error("Worker WASM allocation failed");
  try { new Uint8Array(memory.buffer, pointer, value.length).set(value); return callback(pointer, value.length); }
  finally { exportsRef.web_free(pointer, value.length || 1); }
}
function allowed(url) { try { return origins.has(new URL(url).origin); } catch (_) { return false; } }
function errorMessage(status, action) { return "PocketJS Worker " + action + " failed with status " + status; }
function runtimeError(fallback) {
  const pointer = exportsRef?.web_worker_error?.(workerPtr);
  if (!pointer || !memory) return fallback;
  const view = new Uint8Array(memory.buffer);
  let end = pointer;
  while (end < view.length && view[end]) end += 1;
  const message = decoder.decode(view.subarray(pointer, end));
  return message || fallback;
}
function invokeAction(action) {
  if (action.type === "emit") {
    return withBytes(action.payload, (pointer, length) => exportsRef.web_worker_emit(
      workerPtr, action.request, action.kind, action.status, action.offset, pointer, length));
  }
  return exportsRef.web_worker_finish(workerPtr, action.request, action.handle, action.status, action.offset);
}
function flushActions() {
  if (closed || !workerPtr) return;
  while (pendingActions.length) {
    const action = pendingActions[0];
    let status;
    try { status = invokeAction(action); }
    catch (error) {
      pendingActions.shift(); action.reject?.(error);
      self.postMessage({ type: "error", message: String(error?.message || error) });
      continue;
    }
    if (status === STATUS.busy) break;
    pendingActions.shift();
    if (status !== STATUS.ok) {
      const error = new Error(errorMessage(status, action.type));
      action.reject?.(error);
      self.postMessage({ type: "error", message: error.message });
    } else action.resolve?.();
  }
}
function enqueueAction(action) {
  if (closed || !workerPtr) return Promise.reject(new Error("PocketJS Worker is closed"));
  if (pendingActions.length >= MAX_PENDING_ACTIONS) return Promise.reject(new Error("PocketJS Worker fact queue is full"));
  return new Promise((resolve, reject) => {
    action.resolve = resolve; action.reject = reject;
    pendingActions.push(action);
    if (active) { flushActions(); if (!pumping) pump(); }
  });
}
function emit(kind, handle, request, status, offset, payload) {
  const bytes = payload instanceof Uint8Array ? payload.slice() : new Uint8Array(payload || []);
  return enqueueAction({ type: "emit", kind, handle, request, status, offset, payload: bytes });
}
function finish(request, handle, status, offset) {
  return enqueueAction({ type: "finish", request, handle, status, offset });
}
function schedulePump() {
  if (closed || !active || timer || pumping || !workerPtr) return;
  if (pendingReceives.length || pendingActions.length) {
    timer = setTimeout(() => { timer = 0; pump(); }, 0);
    return;
  }
  const deadline = Number(exportsRef.web_worker_deadline(workerPtr));
  if (!Number.isFinite(deadline) || deadline < 0) return;
  const delay = Math.max(1, Math.ceil((deadline - nowMicros()) / 1000));
  timer = setTimeout(() => { timer = 0; pump(); }, delay);
}
function flushReceives() {
  if (closed || !workerPtr) return;
  while (pendingReceives.length) {
    const message = pendingReceives[0];
    const data = message.data instanceof Uint8Array ? message.data : new Uint8Array(message.data || []);
    let status;
    try {
      status = withBytes(data, (pointer, length) => exportsRef.web_worker_receive(
        workerPtr, Number(message.channel || 0), pointer, length));
    } catch (error) {
      pendingReceives.shift();
      self.postMessage({ type: "error", message: String(error?.message || error) });
      continue;
    }
    if (status === STATUS.busy) break;
    pendingReceives.shift();
    if (message.seq) self.postMessage({ type: "channelAck", seq: message.seq, status });
    if (status !== STATUS.ok) self.postMessage({ type: "error", message: errorMessage(status, "channel receive") });
  }
}
function drainChannels() {
  if (pendingOutputs.size >= 8) return;
  const channels = Array.isArray(descriptor.declaration?.channels) ? descriptor.declaration.channels : [];
  const output = new Uint8Array(1024);
  if (!scratch) scratch = exportsRef.web_alloc(output.length);
  if (!scratch) throw new Error("Worker channel buffer allocation failed");
  for (let id = 1; id <= channels.length; id += 1) {
    if (channels[id - 1]?.direction !== "worker-to-ui") continue;
    for (let count = 0; count < 8 && pendingOutputs.size < 8; count += 1) {
      const length = exportsRef.web_worker_take(workerPtr, id, scratch, output.length);
      if (length < 0) break;
      const bytes = new Uint8Array(memory.buffer, scratch, length).slice();
      const seq = outputSequence++;
      pendingOutputs.set(seq, true);
      self.postMessage({ type: "channel", seq, channel: id, data: bytes }, [bytes.buffer]);
      if (length === 0) break;
    }
  }
}
function pump() {
  if (closed || !active || pumping || !workerPtr) return;
  pumping = true;
  try {
    flushReceives(); flushActions();
    for (let count = 0; count < 128; count += 1) {
      const result = exportsRef.web_worker_step(workerPtr, nowMicros());
      drainChannels();
      flushReceives(); flushActions();
      if (result !== 1) {
        if (result < 0) {
          const pointer = exportsRef.web_worker_error(workerPtr);
          let message = "PocketJS Worker failed";
          if (pointer) message = runtimeError(message);
          self.postMessage({ type: "error", message });
        }
        break;
      }
    }
  } finally { pumping = false; schedulePump(); }
}
function startHttp(handle, request) {
  const resource = resources.get(handle);
  if (!resource || !allowed(resource.options.url)) {
    void emit(FACT.error, handle, request, STATUS.unsupported, 0, new Uint8Array())
      .then(() => finish(request, handle, STATUS.unsupported, 0)).catch(() => {});
    return;
  }
  const controller = new AbortController();
  requests.set(request, { handle, controller });
  const timeoutValue = Number(resource.options.timeoutMs);
  const timeout = Math.max(1, Math.min(0x7fffffff, Number.isFinite(timeoutValue) && timeoutValue > 0 ? timeoutValue : 30000));
  const timeoutId = setTimeout(() => controller.abort(), timeout);
  (async () => {
    let offset = 0;
    try {
      const response = await fetch(String(resource.options.url), { method: String(resource.options.method || "GET"), headers: resource.options.headers || {}, body: resource.options.body, redirect: "error", signal: controller.signal });
      const headers = {};
      response.headers?.forEach?.((value, key) => { if (Object.keys(headers).length < 32) headers[String(key).toLowerCase()] = String(value).slice(0, 256); });
      let headerBytes = encoder.encode(JSON.stringify({ status: response.status, url: response.url, headers }));
      if (headerBytes.length > 1024) headerBytes = encoder.encode(JSON.stringify({ status: response.status, url: response.url }));
      await emit(FACT.ready, handle, request, STATUS.ok, 0, new Uint8Array());
      await emit(FACT.headers, handle, request, STATUS.ok, 0, headerBytes);
      if (response.body && String(resource.options.method || "GET") !== "HEAD") {
        const reader = response.body.getReader();
        const maxValue = Number(resource.options.maxBytes);
        const maxBytes = Math.max(1, Math.min(262144, Number.isFinite(maxValue) && maxValue > 0 ? maxValue : 262144));
        while (true) {
          const part = await reader.read();
          if (part.done) break;
          const bytes = part.value instanceof Uint8Array ? part.value : new Uint8Array(part.value || []);
          if (offset + bytes.length > maxBytes) throw Object.assign(new Error("HTTP response exceeds maxBytes"), { code: STATUS.failed });
          for (let at = 0; at < bytes.length; at += 1024) {
            const chunk = bytes.slice(at, Math.min(bytes.length, at + 1024));
            await emit(FACT.data, handle, request, STATUS.ok, offset, chunk); offset += chunk.length;
          }
        }
      }
      // The pinned core owns END/COMPLETE ordering. web_worker_emit only
      // accepts non-terminal facts; web_worker_finish appends END followed
      // by the canonical completion once all queued headers/data are seen.
      await finish(request, handle, STATUS.ok, offset);
    } catch (error) {
      const status = error?.name === "AbortError" ? STATUS.cancelled : (Number(error?.code) || STATUS.failed);
      try { await emit(FACT.error, handle, request, status, offset, new Uint8Array()); await finish(request, handle, status, offset); }
      catch (_) { /* The worker realm is already faulted or being disposed. */ }
    } finally { clearTimeout(timeoutId); requests.delete(request); pump(); }
  })();
}
function operation(op, handle, request, opcode, payloadPointer, payloadLength, capacity) {
  if (closed) return STATUS.cancelled;
  const payload = payloadLength > 0 ? bytesAt(payloadPointer, payloadLength) : new Uint8Array();
  if (op === 0) {
    let options; try { options = JSON.parse(decoder.decode(payload)); } catch (_) { return STATUS.invalid; }
    if (typeof options.url !== "string" || !allowed(options.url)) return STATUS.unsupported;
    resources.set(handle, { options }); return STATUS.ok;
  }
  if (op === 1) {
    if (!resources.has(handle) || opcode !== 1) return STATUS.invalid;
    if (!request) return STATUS.invalid;
    startHttp(handle, request); return STATUS.ok;
  }
  if (op === 2) { const pending = requests.get(request); if (!pending) return STATUS.invalid; pending.controller.abort(); return STATUS.ok; }
  if (op === 3) { const resource = resources.get(handle); if (!resource) return STATUS.invalid; for (const [id, pending] of requests) if (pending.handle === handle) { pending.controller.abort(); requests.delete(id); } resources.delete(handle); return STATUS.ok; }
  if (op === 4) return STATUS.unsupported;
  if (op === 5) return resources.has(handle) && opcode === 1 && payloadLength === 0 && capacity === 0 ? STATUS.ok : STATUS.invalid;
  return STATUS.invalid;
}
function receiveChannel(message) {
  const id = Number(message.channel || 0);
  const channels = Array.isArray(descriptor.declaration?.channels) ? descriptor.declaration.channels : [];
  const channel = channels[id - 1];
  const data = message.data instanceof Uint8Array ? message.data.slice() : new Uint8Array(message.data || []);
  if (!channel || channel.direction !== "ui-to-worker" || data.length > Number(channel.recordBytes || 0)) {
    if (message.seq) self.postMessage({ type: "channelAck", seq: message.seq, status: STATUS.invalid });
    self.postMessage({ type: "error", message: "PocketJS Worker channel input violates its descriptor" }); return;
  }
  if (!workerPtr) {
    if (queuedMessages.length >= MAX_QUEUED_MESSAGES) { if (message.seq) self.postMessage({ type: "channelAck", seq: message.seq, status: STATUS.busy }); self.postMessage({ type: "error", message: "PocketJS Worker channel bootstrap queue is full" }); return; }
    queuedMessages.push({ channel: id, data, seq: message.seq }); return;
  }
  if (pendingReceives.length >= MAX_QUEUED_MESSAGES) { if (message.seq) self.postMessage({ type: "channelAck", seq: message.seq, status: STATUS.busy }); self.postMessage({ type: "error", message: "PocketJS Worker channel queue is full" }); return; }
  pendingReceives.push({ channel: id, data, seq: message.seq });
  if (active) { flushReceives(); if (!pumping) pump(); }
}
async function boot() {
  const [wasmResponse, qjbcResponse] = await Promise.all([fetch(engineUrl), fetch(qjbcUrl)]);
  if (!wasmResponse.ok || !qjbcResponse.ok) throw new Error("PocketJS Worker artifact fetch failed");
  const wasmBytes = await wasmResponse.arrayBuffer();
  const qjbc = new Uint8Array(await qjbcResponse.arrayBuffer());
  const imports = { env: { __rquickjs_host_now_us: nowMicros }, pocket_web_worker: { now_micros: nowMicros, operation }, pocket_wechat: { host_emit: () => 0 } };
  const loaded = await WebAssembly.instantiate(wasmBytes, imports);
  exportsRef = loaded.instance?.exports || loaded.exports; memory = exportsRef.memory;
  if (typeof exportsRef.web_worker_create !== "function") throw new Error("PocketJS Web engine has no pinned Worker ABI");
  const config = encoder.encode(JSON.stringify(descriptor));
  workerPtr = withBytes(qjbc, (qjbcPointer, qjbcLength) => withBytes(config, (configPointer, configLength) => exportsRef.web_worker_create(qjbcPointer, qjbcLength, configPointer, configLength, Number(descriptor.tickHz || 60))));
  if (!workerPtr) throw new Error(runtimeError("PocketJS Worker QJBC was rejected"));
  self.postMessage({ type: "ready" });
  while (queuedMessages.length) receiveChannel(queuedMessages.shift());
  pump();
}
self.onmessage = event => { const message = event.data || {}; if (message.type === "channel") receiveChannel(message); else if (message.type === "outputAck") { pendingOutputs.delete(Number(message.seq || 0)); if (active) pump(); } else if (message.type === "active") { if (message.active && !active) { active = true; nowMicros(); } else if (!message.active && active) { pausedAt = wallNowMicros(); active = false; if (timer) { clearTimeout(timer); timer = 0; } } if (active) pump(); } else if (message.type === "dispose") { if (timer) clearTimeout(timer); if (workerPtr) exportsRef.web_worker_destroy(workerPtr); workerPtr = 0; if (scratch) exportsRef?.web_free(scratch, 1024); scratch = 0; closed = true; close(); } };
boot().catch(error => self.postMessage({ type: "error", message: String(error?.message || error) }));
`;
    const blobUrl = URL.createObjectURL(new Blob([workerScript], { type: "text/javascript" }));
    const worker = new Worker(blobUrl);
    const listeners = new Set;
    const inbound = [], inflight = new Map;
    const maxInbound = 64, maxInflight = 8;
    let sequence = 1;
    const outbound = [];
    const maxOutbound = 64;
    let closed = false, active = true, outboundTimer = 0;
    let readyResolve, readyReject;
    let settled = false;
    const ready = new Promise((resolve, reject) => {
      readyResolve = resolve;
      readyReject = reject;
    });
    const fail = (error) => {
      const value = error instanceof Error ? error : new Error(String(error?.message || error || "PocketJS Worker failed"));
      if (!settled) {
        settled = true;
        readyReject(value);
      }
      options.onError?.(value);
    };
    const flushOutbound = () => {
      if (closed || !active || outboundTimer)
        return;
      while (outbound.length) {
        const message = outbound[0];
        const accepted = listeners.size > 0 && [...listeners].every((listener) => listener(message.channel, message.data) !== false);
        if (!accepted) {
          outboundTimer = setTimeout(() => {
            outboundTimer = 0;
            flushOutbound();
          }, 16);
          return;
        }
        outbound.shift();
        worker.postMessage({ type: "outputAck", seq: message.seq });
      }
    };
    const pumpInbound = () => {
      if (closed)
        return;
      while (inflight.size < maxInflight && inbound.length) {
        const message = inbound.shift();
        const seq = sequence++;
        inflight.set(seq, message);
        const copy = message.data.slice();
        worker.postMessage({ type: "channel", seq, channel: message.channel, data: copy }, [copy.buffer]);
      }
    };
    worker.onmessage = (event) => {
      if (closed)
        return;
      const message = event.data || {};
      if (message.type === "ready") {
        if (!settled) {
          settled = true;
          readyResolve();
        }
      } else if (message.type === "channelAck") {
        const pending = inflight.get(Number(message.seq || 0));
        if (!pending)
          return;
        inflight.delete(Number(message.seq || 0));
        const status = Number(message.status);
        if (status === -4)
          inbound.unshift(pending);
        else if (status !== 0)
          fail(new Error("PocketJS Worker channel receive failed with status " + status));
        if (active)
          pumpInbound();
      } else if (message.type === "channel") {
        if (outbound.length >= maxOutbound) {
          fail(new Error("PocketJS Worker output channel queue is full"));
          return;
        }
        outbound.push({ seq: Number(message.seq || 0), channel: Number(message.channel || 0), data: new Uint8Array(message.data || []) });
        flushOutbound();
      } else if (message.type === "error")
        fail(new Error(String(message.message || "PocketJS Worker failed")));
    };
    worker.onerror = (error) => fail(error);
    return {
      ready,
      setActive(value) {
        if (closed)
          return;
        active = !!value;
        if (!active && outboundTimer) {
          clearTimeout(outboundTimer);
          outboundTimer = 0;
        }
        worker.postMessage({ type: "active", active });
        if (active) {
          pumpInbound();
          flushOutbound();
        }
      },
      receive(channel, data) {
        if (closed)
          return false;
        if (inbound.length + inflight.size >= maxInbound) {
          fail(new Error("PocketJS Worker input channel queue is full"));
          return false;
        }
        const copy = data instanceof Uint8Array ? data.slice() : new Uint8Array(data || []);
        inbound.push({ channel, data: copy });
        if (active)
          pumpInbound();
        return true;
      },
      subscribe(listener) {
        listeners.add(listener);
        return () => listeners.delete(listener);
      },
      dispose() {
        if (closed)
          return;
        worker.postMessage({ type: "dispose" });
        closed = true;
        setTimeout(() => worker.terminate(), 1000);
        if (outboundTimer)
          clearTimeout(outboundTimer);
        URL.revokeObjectURL(blobUrl);
        listeners.clear();
        outbound.length = 0;
        inbound.length = 0;
        inflight.clear();
      }
    };
  }
  module.exports = { createPocketWorkerTransport };
});

// targets/web/render_worker_transport.js
var require_render_worker_transport = __commonJS((exports, module) => {
  function errorFrom(value, fallback = "PocketJS rendering Worker failed") {
    return Object.assign(new Error(String(value?.message || value || fallback)), value?.code ? { code: String(value.code) } : {});
  }

  class PocketRenderWorkerHost {
    constructor(options) {
      if (typeof Worker !== "function" || typeof options.canvas.transferControlToOffscreen !== "function") {
        throw Object.assign(new Error("PocketJS renderWorker requires Worker and transferControlToOffscreen support"), { code: "unsupported" });
      }
      this.options = options;
      this.worker = null;
      this.pending = new Map;
      this.boundaries = new Map;
      this.nextId = 1;
      this.input = null;
      this.ready = false;
      this.disposed = false;
      this.disposeTimer = 0;
    }
    request(type, payload, transfer = []) {
      if (!this.worker || this.disposed)
        return Promise.reject(new Error("PocketJS rendering Worker is disposed"));
      if (this.pending.size >= 64 && payload.method !== "dispose")
        return Promise.reject(Object.assign(new Error("PocketJS rendering Worker command quota reached"), { code: "busy" }));
      const id = this.nextId++;
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          this.pending.delete(id);
          reject(Object.assign(new Error("PocketJS rendering Worker command timed out"), { code: "timeout" }));
        }, 20000);
        this.pending.set(id, { resolve, reject, timer });
        try {
          this.worker.postMessage({ type, id, ...payload }, transfer);
        } catch (error) {
          clearTimeout(timer);
          this.pending.delete(id);
          reject(error);
        }
      });
    }
    async start(width, height, devicePixelRatio) {
      if (this.disposed)
        throw new Error("PocketJS rendering Worker is disposed");
      this.worker = new Worker(this.options.workerUrl, { type: "module", name: "Pocket renderer" });
      this.worker.onmessage = (event) => this.message(event.data || {});
      this.worker.onerror = (event) => this.fail(errorFrom(event.error || event.message));
      this.worker.onmessageerror = () => this.fail(new Error("PocketJS rendering Worker message could not be decoded"));
      try {
        const canvas = this.options.canvas.transferControlToOffscreen();
        const result = await this.request("init", {
          canvas,
          width,
          height,
          devicePixelRatio,
          engineUrl: this.options.engineUrl,
          qjbcUrl: this.options.qjbcUrl,
          pakUrl: this.options.pakUrl,
          cache: this.options.cache,
          config: this.options.config,
          capabilityNames: this.options.capabilityNames
        }, [canvas]);
        if (this.disposed)
          throw new Error("PocketJS rendering Worker was disposed while mounting");
        this.ready = true;
        return result;
      } catch (error) {
        this.dispose();
        throw error;
      }
    }
    async message(message) {
      if (message.type === "reply") {
        const record = this.pending.get(message.id);
        if (!record)
          return;
        this.pending.delete(message.id);
        clearTimeout(record.timer);
        if (message.error)
          record.reject(errorFrom(message.error));
        else
          record.resolve(message.result);
        return;
      }
      if (this.disposed)
        return;
      if (message.type === "input") {
        this.input = message.value?.visible ? message.value : null;
        this.options.onInput?.(message.value);
      } else if (message.type === "error")
        this.options.onError?.(errorFrom(message.error));
      else if (message.type === "boundaryCancel") {
        this.boundaries.get(message.id)?.abort();
        this.boundaries.delete(message.id);
      } else if (message.type === "boundary") {
        if (this.boundaries.size >= 32 || this.boundaries.has(message.id)) {
          this.worker?.postMessage({ type: "boundaryResult", id: message.id, error: { code: "busy", message: "Browser boundary quota reached" } });
          return;
        }
        const controller = new AbortController;
        this.boundaries.set(message.id, controller);
        try {
          const result = await this.options.boundary(message.operation, message.params || {}, controller.signal);
          if (!this.disposed && this.boundaries.get(message.id) === controller) {
            try {
              this.worker.postMessage({ type: "boundaryResult", id: message.id, result });
            } catch (error) {
              this.worker.postMessage({
                type: "boundaryResult",
                id: message.id,
                error: { code: "invalid_result", message: String(error?.message || error) }
              });
            }
          }
        } catch (error) {
          if (!this.disposed && this.boundaries.get(message.id) === controller)
            this.worker.postMessage({
              type: "boundaryResult",
              id: message.id,
              error: { code: String(error?.code || "host_error"), message: String(error?.message || error) }
            });
        } finally {
          if (this.boundaries.get(message.id) === controller)
            this.boundaries.delete(message.id);
        }
      }
    }
    command(method, args = {}) {
      return this.request("command", { method, args });
    }
    notify(method, args = {}) {
      if (!this.ready || this.disposed)
        return;
      this.command(method, args).catch((error) => {
        if (!this.disposed)
          this.options.onError?.(error);
      });
    }
    inputFrame(contacts) {
      this.notify("inputFrame", { contacts, inputSample: this.options.sampleInput?.() || {} });
    }
    resize(width, height) {
      this.notify("resize", { width, height, devicePixelRatio: globalThis.devicePixelRatio || 1 });
    }
    show() {
      this.notify("show");
    }
    hide() {
      this.notify("hide");
      this.cancelBoundaries("Browser page inactive");
    }
    imeEdit(detail) {
      this.notify("imeEdit", { detail });
    }
    imeSubmit(detail) {
      this.notify("imeSubmit", { detail });
    }
    imeDismiss(detail) {
      this.notify("imeDismiss", { detail });
    }
    inspect() {
      return this.command("inspect");
    }
    stats() {
      return this.command("stats");
    }
    cancelBoundaries(message) {
      for (const [id, controller] of this.boundaries) {
        controller.abort();
        this.worker?.postMessage({ type: "boundaryResult", id, error: { code: "cancelled", message } });
      }
      this.boundaries.clear();
    }
    fail(error) {
      for (const record of this.pending.values()) {
        clearTimeout(record.timer);
        record.reject(error);
      }
      this.pending.clear();
      this.options.onError?.(error);
      this.dispose();
    }
    dispose() {
      if (this.disposed)
        return;
      const worker = this.worker;
      const disposalId = this.nextId;
      if (worker) {
        this.command("dispose").finally(() => {
          clearTimeout(this.disposeTimer);
          worker.terminate();
        }).catch(() => {});
        this.disposeTimer = setTimeout(() => {
          worker.terminate();
          const record = this.pending.get(disposalId);
          if (record) {
            clearTimeout(record.timer);
            this.pending.delete(disposalId);
            record.reject(new Error("PocketJS rendering Worker terminated"));
          }
        }, 1000);
      }
      this.disposed = true;
      this.ready = false;
      this.input = null;
      this.cancelBoundaries("Browser host disposed");
      for (const [id, record] of this.pending) {
        if (id === disposalId && worker)
          continue;
        clearTimeout(record.timer);
        record.reject(new Error("PocketJS rendering Worker is disposed"));
        this.pending.delete(id);
      }
    }
  }
  module.exports = { PocketRenderWorkerHost };
});

// targets/web/render_observations.js
var require_render_observations = __commonJS((exports, module) => {
  function observeRenderHost(host, mode) {
    let frameCount = 0, frameDurationMs = 0;
    const advance = host.advance.bind(host);
    host.advance = (...args) => {
      const start = performance.now();
      try {
        const value = advance(...args);
        frameCount++;
        return value;
      } finally {
        frameDurationMs += performance.now() - start;
      }
    };
    return {
      inspect() {
        if (!host.exports || !host.host || host.disposed)
          throw new Error("PocketJS runtime is not mounted");
        const ex = host.exports, nodes = [], queue = [0, 1], seen = new Set;
        while (queue.length && seen.size < 16384) {
          const id = queue.shift();
          if (seen.has(id))
            continue;
          seen.add(id);
          if (ex.web_inspect(host.host, id) !== 0)
            throw new Error("PocketJS node inspection failed");
          const bytes = new Uint8Array(ex.memory.buffer, ex.web_result_ptr(host.host), ex.web_result_len(host.host));
          const node = JSON.parse(new TextDecoder().decode(bytes));
          if (!node)
            continue;
          nodes.push({ ...node, id });
          if (Array.isArray(node.children))
            queue.push(...node.children);
        }
        return { nodes };
      },
      stats() {
        return {
          mode,
          thread: mode === "worker" ? "worker" : "main",
          frameCount,
          frameDurationMs,
          width: host.logicalWidth,
          height: host.logicalHeight,
          pixelWidth: host.canvas.width,
          pixelHeight: host.canvas.height,
          visible: host.visible,
          disposed: host.disposed
        };
      }
    };
  }
  module.exports = { observeRenderHost };
});

// targets/web/live2d_provider.js
var require_live2d_provider = __commonJS((exports, module) => {
  (function exposeLive2dProvider(root, factory) {
    if (typeof module === "object" && module.exports)
      module.exports = factory();
    else
      root.PocketLive2dProvider = factory();
  })(globalThis, function createLive2dProviderModule() {
    const LOAD = "media.live2d.model.load";
    const UPDATE = "media.live2d.model.update";
    const RELEASE = "media.live2d.model.release";
    const PMS1_MAGIC = 827542864;
    const MAX_MODELS = 4;
    const MAX_MOC_BYTES = 32 * 1024 * 1024;
    const MAX_PROVIDER_BYTES = 128 * 1024 * 1024;
    const MAX_TEXTURES = 16;
    const MAX_IDENTIFIER_LENGTH = 64;
    const MAX_VERTICES = 16384;
    const MAX_INDICES = 98304;
    const MAX_FRAME_BYTES = 3 * 1024 * 1024;
    const LITTLE_ENDIAN = new Uint8Array(new Uint16Array([1]).buffer)[0] === 1;
    function error(code, message, cause) {
      const value = new Error(message, cause === undefined ? undefined : { cause });
      value.code = code;
      return value;
    }
    function ensureRecord(value, name) {
      if (value === null || typeof value !== "object" || Array.isArray(value)) {
        throw error("invalid_request", `${name} must be an object`);
      }
      return value;
    }
    function identifier(value, name) {
      if (typeof value !== "string" || value.length === 0 || value.length > MAX_IDENTIFIER_LENGTH || !/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(value)) {
        throw error("invalid_request", `${name} must be a short non-empty identifier`);
      }
      return value;
    }
    function assetKey(value, name) {
      if (typeof value !== "string" || value.length === 0 || value.length > 256 || !/^[A-Za-z0-9._/-]+$/.test(value) || value.startsWith("/") || value.includes("://") || value.split("/").some((part) => part.length === 0 || part === "." || part === "..")) {
        throw error("invalid_request", `${name} must be a safe relative asset key`);
      }
      return value;
    }
    function arrayLike(value, name, expectedLength) {
      if (value === null || value === undefined || !Number.isSafeInteger(value.length) || value.length < 0 || expectedLength !== undefined && value.length !== expectedLength) {
        throw error("live2d_core_invalid", `Cubism Core returned an invalid ${name} array`);
      }
      return value;
    }
    function finite(value, name) {
      if (typeof value !== "number" || !Number.isFinite(value)) {
        throw error("live2d_core_invalid", `Cubism Core returned a non-finite ${name}`);
      }
      return value;
    }
    function integer(value, name, minimum = 0) {
      if (!Number.isSafeInteger(value) || value < minimum) {
        throw error("live2d_core_invalid", `Cubism Core returned an invalid ${name}`);
      }
      return value;
    }
    function isUint8Array(value) {
      return value !== null && typeof value === "object" && Object.prototype.toString.call(value) === "[object Uint8Array]";
    }
    function bytesFromAsset(value, key) {
      if (!isUint8Array(value))
        throw error("live2d_asset_invalid", `Asset "${key}" must resolve to Uint8Array bytes`);
      if (value.byteLength === 0)
        throw error("live2d_asset_empty", `Asset "${key}" is empty`);
      if (value.byteLength > MAX_MOC_BYTES)
        throw error("live2d_resource_limit", "MOC3 asset exceeds the 32 MiB model input limit");
      const bytes = new Uint8Array(value.byteLength);
      bytes.set(value);
      return bytes;
    }
    function checkSignal(signal) {
      if (signal?.aborted)
        throw error("cancelled", "Live2D request was cancelled");
    }
    function visibleBufferBytes(mocBytes, model) {
      const parameters = model.parameters;
      const parts = model.parts;
      const drawables = model.drawables;
      let bytes = mocBytes.byteLength;
      const addView = (value) => {
        if (value && Number.isSafeInteger(value.byteLength) && value.byteLength >= 0)
          bytes += value.byteLength;
      };
      for (const value of [
        parameters.minimumValues,
        parameters.maximumValues,
        parameters.defaultValues,
        parameters.values,
        parameters.types,
        parts.opacities,
        parts.parentIndices,
        drawables.constantFlags,
        drawables.dynamicFlags,
        drawables.textureIndices,
        drawables.drawOrders,
        drawables.renderOrders,
        drawables.opacities,
        drawables.maskCounts,
        drawables.vertexCounts,
        drawables.indexCounts,
        drawables.multiplyColors,
        drawables.screenColors,
        drawables.parentPartIndices
      ]) {
        addView(value);
      }
      const drawableCount = integer(drawables.count, "drawable count");
      for (let index = 0;index < drawableCount; index++) {
        addView(drawables.masks[index]);
        addView(drawables.vertexPositions[index]);
        addView(drawables.vertexUvs[index]);
        addView(drawables.indices[index]);
      }
      return bytes;
    }
    function isFiniteNumber(value) {
      return typeof value === "number" && Number.isFinite(value);
    }
    function isNonNegativeSafeInteger(value) {
      return Number.isSafeInteger(value) && value >= 0;
    }
    function floatBytes(values, name) {
      arrayLike(values, name);
      const bytes = new Uint8Array(values.length * 4);
      const view = new DataView(bytes.buffer);
      for (let index = 0;index < values.length; index++) {
        const value = values[index];
        if (!isFiniteNumber(value))
          throw error("live2d_core_invalid", `Cubism Core returned a non-finite ${name}[${index}]`);
        view.setFloat32(index * 4, value, true);
      }
      return bytes;
    }
    function rgbaBytes(values, baseOffset, index, kind) {
      arrayLike(values, `drawable ${index} ${kind} color`);
      if (baseOffset < 0 || baseOffset + 4 > values.length) {
        throw error("live2d_core_invalid", `Cubism Core returned an invalid drawable ${index} ${kind} color array`);
      }
      const bytes = new Uint8Array(16);
      const view = new DataView(bytes.buffer);
      for (let component = 0;component < 4; component++) {
        const value = values[baseOffset + component];
        if (!isFiniteNumber(value)) {
          throw error("live2d_core_invalid", `Cubism Core returned a non-finite drawable ${index} ${kind} color[${component}]`);
        }
        view.setFloat32(component * 4, value, true);
      }
      return bytes;
    }
    function uint32Bytes(values, name) {
      arrayLike(values, name);
      const bytes = new Uint8Array(values.length * 4);
      const view = new DataView(bytes.buffer);
      for (let index = 0;index < values.length; index++) {
        const value = values[index];
        if (!isNonNegativeSafeInteger(value))
          throw error("live2d_core_invalid", `Cubism Core returned an invalid ${name}[${index}]`);
        view.setUint32(index * 4, value, true);
      }
      return bytes;
    }
    function responseIdentifier(value) {
      return identifier(value, "Core identifier");
    }
    function createLive2dProvider(options) {
      const settings = ensureRecord(options, "options");
      if (typeof settings.core !== "function")
        throw new TypeError("createLive2dProvider requires core() to load an official Cubism Web Core");
      if (typeof settings.readAsset !== "function")
        throw new TypeError("createLive2dProvider requires a packaged readAsset(key, signal) resolver");
      const maxModels = settings.maxModels ?? MAX_MODELS;
      const maxMocBytes = settings.maxMocBytes ?? MAX_MOC_BYTES;
      const maxProviderBytes = settings.maxProviderBytes ?? MAX_PROVIDER_BYTES;
      const maxTextures = settings.maxTextures ?? MAX_TEXTURES;
      if (!Number.isSafeInteger(maxModels) || maxModels < 1 || maxModels > MAX_MODELS || !Number.isSafeInteger(maxMocBytes) || maxMocBytes < 1 || maxMocBytes > MAX_MOC_BYTES || !Number.isSafeInteger(maxProviderBytes) || maxProviderBytes < 1 || maxProviderBytes > MAX_PROVIDER_BYTES || !Number.isSafeInteger(maxTextures) || maxTextures < 1 || maxTextures > MAX_TEXTURES) {
        throw new RangeError("Live2D Web limits may not exceed the native provider limits");
      }
      const models = new Map;
      const pendingLoads = new Set;
      let pendingLoadCount = 0;
      let totalBytes = 0;
      let nextModelId = 0;
      let corePromise;
      let disposed = false;
      async function getCore() {
        if (!corePromise) {
          corePromise = Promise.resolve().then(() => settings.core()).then((core) => {
            if (!core?.Moc?.fromArrayBuffer || !core?.Model?.fromMoc || typeof core?.Version?.csmGetVersion !== "function" || typeof core?.Version?.csmGetMocVersion !== "function" || core.Version.csmGetVersion() <= 0) {
              throw error("live2d_core_unavailable", "The supplied Cubism Web Core is missing required model APIs");
            }
            return core;
          }).catch((cause) => {
            corePromise = undefined;
            throw cause?.code ? cause : error("live2d_core_unavailable", "Could not initialize Cubism Web Core", cause);
          });
        }
        return corePromise;
      }
      function validateValues(value, name, { opacity = false } = {}) {
        if (!Array.isArray(value))
          throw error("invalid_request", `${name} must be an array`);
        const seen = new Set;
        return value.map((entry, index) => {
          const item = ensureRecord(entry, `${name}[${index}]`);
          const id = identifier(item.id, `${name}[${index}].id`);
          const number = finite(item.value, `${name}.${id} value`);
          if (opacity && (number < 0 || number > 1))
            throw error("invalid_request", `${name}.${id} must be between zero and one`);
          if (seen.has(id))
            throw error("invalid_request", `${name} contains duplicate id "${id}"`);
          seen.add(id);
          return { id, value: number };
        });
      }
      function validatePlacement(value) {
        if (value === undefined || value === null)
          return { dx: 0, dy: 0, scale: 1, opacity: 1 };
        const placement = ensureRecord(value, "placement");
        const dx = finite(placement.dx, "placement.dx");
        const dy = finite(placement.dy, "placement.dy");
        const scale = finite(placement.scale, "placement.scale");
        const opacity = placement.opacity === undefined ? 1 : finite(placement.opacity, "placement.opacity");
        if (scale <= 0)
          throw error("invalid_request", "placement.scale must be positive");
        return { dx, dy, scale, opacity: Math.max(0, Math.min(1, opacity)) };
      }
      function queue(slot, operation) {
        const previous = slot.tail || Promise.resolve();
        const next = previous.catch(() => {}).then(operation);
        slot.tail = next;
        next.then(() => {
          if (slot.tail === next)
            slot.tail = undefined;
        }, () => {
          if (slot.tail === next)
            slot.tail = undefined;
        });
        return next;
      }
      function destroySlot(slot) {
        if (slot.destroyed)
          return;
        slot.destroyed = true;
        let failure;
        try {
          slot.model.release();
        } catch (cause) {
          failure = cause;
        }
        try {
          slot.moc._release();
        } catch (cause) {
          failure ??= cause;
        }
        totalBytes = Math.max(0, totalBytes - slot.bytes);
        if (failure)
          throw error("live2d_model_release_failed", `Could not release model "${slot.modelId}": ${failure.message || failure}`, failure);
      }
      async function loadModel(rawParams, signal) {
        if (disposed)
          throw error("live2d_provider_disposed", "Live2D provider is disposed");
        const params = ensureRecord(rawParams, "load params");
        const requestedId = identifier(params.id, "id");
        const mocAsset = assetKey(params.mocAsset, "mocAsset");
        if (!mocAsset.toLowerCase().endsWith(".moc3"))
          throw error("invalid_request", "mocAsset must name a MOC3 asset");
        if (!Array.isArray(params.textures) || params.textures.length === 0 || params.textures.length > maxTextures) {
          throw error("invalid_request", `textures must contain between 1 and ${maxTextures} packaged asset keys`);
        }
        const textures = params.textures.map((value, index) => assetKey(value, `textures[${index}]`));
        if (models.size + pendingLoadCount >= maxModels)
          throw error("live2d_model_limit", "Live2D model limit reached");
        pendingLoadCount++;
        let moc;
        let model;
        try {
          checkSignal(signal);
          let loaded;
          try {
            loaded = await settings.readAsset(mocAsset, signal);
          } catch (cause) {
            if (signal?.aborted || cause?.name === "AbortError" || cause?.code === "cancelled")
              throw cause;
            throw cause?.code ? cause : error("live2d_asset_load_failed", `Could not load packaged MOC3 asset "${mocAsset}"`, cause);
          }
          checkSignal(signal);
          const mocBytes = bytesFromAsset(loaded, mocAsset);
          if (mocBytes.byteLength > maxMocBytes)
            throw error("live2d_resource_limit", `MOC3 asset exceeds the ${maxMocBytes}-byte model input limit`);
          const core = await getCore();
          checkSignal(signal);
          try {
            moc = core.Moc.fromArrayBuffer(mocBytes.buffer);
          } catch (cause) {
            throw error("live2d_core_create_failed", `Cubism Core rejected model "${requestedId}": ${cause.message || cause}`, cause);
          }
          if (!moc)
            throw error("live2d_core_create_failed", `Cubism Core rejected model "${requestedId}"`);
          const mocVersion = integer(core.Version.csmGetMocVersion(moc, mocBytes), "MOC version");
          if (mocVersion === 0)
            throw error("live2d_core_create_failed", "Cubism Core returned an unknown MOC version");
          try {
            model = core.Model.fromMoc(moc);
          } catch (cause) {
            throw error("live2d_core_create_failed", `Cubism Core could not create model "${requestedId}": ${cause.message || cause}`, cause);
          }
          if (!model)
            throw error("live2d_core_create_failed", `Cubism Core could not create model "${requestedId}"`);
          checkSignal(signal);
          const { parameters: p, parts: part, drawables: d, canvasinfo: canvasInfo } = model;
          if (!p || !part || !d || !canvasInfo)
            throw error("live2d_core_invalid", "Cubism Core returned incomplete model data");
          const parameterCount = integer(p.count, "parameter count");
          const partCount = integer(part.count, "part count");
          const drawableCount = integer(d.count, "drawable count");
          const parameterIds = arrayLike(p.ids, "parameter IDs", parameterCount);
          const parameterMinimums = arrayLike(p.minimumValues, "parameter minimums", parameterCount);
          const parameterMaximums = arrayLike(p.maximumValues, "parameter maximums", parameterCount);
          const parameterDefaults = arrayLike(p.defaultValues, "parameter defaults", parameterCount);
          const parameterValues = arrayLike(p.values, "parameter values", parameterCount);
          const partIds = arrayLike(part.ids, "part IDs", partCount);
          const partValues = arrayLike(part.opacities, "part opacities", partCount);
          const drawableIds = arrayLike(d.ids, "drawable IDs", drawableCount);
          const textureIndices = arrayLike(d.textureIndices, "drawable texture indices", drawableCount);
          const ids = new Map;
          const partIdIndices = new Map;
          const defaults = new Float32Array(parameterCount);
          const metadata = new Array(parameterCount);
          const partDefaults = new Float32Array(partCount);
          const parts = new Array(partCount);
          for (let index = 0;index < parameterCount; index++) {
            const id = responseIdentifier(parameterIds[index]);
            if (ids.has(id))
              throw error("live2d_core_invalid", `Cubism Core returned duplicate parameter id "${id}"`);
            const minimum = finite(parameterMinimums[index], `${id} minimum`);
            const maximum = finite(parameterMaximums[index], `${id} maximum`);
            const value = finite(parameterDefaults[index], `${id} default`);
            if (minimum > maximum || value < minimum || value > maximum)
              throw error("live2d_core_invalid", `Cubism Core returned invalid parameter bounds for "${id}"`);
            ids.set(id, index);
            defaults[index] = value;
            metadata[index] = { id, minimum, maximum, defaultValue: value };
          }
          for (let index = 0;index < partCount; index++) {
            const id = responseIdentifier(partIds[index]);
            if (partIdIndices.has(id))
              throw error("live2d_core_invalid", `Cubism Core returned duplicate part id "${id}"`);
            const value = finite(partValues[index], `${id} opacity`);
            if (value < 0 || value > 1)
              throw error("live2d_core_invalid", `Cubism Core returned invalid part opacity for "${id}"`);
            partIdIndices.set(id, index);
            partDefaults[index] = value;
            parts[index] = { id, defaultOpacity: value };
          }
          const canvas = {
            widthPixels: finite(canvasInfo.CanvasWidth, "canvas width"),
            heightPixels: finite(canvasInfo.CanvasHeight, "canvas height"),
            originXPixels: finite(canvasInfo.CanvasOriginX, "canvas origin x"),
            originYPixels: finite(canvasInfo.CanvasOriginY, "canvas origin y"),
            pixelsPerUnit: finite(canvasInfo.PixelsPerUnit, "canvas pixels per unit")
          };
          if (canvas.widthPixels <= 0 || canvas.heightPixels <= 0 || canvas.pixelsPerUnit <= 0)
            throw error("live2d_core_invalid", "Cubism Core returned an invalid model canvas");
          for (let index = 0;index < drawableCount; index++) {
            const textureIndex = integer(textureIndices[index], `drawable ${index} texture index`, -2147483647);
            const indexCount = integer(d.indexCounts[index], `drawable ${index} index count`);
            if (indexCount > 0 && textureIndex >= textures.length)
              throw error("live2d_texture_not_found", `Core drawable "${drawableIds[index]}" references texture ${textureIndex}, but only ${textures.length} textures were provided`);
          }
          const bytes = visibleBufferBytes(mocBytes, model);
          if (!Number.isSafeInteger(bytes) || bytes <= 0 || bytes > maxProviderBytes || totalBytes + bytes > maxProviderBytes) {
            throw error("live2d_resource_limit", "The MOC input and Core-visible buffers would exceed the 128 MiB Web provider byte budget");
          }
          if (disposed)
            throw error("live2d_provider_disposed", "Live2D provider was disposed while a model was loading");
          const modelId = `live2d-web-${++nextModelId}`;
          const slot = {
            modelId,
            requestedId,
            moc,
            model,
            mocBytes,
            bytes,
            mocVersion,
            textures,
            parameterIds: ids,
            parameterDefaults: defaults,
            parameterMetadata: metadata,
            partIds: partIdIndices,
            partDefaults,
            parts,
            canvas,
            drawableCount,
            topology: undefined,
            tail: undefined,
            destroyed: false
          };
          models.set(modelId, slot);
          totalBytes += bytes;
          moc = undefined;
          model = undefined;
          return {
            modelId,
            drawableCount,
            mocVersion,
            nativeBytes: bytes,
            parameterCount,
            parameterDefaults: metadata.map(({ id, defaultValue }) => ({ id, value: defaultValue })),
            parameterMetadata: metadata,
            parts,
            canvas,
            textures,
            memoryAccounting: "core-visible-buffers"
          };
        } catch (cause) {
          if (model) {
            try {
              model.release();
            } catch (_) {}
          }
          if (moc) {
            try {
              moc._release();
            } catch (_) {}
          }
          throw cause;
        } finally {
          pendingLoadCount--;
        }
      }
      function makePms1(slot, drawable, index, placement, modelOpacity) {
        const positions = arrayLike(drawable.vertexPositions[index], `drawable ${index} positions`);
        const uvs = arrayLike(drawable.vertexUvs[index], `drawable ${index} UVs`);
        const indices = arrayLike(drawable.indices[index], `drawable ${index} indices`);
        const vertexCount = integer(drawable.vertexCounts[index], `drawable ${index} vertex count`);
        const indexCount = integer(drawable.indexCounts[index], `drawable ${index} index count`);
        if (positions.length !== vertexCount * 2 || uvs.length !== vertexCount * 2 || indices.length !== indexCount) {
          throw error("live2d_topology_changed", `Core drawable ${index} returned inconsistent mesh arrays`);
        }
        if (vertexCount === 0 || indexCount === 0)
          return new Uint8Array(0);
        if (vertexCount > MAX_VERTICES || indexCount < 3 || indexCount > MAX_INDICES || indexCount % 3 !== 0) {
          throw error("live2d_resource_limit", `Core drawable ${index} exceeds Pocket mesh limits`);
        }
        if (drawable.textureIndices[index] < 0 || drawable.textureIndices[index] >= slot.textures.length) {
          throw error("live2d_texture_not_found", `Core drawable ${index} references an unavailable model texture`);
        }
        const rawOpacity = drawable.opacities[index];
        if (!isFiniteNumber(rawOpacity)) {
          throw error("live2d_core_invalid", `Cubism Core returned a non-finite drawable ${index} opacity`);
        }
        const byteLength = 16 + vertexCount * 16 + indexCount * 4;
        const bytes = new Uint8Array(byteLength);
        const opacity = Math.max(0, Math.min(1, rawOpacity * modelOpacity));
        const opacityByte = Math.floor(opacity * 255 + 0.5);
        const headerColor = (opacityByte << 24 | 16777215) >>> 0;
        const originX = slot.canvas.originXPixels;
        const originY = slot.canvas.originYPixels;
        const pixelsPerUnit = slot.canvas.pixelsPerUnit;
        const dx = placement.dx;
        const dy = placement.dy;
        const scale = placement.scale;
        let u32;
        let f32;
        let view;
        if (LITTLE_ENDIAN) {
          u32 = new Uint32Array(bytes.buffer);
          f32 = new Float32Array(bytes.buffer);
          u32[0] = PMS1_MAGIC;
          u32[1] = vertexCount;
          u32[2] = indexCount;
          u32[3] = headerColor;
        } else {
          view = new DataView(bytes.buffer);
          view.setUint32(0, PMS1_MAGIC, true);
          view.setUint32(4, vertexCount, true);
          view.setUint32(8, indexCount, true);
          view.setUint32(12, headerColor, true);
        }
        let offset = 16;
        for (let vertex = 0;vertex < vertexCount; vertex++) {
          const pair = vertex * 2;
          const rawX = positions[pair];
          if (!isFiniteNumber(rawX))
            throw error("live2d_core_invalid", `Cubism Core returned a non-finite drawable ${index} x`);
          const rawY = positions[pair + 1];
          if (!isFiniteNumber(rawY))
            throw error("live2d_core_invalid", `Cubism Core returned a non-finite drawable ${index} y`);
          const placedX = dx + (originX + rawX * pixelsPerUnit) * scale;
          const placedY = dy + (originY - rawY * pixelsPerUnit) * scale;
          const rawU = uvs[pair];
          if (!isFiniteNumber(rawU))
            throw error("live2d_core_invalid", `Cubism Core returned a non-finite drawable ${index} u`);
          const rawV = uvs[pair + 1];
          if (!isFiniteNumber(rawV))
            throw error("live2d_core_invalid", `Cubism Core returned a non-finite drawable ${index} v`);
          const u = rawU;
          const v = 1 - rawV;
          if (!Number.isFinite(placedX) || Math.abs(placedX) > 1e6 || !Number.isFinite(placedY) || Math.abs(placedY) > 1e6 || !Number.isFinite(u) || Math.abs(u) > 1e6 || !Number.isFinite(v) || Math.abs(v) > 1e6) {
            throw error("live2d_mesh_invalid", `Core drawable ${index} contains out-of-range mesh coordinates`);
          }
          if (f32) {
            const word = offset >>> 2;
            f32[word] = placedX;
            f32[word + 1] = placedY;
            f32[word + 2] = u;
            f32[word + 3] = v;
          } else {
            view.setFloat32(offset, placedX, true);
            view.setFloat32(offset + 4, placedY, true);
            view.setFloat32(offset + 8, u, true);
            view.setFloat32(offset + 12, v, true);
          }
          offset += 16;
        }
        for (let item = 0;item < indexCount; item++) {
          const vertexIndex = indices[item];
          if (!isNonNegativeSafeInteger(vertexIndex)) {
            throw error("live2d_core_invalid", `Cubism Core returned an invalid drawable ${index} index ${item}`);
          }
          if (vertexIndex >= vertexCount)
            throw error("live2d_mesh_invalid", `Core drawable ${index} has an index outside its vertex range`);
          if (u32) {
            u32[offset >>> 2] = vertexIndex;
          } else {
            view.setUint32(offset, vertexIndex, true);
          }
          offset += 4;
        }
        return bytes;
      }
      function makeDrawable(slot, index, placement, cacheTopology) {
        const model = slot.model;
        const d = model.drawables;
        const vertexCount = integer(d.vertexCounts[index], `drawable ${index} vertex count`);
        const indexCount = integer(d.indexCounts[index], `drawable ${index} index count`);
        const maskCount = integer(d.maskCounts[index], `drawable ${index} mask count`);
        const id = responseIdentifier(d.ids[index]);
        const masks = arrayLike(d.masks[index], `drawable ${index} masks`, maskCount);
        const previous = cacheTopology ? slot.topology?.[index] : undefined;
        if (previous && (previous.id !== id || previous.vertexCount !== vertexCount || previous.indexCount !== indexCount || previous.maskCount !== maskCount)) {
          throw error("live2d_topology_changed", "Drawable identity or static topology changed while the model was loaded");
        }
        const meshBytes = makePms1(slot, d, index, placement, placement.opacity);
        const maskIndices = previous ? undefined : uint32Bytes(masks, `drawable ${index} masks`);
        const multiplyColorRgba = rgbaBytes(d.multiplyColors, index * 4, index, "multiply");
        const screenColorRgba = rgbaBytes(d.screenColors, index * 4, index, "screen");
        const blendModes = d.blendModes;
        const constantFlags = integer(d.constantFlags[index], `drawable ${index} constant flags`);
        let blendMode;
        if (blendModes && blendModes.length === slot.drawableCount) {
          blendMode = integer(blendModes[index], `drawable ${index} blend mode`);
          const colorBlend = blendMode & 255;
          const alphaBlend = blendMode >>> 8 & 255;
          if (![0, 3, 6, 10].includes(colorBlend) || alphaBlend !== 0 || blendMode >>> 16 !== 0) {
            throw error("live2d_blend_mode_unsupported", `Core drawable "${id}" uses unsupported Cubism color/alpha blend ${colorBlend}/${alphaBlend}`);
          }
        } else {
          const additive = (constantFlags & 1) !== 0;
          const multiplicative = (constantFlags & 2) !== 0;
          if (additive && multiplicative)
            throw error("live2d_core_invalid", `Core drawable "${id}" has conflicting legacy blend flags`);
          blendMode = additive ? 3 : multiplicative ? 6 : 0;
        }
        return {
          id,
          textureIndex: integer(d.textureIndices[index], `drawable ${index} texture index`, -2147483647),
          drawOrder: integer(d.drawOrders[index], `drawable ${index} draw order`, -2147483647),
          renderOrder: integer(d.renderOrders[index], `drawable ${index} render order`, -2147483647),
          blendMode,
          constantFlags,
          dynamicFlags: integer(d.dynamicFlags[index], `drawable ${index} dynamic flags`),
          opacity: finite(d.opacities[index], `drawable ${index} opacity`),
          meshBytes,
          ...previous ? {} : { maskIndices },
          multiplyColorRgba,
          screenColorRgba
        };
      }
      async function updateModel(rawParams, signal) {
        if (disposed)
          throw error("live2d_provider_disposed", "Live2D provider is disposed");
        const params = ensureRecord(rawParams, "update params");
        const modelId = identifier(params.modelId, "modelId");
        const slot = models.get(modelId);
        if (!slot)
          throw error("live2d_model_not_found", `modelId "${modelId}" does not identify a loaded Live2D model`);
        const parameters = validateValues(params.parameters, "parameters");
        const partOpacities = validateValues(params.partOpacities, "partOpacities", { opacity: true });
        const placement = validatePlacement(params.placement);
        if (params.cacheStaticTopology !== undefined && typeof params.cacheStaticTopology !== "boolean") {
          throw error("invalid_request", "cacheStaticTopology must be a boolean when present");
        }
        const cacheTopology = params.cacheStaticTopology === true;
        return queue(slot, async () => {
          checkSignal(signal);
          if (disposed || models.get(modelId) !== slot)
            throw error("live2d_model_not_found", `modelId "${modelId}" does not identify a loaded Live2D model`);
          const p = slot.model.parameters;
          const part = slot.model.parts;
          for (let index = 0;index < slot.parameterDefaults.length; index++)
            p.values[index] = slot.parameterDefaults[index];
          for (let index = 0;index < slot.partDefaults.length; index++)
            part.opacities[index] = slot.partDefaults[index];
          for (const entry of parameters) {
            const index = slot.parameterIds.get(entry.id);
            if (index === undefined)
              throw error("live2d_parameter_not_found", `Core parameter "${entry.id}" does not exist`);
            p.values[index] = entry.value;
          }
          for (const entry of partOpacities) {
            const index = slot.partIds.get(entry.id);
            if (index === undefined)
              throw error("live2d_parameter_not_found", `Core part "${entry.id}" does not exist`);
            part.opacities[index] = entry.value;
          }
          try {
            slot.model.update();
          } catch (cause) {
            throw error("live2d_update_failed", `Cubism Core could not update model "${modelId}": ${cause.message || cause}`, cause);
          }
          const drawables = new Array(slot.drawableCount);
          let frameBytes = 0;
          const topologies = cacheTopology && !slot.topology ? new Array(slot.drawableCount) : undefined;
          for (let index = 0;index < slot.drawableCount; index++) {
            const drawable = makeDrawable(slot, index, placement, cacheTopology);
            frameBytes += drawable.meshBytes.byteLength + drawable.multiplyColorRgba.byteLength + drawable.screenColorRgba.byteLength + (drawable.maskIndices?.byteLength || 0);
            if (frameBytes > MAX_FRAME_BYTES)
              throw error("live2d_resource_limit", "Live2D frame exceeds the 3 MiB browser response limit");
            drawables[index] = drawable;
            if (topologies)
              topologies[index] = {
                id: drawable.id,
                vertexCount: slot.model.drawables.vertexCounts[index],
                indexCount: slot.model.drawables.indexCounts[index],
                maskCount: slot.model.drawables.maskCounts[index]
              };
          }
          if (topologies)
            slot.topology = topologies;
          return { modelId, drawables, ...cacheTopology ? { topologyMode: topologies ? "full" : "cached-v1" } : {} };
        });
      }
      async function releaseModel(rawParams, internal = false) {
        if (disposed && !internal)
          throw error("live2d_provider_disposed", "Live2D provider is disposed");
        const params = ensureRecord(rawParams, "release params");
        const modelId = identifier(params.modelId, "modelId");
        const slot = models.get(modelId);
        if (!slot)
          throw error("live2d_model_not_found", `modelId "${modelId}" does not identify a loaded Live2D model`);
        return queue(slot, async () => {
          if (models.get(modelId) !== slot)
            throw error("live2d_model_not_found", `modelId "${modelId}" does not identify a loaded Live2D model`);
          models.delete(modelId);
          try {
            destroySlot(slot);
          } catch (cause) {
            throw cause;
          }
          return { modelId, released: true };
        });
      }
      async function invoke(capability, params, context = {}) {
        if (disposed)
          throw error("live2d_provider_disposed", "Live2D provider is disposed");
        checkSignal(context?.signal);
        if (capability === LOAD) {
          const pending = loadModel(params, context?.signal);
          pendingLoads.add(pending);
          try {
            return await pending;
          } finally {
            pendingLoads.delete(pending);
          }
        }
        if (capability === UPDATE)
          return updateModel(params, context?.signal);
        if (capability === RELEASE)
          return releaseModel(params);
        throw error("unsupported", `Unsupported Live2D capability "${String(capability)}"`);
      }
      async function dispose() {
        if (disposed)
          return;
        disposed = true;
        await Promise.allSettled([...pendingLoads]);
        const ids = [...models.keys()];
        const results = await Promise.allSettled(ids.map((modelId) => releaseModel({ modelId }, true)));
        const failure = results.find((result) => result.status === "rejected");
        if (failure)
          throw failure.reason;
      }
      return { invoke, dispose };
    }
    return { createLive2dProvider };
  });
});

// targets/web/live2d_browser.js
var require_live2d_browser = __commonJS((exports, module) => {
  var { createLive2dProvider } = require_live2d_provider();
  var live2dCapabilities = ["media.live2d.model.load", "media.live2d.model.update", "media.live2d.model.release"];
  var coreScripts = new Map;
  function loadCubismCore(url) {
    const absolute = new URL(url, document.baseURI).href;
    if (coreScripts.has(absolute))
      return coreScripts.get(absolute);
    const pending = new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = absolute;
      const timer = setTimeout(() => finish(new Error("Cubism Web Core initialization timed out")), 20000);
      let poll;
      const finish = (error, core) => {
        clearTimeout(timer);
        clearTimeout(poll);
        script.onload = script.onerror = null;
        if (error) {
          script.remove();
          reject(error);
        } else
          resolve(core);
      };
      script.onerror = () => finish(new Error(`Could not load Cubism Web Core: ${absolute}`));
      script.onload = () => {
        const ready = () => {
          try {
            const core = globalThis.Live2DCubismCore;
            if (!core?.Moc || !core?.Model || !core?.Version?.csmGetVersion())
              throw new Error("Core is not ready");
            finish(null, core);
          } catch (_) {
            poll = setTimeout(ready, 16);
          }
        };
        ready();
      };
      document.head.appendChild(script);
    });
    coreScripts.set(absolute, pending);
    pending.catch(() => {
      if (coreScripts.get(absolute) === pending)
        coreScripts.delete(absolute);
    });
    return pending;
  }
  function safeAsset(value) {
    return typeof value === "string" && value.length > 0 && value.length <= 1024 && !/[\\\x00-\x1f%?#:]/.test(value) && !value.startsWith("/") && value.split("/").every((part) => part && part !== "." && part !== "..");
  }
  function createBrowserLive2d(config, baseUrl) {
    if (!config)
      return null;
    if (typeof config.coreUrl !== "string" || !config.coreUrl)
      throw new Error("Live2D requires a trusted Cubism Web coreUrl");
    if (!config.assets || typeof config.assets !== "object" || Array.isArray(config.assets))
      throw new Error("Live2D requires a packaged asset allowlist");
    const assets = new Map;
    const base = new URL(baseUrl, document.baseURI);
    for (const [key, path] of Object.entries(config.assets)) {
      if (!safeAsset(key) || typeof path !== "string" || !path || path.length > 8192)
        throw new Error("Live2D asset allowlist contains an unsafe path");
      const url = new URL(path, base);
      if (url.origin !== base.origin || url.username || url.password || url.hash)
        throw new Error("Live2D model assets must share their package origin");
      assets.set(key, url.href);
    }
    return createLive2dProvider({
      core: () => loadCubismCore(new URL(config.coreUrl, base).href),
      readAsset: async (key, signal) => {
        const url = assets.get(key);
        if (!url)
          throw Object.assign(new Error(`Live2D asset is not packaged: ${key}`), { code: "permission_denied" });
        const response = await fetch(url, { signal });
        if (!response.ok)
          throw new Error(`Live2D model HTTP ${response.status}`);
        const limit = 32 * 1024 * 1024;
        if (Number(response.headers.get("content-length")) > limit)
          throw new Error("Live2D model exceeds 32 MiB");
        const reader = response.body?.getReader();
        if (!reader)
          throw new Error("Live2D model response has no body");
        const chunks = [];
        let length = 0;
        try {
          for (;; ) {
            const { value, done } = await reader.read();
            if (done)
              break;
            length += value.byteLength;
            if (length > limit)
              throw new Error("Live2D model exceeds 32 MiB");
            chunks.push(value);
          }
        } finally {
          await reader.cancel().catch(() => {});
          reader.releaseLock();
        }
        const bytes = new Uint8Array(length);
        let offset = 0;
        for (const chunk of chunks) {
          bytes.set(chunk, offset);
          offset += chunk.byteLength;
        }
        return bytes;
      }
    });
  }
  module.exports = { createBrowserLive2d, live2dCapabilities, loadCubismCore };
});

// targets/web/browser_runtime.js
var {
  PocketWechatHost,
  registerCapability,
  setPermissionHandler,
  registeredCapabilityNames,
  invokeRegisteredCapability,
  requestCapabilityPermission
} = require_wechat_host();
var { BrowserGameInput } = require_game_input();
var { createPocketWorkerTransport } = require_worker_transport();
var { PocketRenderWorkerHost } = require_render_worker_transport();
var { observeRenderHost } = require_render_observations();
var { createBrowserLive2d, live2dCapabilities } = require_live2d_browser();
function numberOr(value, fallback) {
  return Number.isFinite(Number(value)) ? Number(value) : fallback;
}
function browserStorage() {
  const store = globalThis.localStorage;
  if (!store)
    throw Object.assign(new Error("localStorage is unavailable"), { code: "unsupported" });
  return store;
}
function createBrowserWx(runtime) {
  const wx = {
    __pocketBrowserPreview: true,
    __pocketBrowserDevicePixelRatio: () => numberOr(globalThis.devicePixelRatio, 1),
    WXWebAssembly: {
      instantiate: async (_path, imports) => {
        const response = await fetch(runtime.engineUrl, { cache: runtime.cache ?? "no-store" });
        if (!response.ok)
          throw new Error(`PocketJS WASM HTTP ${response.status}`);
        return WebAssembly.instantiate(await response.arrayBuffer(), imports);
      }
    },
    getWindowInfo: () => {
      const rect = runtime.canvas.getBoundingClientRect();
      const width = Math.max(1, Math.floor(rect.width || runtime.canvas.clientWidth || 1));
      const height = Math.max(1, Math.floor(rect.height || runtime.canvas.clientHeight || 1));
      return {
        windowWidth: width,
        windowHeight: height,
        screenWidth: width,
        screenHeight: height,
        pixelRatio: numberOr(globalThis.devicePixelRatio, 1),
        safeArea: { left: 0, top: 0, right: width, bottom: height }
      };
    },
    getSystemInfoSync: () => wx.getWindowInfo(),
    hideKeyboard: ({ complete } = {}) => {
      if (typeof complete === "function")
        complete();
    },
    getStorage: ({ key, success, fail } = {}) => {
      try {
        const value = browserStorage().getItem(String(key));
        if (value === null)
          fail?.({ errMsg: "data not found" });
        else
          success?.({ data: value });
      } catch (error) {
        fail?.({ errMsg: String(error?.message || error) });
      }
    },
    setStorage: ({ key, data, success, fail } = {}) => {
      try {
        browserStorage().setItem(String(key), String(data));
        success?.();
      } catch (error) {
        fail?.({ errMsg: String(error?.message || error) });
      }
    },
    removeStorage: ({ key, success, fail } = {}) => {
      try {
        browserStorage().removeItem(String(key));
        success?.();
      } catch (error) {
        fail?.({ errMsg: String(error?.message || error) });
      }
    },
    getStorageInfo: ({ success, fail } = {}) => {
      try {
        const store = browserStorage();
        const keys = [];
        for (let index = 0;index < store.length; index += 1) {
          const key = store.key(index);
          if (key !== null)
            keys.push(key);
        }
        success?.({ keys, currentSize: 0, limitSize: 0 });
      } catch (error) {
        fail?.({ errMsg: String(error?.message || error) });
      }
    }
  };
  return wx;
}

class PocketWebRuntime {
  constructor(options = {}) {
    if (!options.canvas || typeof options.canvas.getContext !== "function") {
      throw new TypeError("PocketWebRuntime requires an HTMLCanvasElement or compatible Canvas2D surface");
    }
    if (!options.engineUrl)
      throw new TypeError("PocketWebRuntime requires engineUrl");
    this.canvas = options.canvas;
    this.engineUrl = String(options.engineUrl);
    const configured = options.config && typeof options.config === "object" ? options.config : {};
    this.qjbcUrl = options.qjbcUrl ? String(options.qjbcUrl) : configured.qjbcUrl ? String(configured.qjbcUrl) : null;
    this.pakUrl = options.pakUrl ? String(options.pakUrl) : configured.pakUrl ? String(configured.pakUrl) : null;
    this.cache = options.cache;
    this.config = {
      ...options.config || {},
      provider: "web",
      host: "web",
      hostRuntime: "WebAssembly + Canvas2D",
      enginePath: "engine/pocketjs.wasm"
    };
    this.inputElement = options.inputElement || null;
    this.ownsInputElement = false;
    this.disposed = false;
    this.active = false;
    this.mounted = false;
    this.mountPromise = null;
    this.pointers = new Map;
    this.renderWorker = options.renderWorker ?? this.config.renderWorker ?? false;
    if (typeof this.renderWorker !== "boolean")
      throw new TypeError("renderWorker must be a boolean host option");
    this.context = this.renderWorker ? null : this.canvas.getContext("2d", { alpha: true });
    if (!this.renderWorker && !this.context)
      throw new Error("PocketJS requires a Canvas2D context");
    this.onError = options.onError;
    this.workerTransport = null;
    this.workerTransportUnsubscribe = null;
    this.gameInput = options.gameInput === true || this.config.gameInput === true ? new BrowserGameInput({ canvas: this.canvas, onChange: () => {
      if (this.active && !this.disposed)
        this.host?.inputFrame([...this.pointers.values()]);
    } }) : null;
    this.wx = createBrowserWx(this);
    this.live2d = createBrowserLive2d(this.config.live2d, this.qjbcUrl ? new URL(this.qjbcUrl, document.baseURI).href : document.baseURI);
    this.capabilityHandlers = Object.create(null);
    if (this.live2d)
      for (const name of live2dCapabilities) {
        this.capabilityHandlers[name] = (params, context) => this.live2d.invoke(name, params, context);
      }
    const hostOptions = {
      wx: this.wx,
      config: this.config,
      canvas: this.canvas,
      context: this.context,
      onInput: (value) => this.updateInput(value),
      onError: (error) => this.onError?.(error),
      isActive: () => this.active && !this.disposed,
      sampleInput: () => this.gameInput?.state(),
      onWorkerChannel: (channel, data) => this.workerTransport?.receive(channel, data),
      capabilityHandlers: this.capabilityHandlers
    };
    if (this.renderWorker) {
      const base = document.baseURI;
      const absolute = (value) => value ? new URL(value, base).href : null;
      try {
        this.host = new PocketRenderWorkerHost({
          ...hostOptions,
          workerUrl: absolute(options.renderWorkerUrl) || new URL("./pocket-render-worker.js", import.meta.url).href,
          engineUrl: absolute(this.engineUrl),
          qjbcUrl: absolute(this.qjbcUrl),
          pakUrl: absolute(this.pakUrl),
          cache: this.cache,
          capabilityNames: [...new Set([...Object.keys(this.capabilityHandlers), ...registeredCapabilityNames(), ...this.config.requires || [], ...this.config.optional || []])],
          boundary: (operation, params, signal) => this.browserBoundary(operation, params, signal)
        });
      } catch (error) {
        this.gameInput?.dispose();
        throw error;
      }
    } else {
      this.host = new PocketWechatHost(hostOptions);
      this.observations = observeRenderHost(this.host, "main");
    }
    this.handleResize = () => {
      if (!this.disposed)
        this.host.resize(this.width(), this.height());
    };
    this.handleVisibility = () => {
      if (document.visibilityState === "hidden")
        this.hide();
      else
        this.show();
    };
    this.handlePointer = (event) => this.pointer(event);
    this.handleKey = (event) => {
      if (event.key === "Enter")
        this.host.imeSubmit({ value: this.inputElement?.value || "" });
      if (event.key === "Escape")
        this.host.imeDismiss({ value: this.inputElement?.value || "" });
    };
  }
  width() {
    return Math.max(1, Math.floor(this.canvas.clientWidth || this.canvas.width || 1));
  }
  height() {
    return Math.max(1, Math.floor(this.canvas.clientHeight || this.canvas.height || 1));
  }
  async browserBoundary(operation, params, signal) {
    if (this.disposed || signal.aborted)
      throw Object.assign(new Error("Browser host is disposed"), { code: "cancelled" });
    if (Object.hasOwn(this.capabilityHandlers, params.capability)) {
      if (operation === "permission")
        return true;
      if (operation === "capability.invoke")
        return this.capabilityHandlers[params.capability](params.params || {}, { signal });
    }
    if (operation === "permission")
      return requestCapabilityPermission(params.capability, params.params || {}, { signal, wx: this.wx });
    if (operation === "capability.invoke")
      return invokeRegisteredCapability(params.capability, params.params || {}, { signal, wx: this.wx });
    const store = browserStorage();
    if (operation === "storage.get") {
      const data = store.getItem(String(params.key));
      if (data === null)
        throw Object.assign(new Error("data not found"), { code: "not_found" });
      return { data };
    }
    if (operation === "storage.set") {
      store.setItem(String(params.key), String(params.data));
      return {};
    }
    if (operation === "storage.remove") {
      store.removeItem(String(params.key));
      return {};
    }
    if (operation === "storage.info") {
      const keys = [];
      for (let index = 0;index < store.length; index++) {
        const key = store.key(index);
        if (key !== null)
          keys.push(key);
      }
      return { keys, currentSize: 0, limitSize: 0 };
    }
    throw Object.assign(new Error(`Unsupported browser boundary: ${operation}`), { code: "unsupported" });
  }
  async inspect() {
    return this.renderWorker ? this.host.inspect() : this.observations.inspect();
  }
  async stats() {
    return this.renderWorker ? this.host.stats() : this.observations.stats();
  }
  ensureInputElement() {
    if (this.inputElement)
      return this.inputElement;
    const parent = this.canvas.parentElement || document.body;
    if (getComputedStyle(parent).position === "static")
      parent.style.position = "relative";
    const input = document.createElement("input");
    input.autocomplete = "off";
    input.spellcheck = false;
    input.style.position = "absolute";
    input.style.display = "none";
    input.style.zIndex = "10";
    input.addEventListener("input", () => this.host.imeEdit({ value: input.value, cursor: input.selectionStart ?? input.value.length }));
    input.addEventListener("blur", () => this.host.imeDismiss({ value: input.value }));
    input.addEventListener("keydown", this.handleKey);
    parent.appendChild(input);
    this.inputElement = input;
    this.ownsInputElement = true;
    return input;
  }
  updateInput(value) {
    const input = this.ensureInputElement();
    if (!value?.visible) {
      input.style.display = "none";
      return;
    }
    input.value = String(value.text || "");
    input.placeholder = String(value.placeholder || "");
    input.style.cssText = `${value.style || ""};position:absolute;z-index:10;display:block;box-sizing:border-box;`;
    input.focus({ preventScroll: true });
    const cursor = Math.max(0, Math.min(input.value.length, Number(value.cursor) || input.value.length));
    input.setSelectionRange(cursor, cursor);
  }
  pointer(event) {
    if (this.disposed)
      return;
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.width() / Math.max(1, rect.width), scaleY = this.height() / Math.max(1, rect.height);
    const contact = {
      surface: 0,
      id: Number(event.pointerId || 0) >>> 0,
      x: (event.clientX - rect.left) * scaleX,
      y: (event.clientY - rect.top) * scaleY,
      cancelled: event.type === "pointercancel"
    };
    if (event.type === "pointerdown") {
      if ((!this.inputElement || this.inputElement.style.display === "none") && this.canvas.focus)
        this.canvas.focus({ preventScroll: true });
      this.pointers.set(event.pointerId, contact);
      this.canvas.setPointerCapture?.(event.pointerId);
    } else if (event.type === "pointermove") {
      if (!this.pointers.has(event.pointerId))
        return;
      this.pointers.set(event.pointerId, contact);
    } else {
      if (!this.pointers.has(event.pointerId))
        return;
      this.pointers.delete(event.pointerId);
    }
    const contacts = [...this.pointers.values()];
    if (event.type === "pointercancel")
      contacts.push(contact);
    this.host.inputFrame(contacts);
    event.preventDefault();
  }
  async mount() {
    if (this.disposed)
      throw new Error("PocketWebRuntime is disposed");
    if (this.mounted)
      return this;
    if (this.mountPromise)
      return this.mountPromise;
    this.mountPromise = this.mountRuntime();
    try {
      return await this.mountPromise;
    } catch (error) {
      this.dispose();
      throw error;
    } finally {
      this.mountPromise = null;
    }
  }
  async mountRuntime() {
    if (!this.renderWorker && (this.qjbcUrl || this.pakUrl)) {
      if (!this.qjbcUrl || !this.pakUrl)
        throw new Error("PocketWebRuntime requires both qjbcUrl and pakUrl");
      const [qjbcResponse, pakResponse] = await Promise.all([
        fetch(this.qjbcUrl, { cache: this.cache ?? "no-store" }),
        fetch(this.pakUrl, { cache: this.cache ?? "no-store" })
      ]);
      if (!qjbcResponse.ok)
        throw new Error(`PocketJS QJBC HTTP ${qjbcResponse.status}`);
      if (!pakResponse.ok)
        throw new Error(`PocketJS PAK HTTP ${pakResponse.status}`);
      const hostAbi = Number(this.config.bindingGeneration ?? this.config.hostAbi);
      if (!Number.isInteger(hostAbi) || hostAbi < 1) {
        throw new Error("PocketWebRuntime external Guest requires config.bindingGeneration");
      }
      this.config.externalGuest = {
        qjbc: new Uint8Array(await qjbcResponse.arrayBuffer()),
        pak: new Uint8Array(await pakResponse.arrayBuffer()),
        tickHz: Number(this.config.tickHz || 60),
        hostAbi
      };
    }
    this.active = true;
    addEventListener("resize", this.handleResize);
    addEventListener("visibilitychange", this.handleVisibility);
    for (const type of ["pointerdown", "pointermove", "pointerup", "pointercancel"])
      this.canvas.addEventListener(type, this.handlePointer, { passive: false });
    await this.host.start(this.width(), this.height(), numberOr(globalThis.devicePixelRatio, 1));
    const workerConfig = this.config.worker && typeof this.config.worker === "object" ? this.config.worker : null;
    const workerDescriptor = workerConfig?.descriptor && typeof workerConfig.descriptor === "object" ? workerConfig.descriptor : workerConfig;
    if (!this.renderWorker && workerConfig && workerDescriptor) {
      const base = globalThis.location?.href || globalThis.document?.baseURI || "http://localhost/";
      const engineUrl = new URL(this.engineUrl, base).href;
      const qjbcBase = this.qjbcUrl ? new URL(this.qjbcUrl, base) : new URL(base);
      this.workerTransport = createPocketWorkerTransport({
        descriptor: workerDescriptor,
        engineUrl,
        qjbcUrl: new URL(String(workerConfig.bytecode || "app.worker.qjbc"), qjbcBase).href,
        workerHttpOrigins: this.config.workerHttpOrigins,
        onError: (error) => this.onError?.(error)
      });
      this.workerTransportUnsubscribe = this.workerTransport.subscribe((channel, data) => this.host.pushWorkerChannel(channel, data));
      try {
        await this.workerTransport.ready;
      } catch (error) {
        this.dispose();
        throw error;
      }
    }
    this.mounted = true;
    this.host.show();
    this.workerTransport?.setActive(true);
    this.gameInput?.setActive(true);
    return this;
  }
  show() {
    if (!this.disposed) {
      this.active = true;
      this.host.show();
      this.workerTransport?.setActive(true);
      this.gameInput?.setActive(true);
    }
  }
  hide() {
    if (!this.disposed) {
      this.gameInput?.setActive(false);
      this.active = false;
      this.workerTransport?.setActive(false);
      this.host.hide();
    }
  }
  dispose() {
    if (this.disposed)
      return;
    this.disposed = true;
    this.active = false;
    const released = this.live2d?.dispose().catch((error) => this.onError?.(error));
    this.live2d = null;
    removeEventListener("resize", this.handleResize);
    removeEventListener("visibilitychange", this.handleVisibility);
    for (const type of ["pointerdown", "pointermove", "pointerup", "pointercancel"])
      this.canvas.removeEventListener(type, this.handlePointer);
    this.pointers.clear();
    this.gameInput?.dispose();
    this.gameInput = null;
    this.workerTransportUnsubscribe?.();
    this.workerTransportUnsubscribe = null;
    this.workerTransport?.dispose();
    this.workerTransport = null;
    this.host.dispose();
    if (this.ownsInputElement)
      this.inputElement?.remove();
    return released;
  }
}
export {
  setPermissionHandler,
  registerCapability,
  PocketWebRuntime
};
